package com.example.data.remote

import com.example.BuildConfig
import com.example.data.local.ChatMessageEntity
import com.example.data.model.GeminiModelTier
import com.example.data.model.QuizQuestionItem
import com.example.data.model.TutorRolePersona
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null
)

@Serializable
data class GenerationConfig(
    val responseMimeType: String? = null,
    val responseSchema: JsonObject? = null,
    val temperature: Float? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate> = emptyList()
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiRestApi {
    @POST("v1beta/models/{model}:generateContent")
    suspend fun generateContent(
        @Path("model") model: String,
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiAcademicService {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"
    private const val PRIMARY_STEM_MODEL = "gemini-3.1-pro-preview"
    private const val FALLBACK_FLASH_MODEL = "gemini-3.5-flash"
    private const val FAST_LITE_MODEL = "gemini-3.1-flash-lite-preview"

    private val jsonFormat = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private val api: GeminiRestApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(jsonFormat.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiRestApi::class.java)
    }

    fun resolveActiveApiKey(userPersonalKey: String): String {
        val trimmedUserKey = userPersonalKey.trim()
        if (trimmedUserKey.isNotEmpty() && !trimmedUserKey.startsWith("DEMO_KEY")) {
            return trimmedUserKey
        }
        val buildConfigKey = BuildConfig.GEMINI_API_KEY.trim()
        if (buildConfigKey.isNotEmpty() && buildConfigKey != "MY_GEMINI_API_KEY") {
            return buildConfigKey
        }
        return ""
    }

    suspend fun askAiTutor(
        userApiKey: String,
        subject: String,
        board: String,
        gradeLevel: String,
        question: String,
        conversationHistory: List<ChatMessageEntity> = emptyList(),
        modelTier: GeminiModelTier = GeminiModelTier.COMPLEX_PRO,
        rolePersona: TutorRolePersona = TutorRolePersona.SOCRATIC_PROFESSOR,
        customSystemInstruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        val activeKey = resolveActiveApiKey(userApiKey)
        val roleDirective = customSystemInstruction.trim().ifBlank {
            rolePersona.defaultSystemInstruction
        }
        val systemPrompt = """
            $roleDirective
            
            Academic Context:
            - Examination Board: $board ($gradeLevel)
            - Active Subject: $subject
            - Assigned Role: ${rolePersona.roleTitle}
            - Selected Model Tier: ${modelTier.displayTitle} (${modelTier.badgeLabel})
            
            CRITICAL MATH FORMATTING RULE:
            - Format ALL mathematical formulas, algebraic equations, powers, roots, integrals, derivatives, and scientific notations in clean standard LaTeX using inline ${'$'}...${'$'} or display block ${'$'}${'$'}...${'$'}${'$'}.
            - NEVER wrap LaTeX formulas inside markdown code blocks (never use ```math, ```latex, ```tex, or single backticks `...`).
            - Maintain multi-turn continuity with previous messages in the conversation thread.
        """.trimIndent()

        if (activeKey.isNotEmpty()) {
            // Build multi-turn conversation contents (last 12 turns + current user prompt)
            val historyTurns = conversationHistory
                .takeLast(12)
                .map { msg ->
                    Content(
                        role = if (msg.isUser) "user" else "model",
                        parts = listOf(Part(text = msg.content))
                    )
                }
            val multiTurnContents = historyTurns + Content(
                role = "user",
                parts = listOf(Part(text = question))
            )

            val temp = when (modelTier) {
                GeminiModelTier.COMPLEX_PRO -> 0.35f
                GeminiModelTier.GENERAL_FLASH -> 0.5f
                GeminiModelTier.FAST_FLASH_LITE -> 0.3f
            }

            val req = GenerateContentRequest(
                contents = multiTurnContents,
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt))),
                generationConfig = GenerationConfig(temperature = temp)
            )

            val candidateModels = when (modelTier) {
                GeminiModelTier.COMPLEX_PRO -> listOf(PRIMARY_STEM_MODEL, FALLBACK_FLASH_MODEL, FAST_LITE_MODEL)
                GeminiModelTier.GENERAL_FLASH -> listOf(FALLBACK_FLASH_MODEL, PRIMARY_STEM_MODEL, FAST_LITE_MODEL)
                GeminiModelTier.FAST_FLASH_LITE -> listOf(FAST_LITE_MODEL, "gemini-3.1-flash-lite", FALLBACK_FLASH_MODEL)
            }

            for (model in candidateModels) {
                try {
                    val res = api.generateContent(model, activeKey, req)
                    val reply = res.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!reply.isNullOrBlank()) {
                        return@withContext reply
                    }
                } catch (_: Exception) {
                    // Try fallback model or local academic synthesis
                }
            }
        }

        val turnNumber = (conversationHistory.count { it.isUser } + 1)
        val headerBadge = "**[${rolePersona.iconEmoji} ${rolePersona.roleTitle} • Model: `${modelTier.displayTitle}` • Turn #$turnNumber]**\n\n"
        headerBadge + synthesizeAcademicTutorResponse(subject, board, gradeLevel, question)
    }

    suspend fun generateCustomQuiz(
        userApiKey: String,
        subject: String,
        topic: String,
        board: String,
        difficulty: String,
        count: Int
    ): List<QuizQuestionItem> = withContext(Dispatchers.IO) {
        val activeKey = resolveActiveApiKey(userApiKey)
        if (activeKey.isNotEmpty()) {
            val prompt = """
                Generate exactly $count multiple-choice questions (MCQs) for Subject: "$subject", Topic: "$topic", Examination Board: "$board", Difficulty: "$difficulty".
                STRICT LATEX FORMATTING RULE:
                - Every mathematical formula, equation, power, root, or scientific unit in "question", "options", and "explanation" MUST use clean LaTeX (${'$'}...${'$'} inline or ${'$'}${'$'}...${'$'}${'$'} block).
                - NEVER use ```math or ```latex code blocks.
                - Each question must have 4 options and a 0-based "correctIndex" (0 to 3).
            """.trimIndent()

            val schema = buildJsonObject {
                put("type", "ARRAY")
                putJsonObject("items") {
                    put("type", "OBJECT")
                    putJsonObject("properties") {
                        putJsonObject("question") { put("type", "STRING") }
                        putJsonObject("options") {
                            put("type", "ARRAY")
                            putJsonObject("items") { put("type", "STRING") }
                        }
                        putJsonObject("correctIndex") { put("type", "INTEGER") }
                        putJsonObject("explanation") { put("type", "STRING") }
                        putJsonObject("sloTag") { put("type", "STRING") }
                    }
                    putJsonArray("required") {
                        add(kotlinx.serialization.json.JsonPrimitive("question"))
                        add(kotlinx.serialization.json.JsonPrimitive("options"))
                        add(kotlinx.serialization.json.JsonPrimitive("correctIndex"))
                        add(kotlinx.serialization.json.JsonPrimitive("explanation"))
                    }
                }
            }

            val req = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                generationConfig = GenerationConfig(
                    responseMimeType = "application/json",
                    responseSchema = schema,
                    temperature = 0.5f
                )
            )

            for (model in listOf(FALLBACK_FLASH_MODEL, PRIMARY_STEM_MODEL)) {
                try {
                    val res = api.generateContent(model, activeKey, req)
                    val rawJson = res.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!rawJson.isNullOrBlank()) {
                        val parsedArray = jsonFormat.parseToJsonElement(rawJson).jsonArray
                        val parsedList = parsedArray.mapIndexed { idx, elem ->
                            val obj = elem.jsonObject
                            val opts = obj["options"]?.jsonArray?.map { it.jsonPrimitive.content } ?: emptyList()
                            QuizQuestionItem(
                                id = idx + 1,
                                question = obj["question"]?.jsonPrimitive?.content ?: "",
                                options = if (opts.size >= 4) opts.take(4) else opts + List(4 - opts.size) { "Option ${it + 1}" },
                                correctIndex = (obj["correctIndex"]?.jsonPrimitive?.content?.toIntOrNull() ?: 0).coerceIn(0, 3),
                                explanation = obj["explanation"]?.jsonPrimitive?.content ?: "",
                                difficulty = difficulty,
                                sloTag = obj["sloTag"]?.jsonPrimitive?.content ?: "$board • $difficulty"
                            )
                        }
                        if (parsedList.isNotEmpty()) {
                            return@withContext parsedList
                        }
                    }
                } catch (_: Exception) {
                    // Fallback to rich local curriculum bank if network/quota fails
                }
            }
        }

        buildCuratedBoardMcqSet(subject, topic, board, difficulty, count)
    }

    suspend fun generateBoardGuessPaper(
        userApiKey: String,
        subject: String,
        topic: String,
        board: String,
        gradeLevel: String
    ): String = withContext(Dispatchers.IO) {
        val activeKey = resolveActiveApiKey(userApiKey)
        if (activeKey.isNotEmpty()) {
            val prompt = """
                Generate an official SLO-aligned Model Guess Paper for:
                - Examination Authority: $board
                - Grade Level: $gradeLevel
                - Subject: $subject
                - Focus Chapter/Topic: $topic
                
                Include:
                1. Section A: High-Probability Conceptual MCQs with answers and LaTeX explanations.
                2. Section B: High-Yield SLO Short Questions (4 Marks each) with complete mathematical derivations.
                3. Section C: Comprehensive Long Analytical Derivation (8 Marks) + Official Board Step-by-Step Marking Rubric.
                
                CRITICAL RULE: Format all equations and scientific notation using standard inline ${'$'}...${'$'} or block ${'$'}${'$'}...${'$'}${'$'} LaTeX. NEVER use ```math or ```latex code blocks.
            """.trimIndent()

            val req = GenerateContentRequest(
                contents = listOf(Content(parts = listOf(Part(text = prompt)))),
                generationConfig = GenerationConfig(temperature = 0.4f)
            )
            for (model in listOf(PRIMARY_STEM_MODEL, FALLBACK_FLASH_MODEL)) {
                try {
                    val res = api.generateContent(model, activeKey, req)
                    val text = res.candidates.firstOrNull()?.content?.parts?.firstOrNull()?.text
                    if (!text.isNullOrBlank()) {
                        return@withContext text
                    }
                } catch (_: Exception) {
                    // Fallback below
                }
            }
        }

        buildCuratedGuessPaper(subject, topic, board, gradeLevel)
    }

    private fun synthesizeAcademicTutorResponse(
        subject: String,
        board: String,
        gradeLevel: String,
        question: String
    ): String {
        val qLower = question.lowercase()
        return when {
            qLower.contains("carnot") || qLower.contains("thermodynamic") || qLower.contains("efficiency") -> """
### 🎓 SLO Derivation: Carnot Heat Engine & Thermal Efficiency
**Board Alignment:** $board • $gradeLevel ($subject)

#### 1. Fundamental Thermodynamic Principle
By the **First Law of Thermodynamics**, the differential heat supplied to an ideal gas relates to internal energy and work:
${'$'}${'$'}dQ = dU + dW${'$'}${'$'}

For a cyclic Carnot process operating between a hot reservoir at temperature ${'$'}T_H${'$'} and a cold sink at temperature ${'$'}T_C${'$'}, the total change in internal energy over a complete cycle vanishes:
${'$'}${'$'}\Delta U_{\text{cycle}} = 0 \implies W_{\text{net}} = Q_H - Q_C${'$'}${'$'}

#### 2. Four-Stage Reversible Cycle Equations
1. **Isothermal Expansion at ${'$'}T_H${'$'}:**
   ${'$'}${'$'}Q_H = W_1 = n R T_H \ln\left(\frac{V_2}{V_1}\right)${'$'}${'$'}
2. **Adiabatic Expansion (${'$'}T_H \rightarrow T_C${'$'}):**
   ${'$'}${'$'}W_2 = \frac{n R}{\gamma - 1}(T_H - T_C)${'$'}${'$'}
3. **Isothermal Compression at ${'$'}T_C${'$'}:**
   ${'$'}${'$'}Q_C = |W_3| = n R T_C \ln\left(\frac{V_3}{V_4}\right)${'$'}${'$'}
4. **Adiabatic Compression (${'$'}T_C \rightarrow T_H${'$'}):**
   ${'$'}${'$'}|W_4| = \frac{n R}{\gamma - 1}(T_H - T_C)${'$'}${'$'}

#### 3. Final Thermal Efficiency Formula
Since ${'$'}T_H V_2^{\gamma-1} = T_C V_3^{\gamma-1}${'$'} and ${'$'}T_H V_1^{\gamma-1} = T_C V_4^{\gamma-1}${'$'}, dividing the two adiabatic relations gives ${'$'}\frac{V_2}{V_1} = \frac{V_3}{V_4}${'$'}. Thus:
${'$'}${'$'}\eta = \frac{W_{\text{net}}}{Q_H} = \frac{Q_H - Q_C}{Q_H} = 1 - \frac{Q_C}{Q_H} = 1 - \frac{T_C}{T_H}${'$'}${'$'}

> **Exam Board Tip:** Always convert temperatures from ${'$'}^\circ\text{C}${'$'} to Kelvin using ${'$'}T(\text{K}) = T(^\circ\text{C}) + 273.15${'$'} before substituting into ${'$'}\eta = 1 - \frac{T_C}{T_H}${'$'}.
            """.trimIndent()

            qLower.contains("quadratic") || qLower.contains("root") || qLower.contains("discriminant") || qLower.contains("calculus") || qLower.contains("integral") -> """
### 📐 Mathematical Analysis & Step-by-Step Derivation
**Board Alignment:** $board • $gradeLevel ($subject)

#### 1. Quadratic Root Formula & Discriminant Analysis
Given the general second-degree polynomial equation with ${'$'}a \neq 0${'$'}:
${'$'}${'$'}a x^2 + b x + c = 0${'$'}${'$'}

Dividing through by ${'$'}a${'$'} and completing the square:
${'$'}${'$'}\left(x + \frac{b}{2a}\right)^2 = \frac{b^2 - 4ac}{4a^2}${'$'}${'$'}

Taking the square root on both sides yields the **Quadratic Formula**:
${'$'}${'$'}x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}${'$'}${'$'}

#### 2. Nature of Roots via Discriminant ${'$'}\Delta = b^2 - 4ac${'$'}
- If ${'$'}\Delta > 0${'$'} and a perfect square: **Real, rational, and unequal** roots.
- If ${'$'}\Delta = 0${'$'}: **Real, rational, and equal (repeated)** roots ${'$'}x = -\frac{b}{2a}${'$'}.
- If ${'$'}\Delta < 0${'$'}: **Complex conjugate** roots ${'$'}x = -\frac{b}{2a} \pm i\frac{\sqrt{4ac - b^2}}{2a}${'$'}.

#### 3. Fundamental Calculus Connection
The vertex (extremum) occurs where the first derivative vanishes:
${'$'}${'$'}\frac{d}{dx}(ax^2 + bx + c) = 2ax + b = 0 \implies x_v = -\frac{b}{2a}${'$'}${'$'}
            """.trimIndent()

            else -> """
### 🎓 Structured Concept Breakdown: $question
**Board Alignment:** $board • $gradeLevel • **Subject:** $subject

#### 1. Core Theoretical Framework & Governing Equations
In **$subject**, board examiners evaluate both conceptual clarity and mathematical rigor. Key relationships for this topic include:

- **Electrostatic & Gravitational Inverse-Square Field Law:**
  ${'$'}${'$'}F = \frac{1}{4\pi\varepsilon_0} \frac{q_1 q_2}{r^2} \quad \text{and} \quad \Phi_E = \oint \vec{E} \cdot d\vec{A} = \frac{Q_{\text{enc}}}{\varepsilon_0}${'$'}${'$'}

- **Wave-Particle Duality & Relativistic Energy Invariant:**
  ${'$'}${'$'}\lambda = \frac{h}{p} = \frac{h}{mv} \quad \text{and} \quad E = \sqrt{p^2 c^2 + m_0^2 c^4}${'$'}${'$'}

- **Differential Rate & Integral Accumulation Law:**
  ${'$'}${'$'}\frac{d}{dx}\left[\sin(kx) e^{\alpha x}\right] = e^{\alpha x}\left(k\cos(kx) + \alpha\sin(kx)\right)${'$'}${'$'}

#### 2. High-Yield SLO Exam Pointers ($board)
1. **State Variables & SI Units:** Explicitly define every symbol and its SI unit (e.g., ${'$'}\varepsilon_0 = 8.85 \times 10^{-12} \text{ C}^2\text{N}^{-1}\text{m}^{-2}${'$'}).
2. **Boundary Conditions:** Check limiting cases when ${'$'}r \rightarrow \infty${'$'} or ${'$'}v \ll c${'$'}.
3. **Step Marks:** Even if final numerical calculation has a rounding variance, writing the canonical formula ${'$'}E = mc^2${'$'} or ${'$'}PV^\gamma = \text{constant}${'$'} secures 50% of the rubric marks.
            """.trimIndent()
        }
    }

    fun buildCuratedBoardMcqSet(
        subject: String,
        topic: String,
        board: String,
        difficulty: String,
        count: Int
    ): List<QuizQuestionItem> {
        val bank = listOf(
            QuizQuestionItem(
                id = 1,
                question = "In $subject ($topic), what is the electrostatic force between two point charges ${'$'}q_1${'$'} and ${'$'}q_2${'$'} separated by distance ${'$'}r${'$'} in free space?",
                options = listOf(
                    "${'$'}F = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q_1 q_2}{r^2}${'$'}",
                    "${'$'}F = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q_1 q_2}{r}${'$'}",
                    "${'$'}F = 4\\pi\\varepsilon_0 \\frac{q_1 q_2}{r^2}${'$'}",
                    "${'$'}F = \\frac{q_1 q_2}{4\\pi r^3}${'$'}"
                ),
                correctIndex = 0,
                explanation = "By Coulomb's Law, electrostatic force follows an inverse-square relationship ${'$'}F = \\frac{1}{4\\pi\\varepsilon_0} \\frac{q_1 q_2}{r^2}${'$'} where ${'$'}\\varepsilon_0 = 8.85 \\times 10^{-12} \\text{ F/m}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-1"
            ),
            QuizQuestionItem(
                id = 2,
                question = "For an ideal gas undergoing a reversible adiabatic process, which equation correctly relates pressure ${'$'}P${'$'} and volume ${'$'}V${'$'} where ${'$'}\\gamma = \\frac{C_p}{C_v}${'$'}?",
                options = listOf(
                    "${'$'}P V^\\gamma = \\text{constant}${'$'}",
                    "${'$'}P V = n R T${'$'}",
                    "${'$'}P^\\gamma V = \\text{constant}${'$'}",
                    "${'$'}\\frac{P}{V^\\gamma} = \\text{constant}${'$'}"
                ),
                correctIndex = 0,
                explanation = "In an adiabatic process (${'$'}dQ = 0${'$'}), integrating ${'$'}C_v dT + P dV = 0${'$'} yields Poisson's relation ${'$'}P V^\\gamma = \\text{constant}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-2"
            ),
            QuizQuestionItem(
                id = 3,
                question = "What are the discriminant ${'$'}\\Delta${'$'} and exact roots of the quadratic equation ${'$'}a x^2 + b x + c = 0${'$'} (${'$'}a \\neq 0${'$'})?",
                options = listOf(
                    "${'$'}\\Delta = b^2 - 4ac${'$'} and ${'$'}x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}${'$'}",
                    "${'$'}\\Delta = b^2 + 4ac${'$'} and ${'$'}x = \\frac{-b \\pm \\sqrt{b^2 + 4ac}}{2a}${'$'}",
                    "${'$'}\\Delta = b^2 - 4ac${'$'} and ${'$'}x = \\frac{b \\pm \\sqrt{b^2 - 4ac}}{a}${'$'}",
                    "${'$'}\\Delta = 4ac - b^2${'$'} and ${'$'}x = \\frac{-b \\pm \\sqrt{4ac - b^2}}{2a}${'$'}"
                ),
                correctIndex = 0,
                explanation = "Completing the square on ${'$'}ax^2 + bx + c = 0${'$'} gives ${'$'}x = \\frac{-b \\pm \\sqrt{\\Delta}}{2a}${'$'} with discriminant ${'$'}\\Delta = b^2 - 4ac${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-3"
            ),
            QuizQuestionItem(
                id = 4,
                question = "Evaluate the first derivative ${'$'}\\frac{d}{dx}\\left(\\sin(2x) \\cdot e^{3x}\\right)${'$'} with respect to ${'$'}x${'$'}:",
                options = listOf(
                    "${'$'}e^{3x}\\left(2\\cos(2x) + 3\\sin(2x)\\right)${'$'}",
                    "${'$'}2\\cos(2x) e^{3x}${'$'}",
                    "${'$'}3\\sin(2x) e^{3x}${'$'}",
                    "${'$'}e^{3x}\\left(\\cos(2x) - \\sin(2x)\\right)${'$'}"
                ),
                correctIndex = 0,
                explanation = "Applying the product rule ${'$'}\\frac{d}{dx}(uv) = u'v + uv'${'$'}: ${'$'}u' = 2\\cos(2x)${'$'} and ${'$'}v' = 3e^{3x}${'$'}, giving ${'$'}e^{3x}(2\\cos(2x) + 3\\sin(2x))${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-4"
            ),
            QuizQuestionItem(
                id = 5,
                question = "According to de Broglie's wave-particle duality hypothesis, the wavelength ${'$'}\\lambda${'$'} of a particle of mass ${'$'}m${'$'} moving at velocity ${'$'}v${'$'} is:",
                options = listOf(
                    "${'$'}\\lambda = \\frac{h}{p} = \\frac{h}{mv}${'$'}",
                    "${'$'}\\lambda = \\frac{mv}{h}${'$'}",
                    "${'$'}\\lambda = \\frac{h}{2mv^2}${'$'}",
                    "${'$'}\\lambda = \\frac{h^2}{mv}${'$'}"
                ),
                correctIndex = 0,
                explanation = "de Broglie wavelength relates Planck's constant ${'$'}h = 6.626 \\times 10^{-34} \\text{ J}\\cdot\\text{s}${'$'} to momentum ${'$'}p = mv${'$'} via ${'$'}\\lambda = \\frac{h}{mv}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-5"
            ),
            QuizQuestionItem(
                id = 6,
                question = "What is the exact value of the definite integral ${'$'}\\int_{0}^{\\pi/2} \\cos(x)\\,dx${'$'}?",
                options = listOf(
                    "${'$'}1${'$'}",
                    "${'$'}0${'$'}",
                    "${'$'}\\frac{\\pi}{2}${'$'}",
                    "${'$'}-1${'$'}"
                ),
                correctIndex = 0,
                explanation = "Since ${'$'}\\int \\cos(x)\\,dx = \\sin(x)${'$'}, evaluating from ${'$'}0${'$'} to ${'$'}\\frac{\\pi}{2}${'$'} yields ${'$'}\\sin(\\frac{\\pi}{2}) - \\sin(0) = 1 - 0 = 1${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-6"
            ),
            QuizQuestionItem(
                id = 7,
                question = "In relativistic mechanics, the total energy ${'$'}E${'$'} of a particle with rest mass ${'$'}m_0${'$'} and linear momentum ${'$'}p${'$'} is given by:",
                options = listOf(
                    "${'$'}E = \\sqrt{p^2 c^2 + m_0^2 c^4}${'$'}",
                    "${'$'}E = p c + m_0 c^2${'$'}",
                    "${'$'}E = \\frac{1}{2} m_0 v^2 + m_0 c^2${'$'}",
                    "${'$'}E = p^2 c^2 - m_0^2 c^4${'$'}"
                ),
                correctIndex = 0,
                explanation = "From the Lorentz-invariant four-momentum relation ${'$'}E^2 - p^2 c^2 = m_0^2 c^4${'$'}, we obtain ${'$'}E = \\sqrt{p^2 c^2 + m_0^2 c^4}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-7"
            ),
            QuizQuestionItem(
                id = 8,
                question = "Calculate the ${'$'}\\text{pH}${'$'} of an aqueous solution at ${'$'}25^\\circ\\text{C}${'$'} whose hydronium ion concentration is ${'$'}[H_3O^+] = 1.0 \\times 10^{-4} \\text{ M}${'$'}?",
                options = listOf(
                    "${'$'}\\text{pH} = 4.0${'$'}",
                    "${'$'}\\text{pH} = 10.0${'$'}",
                    "${'$'}\\text{pH} = 7.0${'$'}",
                    "${'$'}\\text{pH} = 1.0 \\times 10^{-4}${'$'}"
                ),
                correctIndex = 0,
                explanation = "By logarithmic definition, ${'$'}\\text{pH} = -\\log_{10}[H_3O^+] = -\\log_{10}(10^{-4}) = 4.0${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-8"
            ),
            QuizQuestionItem(
                id = 9,
                question = "By Gauss's Law in electrostatics, the total electric flux ${'$'}\\Phi_E${'$'} through any closed Gaussian surface enclosing net charge ${'$'}Q${'$'} is:",
                options = listOf(
                    "${'$'}\\Phi_E = \\oint \\vec{E} \\cdot d\\vec{A} = \\frac{Q}{\\varepsilon_0}${'$'}",
                    "${'$'}\\Phi_E = \\varepsilon_0 Q${'$'}",
                    "${'$'}\\Phi_E = \\frac{Q}{4\\pi\\varepsilon_0 r^2}${'$'}",
                    "${'$'}\\Phi_E = 0${'$'}"
                ),
                correctIndex = 0,
                explanation = "Gauss's law states that the surface integral of ${'$'}\\vec{E}${'$'} over a closed surface equals ${'$'}\\frac{Q_{\\text{enclosed}}}{\\varepsilon_0}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-9"
            ),
            QuizQuestionItem(
                id = 10,
                question = "For a Carnot heat engine operating between ${'$'}T_H = 600\\text{ K}${'$'} and ${'$'}T_C = 300\\text{ K}${'$'}, what is the maximum thermal efficiency ${'$'}\\eta${'$'}?",
                options = listOf(
                    "${'$'}\\eta = 1 - \\frac{T_C}{T_H} = 50\\%${'$'}",
                    "${'$'}\\eta = 1 - \\frac{T_H}{T_C} = 100\\%${'$'}",
                    "${'$'}\\eta = \\frac{T_C}{T_H} = 25\\%${'$'}",
                    "${'$'}\\eta = 75\\%${'$'}"
                ),
                correctIndex = 0,
                explanation = "Substituting into ${'$'}\\eta = 1 - \\frac{T_C}{T_H} = 1 - \\frac{300}{600} = 0.50 = 50\\%${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-10"
            ),
            QuizQuestionItem(
                id = 11,
                question = "In simple harmonic motion (SHM), the angular frequency ${'$'}\\omega${'$'} and time period ${'$'}T${'$'} of a mass-spring system with spring constant ${'$'}k${'$'} and mass ${'$'}m${'$'} are:",
                options = listOf(
                    "${'$'}\\omega = \\sqrt{\\frac{k}{m}}${'$'} and ${'$'}T = 2\\pi\\sqrt{\\frac{m}{k}}${'$'}",
                    "${'$'}\\omega = \\sqrt{\\frac{m}{k}}${'$'} and ${'$'}T = 2\\pi\\sqrt{\\frac{k}{m}}${'$'}",
                    "${'$'}\\omega = \\frac{k}{m}${'$'} and ${'$'}T = \\frac{1}{2\\pi}\\sqrt{\\frac{m}{k}}${'$'}",
                    "${'$'}\\omega = 2\\pi k m${'$'}"
                ),
                correctIndex = 0,
                explanation = "From ${'$'}F = -kx = m\\frac{d^2x}{dt^2}${'$'}, we get ${'$'}\\frac{d^2x}{dt^2} + \\frac{k}{m}x = 0${'$'}, so ${'$'}\\omega = \\sqrt{\\frac{k}{m}}${'$'} and ${'$'}T = \\frac{2\\pi}{\\omega} = 2\\pi\\sqrt{\\frac{m}{k}}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-11"
            ),
            QuizQuestionItem(
                id = 12,
                question = "What is the escape velocity ${'$'}v_{\\text{esc}}${'$'} from the surface of a planet of mass ${'$'}M${'$'} and radius ${'$'}R${'$'}?",
                options = listOf(
                    "${'$'}v_{\\text{esc}} = \\sqrt{\\frac{2GM}{R}} = \\sqrt{2gR}${'$'}",
                    "${'$'}v_{\\text{esc}} = \\sqrt{\\frac{GM}{R}}${'$'}",
                    "${'$'}v_{\\text{esc}} = \\frac{2GM}{R^2}${'$'}",
                    "${'$'}v_{\\text{esc}} = 2\\sqrt{gR}${'$'}"
                ),
                correctIndex = 0,
                explanation = "Equating kinetic energy ${'$'}\\frac{1}{2}mv_{\\text{esc}}^2${'$'} to gravitational potential magnitude ${'$'}\\frac{GMm}{R}${'$'} yields ${'$'}v_{\\text{esc}} = \\sqrt{\\frac{2GM}{R}} = \\sqrt{2gR}${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-12"
            ),
            QuizQuestionItem(
                id = 13,
                question = "According to Faraday's Law of Electromagnetic Induction, the induced electromotive force ${'$'}\\mathcal{E}${'$'} in a coil of ${'$'}N${'$'} turns is:",
                options = listOf(
                    "${'$'}\\mathcal{E} = -N \\frac{d\\Phi_B}{dt}${'$'}",
                    "${'$'}\\mathcal{E} = N \\Phi_B t${'$'}",
                    "${'$'}\\mathcal{E} = -\\frac{\\Phi_B}{N}${'$'}",
                    "${'$'}\\mathcal{E} = \\mu_0 N I${'$'}"
                ),
                correctIndex = 0,
                explanation = "Faraday's law together with Lenz's law states ${'$'}\\mathcal{E} = -N \\frac{d\\Phi_B}{dt}${'$'}, where the negative sign indicates opposition to flux change.",
                difficulty = difficulty,
                sloTag = "$board • SLO-13"
            ),
            QuizQuestionItem(
                id = 14,
                question = "What is Euler's fundamental complex identity relating exponential and trigonometric functions for angle ${'$'}\\theta${'$'}?",
                options = listOf(
                    "${'$'}e^{i\\theta} = \\cos(\\theta) + i\\sin(\\theta)${'$'}",
                    "${'$'}e^{i\\theta} = \\sin(\\theta) + i\\cos(\\theta)${'$'}",
                    "${'$'}e^{\\theta} = \\cos(\\theta) - \\sin(\\theta)${'$'}",
                    "${'$'}e^{i\\theta} = \\cos^2(\\theta) + \\sin^2(\\theta)${'$'}"
                ),
                correctIndex = 0,
                explanation = "By Maclaurin series expansion, ${'$'}e^{i\\theta} = \\cos(\\theta) + i\\sin(\\theta)${'$'}, which gives ${'$'}e^{i\\pi} + 1 = 0${'$'} at ${'$'}\\theta = \\pi${'$'}.",
                difficulty = difficulty,
                sloTag = "$board • SLO-14"
            ),
            QuizQuestionItem(
                id = 15,
                question = "For a reversible chemical reaction ${'$'}aA + bB \\rightleftharpoons cC + dD${'$'}, the equilibrium constant ${'$'}K_c${'$'} expression is:",
                options = listOf(
                    "${'$'}K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b}${'$'}",
                    "${'$'}K_c = \\frac{[A]^a [B]^b}{[C]^c [D]^d}${'$'}",
                    "${'$'}K_c = [C]^c + [D]^d - [A]^a - [B]^b${'$'}",
                    "${'$'}K_c = \\frac{c[C] + d[D]}{a[A] + b[B]}${'$'}"
                ),
                correctIndex = 0,
                explanation = "By the Law of Mass Action, ${'$'}K_c = \\frac{[C]^c [D]^d}{[A]^a [B]^b}${'$'} where brackets denote molar concentrations at equilibrium.",
                difficulty = difficulty,
                sloTag = "$board • SLO-15"
            )
        )

        return List(count) { idx ->
            val template = bank[idx % bank.size]
            val cycle = (idx / bank.size) + 1
            val stemPrefix = if (cycle > 1) "[$difficulty Variant #$cycle • $subject] " else ""
            template.copy(
                id = idx + 1,
                question = stemPrefix + template.question,
                difficulty = difficulty
            )
        }
    }

    private fun buildCuratedGuessPaper(
        subject: String,
        topic: String,
        board: String,
        gradeLevel: String
    ): String {
        return """
### 🏛️ Official SLO Model Guess Paper: $subject
**Board Authority:** $board • **Level:** $gradeLevel
**Focus Syllabus Unit:** $topic

---

### Section A: High-Probability Conceptual MCQs (1 Mark Each)

1. For an isothermal expansion of an ideal gas at constant temperature ${'$'}T${'$'}, the internal energy change ${'$'}\Delta U${'$'} is:
   - A) ${'$'}\Delta U = Q${'$'}
   - B) ${'$'}\Delta U = 0${'$'}
   - C) ${'$'}\Delta U = W${'$'}
   - D) ${'$'}\Delta U = n C_v \Delta T \neq 0${'$'}
   *(Correct Answer: **B**, because internal energy of an ideal gas is a function of temperature alone: ${'$'}\Delta T = 0 \implies \Delta U = 0${'$'})*

2. The thermal efficiency ${'$'}\eta${'$'} of a reversible Carnot engine operating between hot reservoir ${'$'}T_H${'$'} and cold sink ${'$'}T_C${'$'} is:
   - A) ${'$'}\eta = 1 - \frac{T_C}{T_H}${'$'}
   - B) ${'$'}\eta = 1 - \frac{T_H}{T_C}${'$'}
   - C) ${'$'}\eta = \frac{T_H + T_C}{T_H}${'$'}
   - D) ${'$'}\eta = \frac{T_C}{T_H - T_C}${'$'}
   *(Correct Answer: **A**)*

3. According to Gauss's Divergence Theorem in electrostatics, electric flux ${'$'}\Phi_E${'$'} through a closed surface enclosing charge ${'$'}Q${'$'} is:
   - A) ${'$'}\Phi_E = \oint \vec{E} \cdot d\vec{A} = \frac{Q}{\varepsilon_0}${'$'}
   - B) ${'$'}\Phi_E = \frac{Q}{4\pi\varepsilon_0 r^2}${'$'}
   - C) ${'$'}\Phi_E = \varepsilon_0 Q${'$'}
   - D) ${'$'}\Phi_E = 0${'$'}
   *(Correct Answer: **A**)*

---

### Section B: High-Yield SLO Short Questions (4 Marks Each)

**Q1. (First Law of Thermodynamics in Adiabatic Compression)**
State the First Law of Thermodynamics:
${'$'}${'$'}dQ = dU + dW${'$'}${'$'}
Prove that during a rapid adiabatic compression (${'$'}dQ = 0${'$'}), the work done on the gas equals the rise in internal energy:
${'$'}${'$'}dW = -dU \implies W_{\text{on}} = \Delta U = n C_v \Delta T${'$'}${'$'}

**Q2. (Entropy & Second Law of Thermodynamics)**
Prove that for any reversible Carnot cycle, the net cyclic integral of entropy change vanishes:
${'$'}${'$'}\Delta S_{\text{cycle}} = \oint \frac{dQ_{\text{rev}}}{T} = \frac{Q_H}{T_H} - \frac{Q_C}{T_C} = 0${'$'}${'$'}

**Q3. (Wave-Particle Duality & Relativistic Momentum)**
Combine Planck's photon energy ${'$'}E = h f = \frac{h c}{\lambda}${'$'} with relativistic momentum ${'$'}p = \frac{E}{c}${'$'} to derive de Broglie's relation:
${'$'}${'$'}\lambda = \frac{h}{p} = \frac{h}{m v}${'$'}${'$'}

---

### Section C: Long Analytical Derivation (8 Marks)

**Q4. (Complete Carnot Cycle Work & Efficiency Proof)**
An ideal gas undergoes a four-step reversible Carnot cycle:
1. **Isothermal Expansion at ${'$'}T_H${'$'}:**
   ${'$'}${'$'}W_1 = Q_H = n R T_H \ln\left(\frac{V_2}{V_1}\right)${'$'}${'$'}
2. **Adiabatic Expansion (${'$'}T_H \rightarrow T_C${'$'}):**
   ${'$'}${'$'}W_2 = \frac{n R}{\gamma - 1}(T_H - T_C)${'$'}${'$'}
3. **Isothermal Compression at ${'$'}T_C${'$'}:**
   ${'$'}${'$'}W_3 = -Q_C = -n R T_C \ln\left(\frac{V_3}{V_4}\right)${'$'}${'$'}
4. **Adiabatic Compression (${'$'}T_C \rightarrow T_H${'$'}):**
   ${'$'}${'$'}W_4 = -\frac{n R}{\gamma - 1}(T_H - T_C)${'$'}${'$'}

Summing ${'$'}W_{\text{net}} = W_1 + W_2 + W_3 + W_4${'$'} and using ${'$'}\frac{V_2}{V_1} = \frac{V_3}{V_4}${'$'}:
${'$'}${'$'}\eta = \frac{W_{\text{net}}}{Q_H} = \frac{n R (T_H - T_C) \ln(V_2 / V_1)}{n R T_H \ln(V_2 / V_1)} = 1 - \frac{T_C}{T_H}${'$'}${'$'}

---

### Official $board Marking Scheme Rubric
- **PV Indicator Diagram & Process Labels:** 2 Marks
- **Isothermal Work Equations (${'$'}W_1, W_3${'$'}):** 2 Marks
- **Adiabatic Volume Ratio Proof (${'$'}\frac{V_2}{V_1} = \frac{V_3}{V_4}${'$'}):** 2 Marks
- **Final Efficiency Expression ${'$'}\eta = 1 - \frac{T_C}{T_H}${'$'}:** 2 Marks
        """.trimIndent()
    }
}
