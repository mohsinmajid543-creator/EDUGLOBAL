package com.example.data.model

import kotlinx.serialization.Serializable

object AcademicCatalog {
    val PAKISTAN_BOARDS = listOf(
        "Federal Board (FBISE Islamabad)",
        "Punjab Board (BISE Lahore / Rawalpindi / Multan)",
        "Sindh Board (BIEK Karachi / BSEK / Hyderabad)",
        "KPK Board (BISE Peshawar / Abbottabad / Swat)",
        "Balochistan Board (BISE Quetta)",
        "Aga Khan University Exam Board (AKU-EB)",
        "Cambridge O/A Levels (CAIE Pakistan)"
    )

    val GRADE_LEVELS = listOf(
        "Class 9 (SSC Part 1)",
        "Class 10 (SSC Part 2)",
        "Class 11 / FSc Part 1 (HSSC-I)",
        "Class 12 / FSc Part 2 (HSSC-II)",
        "Cambridge O Level",
        "Cambridge A Level"
    )

    val DEFAULT_SUBJECTS = listOf(
        SubjectSeed("Physics", "STEM Core", 84),
        SubjectSeed("Mathematics", "STEM Core", 78),
        SubjectSeed("Chemistry", "STEM Core", 86),
        SubjectSeed("Biology", "Life Sciences", 80),
        SubjectSeed("Computer Science", "Computing & AI", 94),
        SubjectSeed("Economics", "Social Sciences", 72),
        SubjectSeed("Psychology", "Humanities", 68),
        SubjectSeed("Islamic Studies", "Compulsory Core", 91),
        SubjectSeed("Pakistan Studies", "Compulsory Core", 89),
        SubjectSeed("English Literature", "Languages", 76),
        SubjectSeed("Statistics", "Quantitative", 70),
        SubjectSeed("Principles of Accounting", "Commerce", 75)
    )

    val BADGE_CATALOG = listOf(
        BadgeDefinition(
            id = "streak_3",
            title = "Flame Starter",
            category = "Streaks",
            icon = "🔥",
            rarity = "Bronze",
            description = "Maintain a 3-day consecutive study and practice streak.",
            target = 3,
            xpReward = 50,
            metricType = BadgeMetricType.STREAK_DAYS
        ),
        BadgeDefinition(
            id = "streak_7",
            title = "Streak Veteran",
            category = "Streaks",
            icon = "⚡",
            rarity = "Silver",
            description = "Maintain a 7-day uninterrupted study streak.",
            target = 7,
            xpReward = 100,
            metricType = BadgeMetricType.STREAK_DAYS
        ),
        BadgeDefinition(
            id = "streak_14",
            title = "Unstoppable Force",
            category = "Streaks",
            icon = "🌟",
            rarity = "Gold",
            description = "Achieve an extraordinary 14-day continuous study streak.",
            target = 14,
            xpReward = 250,
            metricType = BadgeMetricType.STREAK_DAYS
        ),
        BadgeDefinition(
            id = "quiz_1",
            title = "Quiz Pioneer",
            category = "Completed Quizzes",
            icon = "🎯",
            rarity = "Bronze",
            description = "Complete your first dynamic AI assessment with auto-grading.",
            target = 1,
            xpReward = 30,
            metricType = BadgeMetricType.QUIZZES_COMPLETED
        ),
        BadgeDefinition(
            id = "quiz_15",
            title = "Knowledge Veteran",
            category = "Completed Quizzes",
            icon = "🎖️",
            rarity = "Gold",
            description = "Complete 15 curriculum quizzes across any Pakistan board.",
            target = 15,
            xpReward = 200,
            metricType = BadgeMetricType.QUIZZES_COMPLETED
        ),
        BadgeDefinition(
            id = "quiz_25",
            title = "Grand Quizmaster",
            category = "Completed Quizzes",
            icon = "🏆",
            rarity = "Diamond",
            description = "Conquer 25 comprehensive subject assessments.",
            target = 25,
            xpReward = 500,
            metricType = BadgeMetricType.QUIZZES_COMPLETED
        ),
        BadgeDefinition(
            id = "milestone_perfect",
            title = "Flawless Bullseye",
            category = "High-Performance",
            icon = "💯",
            rarity = "Gold",
            description = "Score a 100% perfect mark on any dynamic MCQ quiz.",
            target = 100,
            xpReward = 200,
            metricType = BadgeMetricType.BEST_QUIZ_SCORE
        ),
        BadgeDefinition(
            id = "milestone_90pct",
            title = "High Honors Scholar",
            category = "High-Performance",
            icon = "🏅",
            rarity = "Silver",
            description = "Maintain an overall average quiz accuracy of 90% or above.",
            target = 90,
            xpReward = 150,
            metricType = BadgeMetricType.AVG_QUIZ_SCORE
        ),
        BadgeDefinition(
            id = "milestone_extreme",
            title = "Olympiad Mind",
            category = "High-Performance",
            icon = "🔴",
            rarity = "Diamond",
            description = "Complete and pass an assessment on 'Extreme' difficulty.",
            target = 1,
            xpReward = 300,
            metricType = BadgeMetricType.EXTREME_QUIZZES
        ),
        BadgeDefinition(
            id = "milestone_xp1000",
            title = "XP Titan",
            category = "High-Performance",
            icon = "🚀",
            rarity = "Gold",
            description = "Accumulate 1,000+ total Scholar Experience Points.",
            target = 1000,
            xpReward = 250,
            metricType = BadgeMetricType.SCHOLAR_XP
        )
    )
}

data class SubjectSeed(
    val name: String,
    val category: String,
    val progress: Int
)

enum class BadgeMetricType {
    STREAK_DAYS,
    QUIZZES_COMPLETED,
    BEST_QUIZ_SCORE,
    AVG_QUIZ_SCORE,
    EXTREME_QUIZZES,
    SCHOLAR_XP
}

data class BadgeDefinition(
    val id: String,
    val title: String,
    val category: String,
    val icon: String,
    val rarity: String,
    val description: String,
    val target: Int,
    val xpReward: Int,
    val metricType: BadgeMetricType
)

@Serializable
data class QuizQuestionItem(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String,
    val difficulty: String = "Medium",
    val sloTag: String = "SLO-Verified"
)

enum class GeminiModelTier(
    val apiModelId: String,
    val fallbackModelId: String,
    val displayTitle: String,
    val badgeLabel: String,
    val taskCategory: String,
    val description: String
) {
    COMPLEX_PRO(
        apiModelId = "gemini-3.1-pro-preview",
        fallbackModelId = "gemini-3.5-flash",
        displayTitle = "gemini-3.1-pro-preview",
        badgeLabel = "Complex Tasks",
        taskCategory = "Deep STEM Derivations & Proofs",
        description = "Uses gemini-3.1-pro-preview for complex multi-step derivations, calculus proofs, and analytical board questions."
    ),
    GENERAL_FLASH(
        apiModelId = "gemini-3.5-flash",
        fallbackModelId = "gemini-3.1-pro-preview",
        displayTitle = "gemini-3.5-flash",
        badgeLabel = "General Tasks",
        taskCategory = "Balanced Multi-Turn Tutoring",
        description = "Uses gemini-3.5-flash for general study questions, chapter explanations, and multi-turn Socratic dialogue."
    ),
    FAST_FLASH_LITE(
        apiModelId = "gemini-3.1-flash-lite-preview",
        fallbackModelId = "gemini-3.5-flash",
        displayTitle = "gemini-3.1-flash-lite",
        badgeLabel = "Fast Tasks",
        taskCategory = "Instant Definitions & Flashcards",
        description = "Uses gemini-3.1-flash-lite (gemini-3.1-flash-lite-preview) for ultra-fast formula lookups, quick definitions, and rapid cramming."
    )
}

enum class TutorRolePersona(
    val roleTitle: String,
    val shortBadge: String,
    val iconEmoji: String,
    val defaultSystemInstruction: String
) {
    SOCRATIC_PROFESSOR(
        roleTitle = "Socratic STEM Professor",
        shortBadge = "Socratic Role",
        iconEmoji = "🎓",
        defaultSystemInstruction = "You are a Socratic STEM Professor for EduGlobal. Maintain multi-turn context across the conversation thread, guide the student step-by-step through rigorous mathematical derivations using standard LaTeX (\$...\$ and \$\$...\$\$), and conclude with a thought-provoking follow-up question to verify mastery."
    ),
    BOARD_CHIEF_EXAMINER(
        roleTitle = "Board Chief Examiner",
        shortBadge = "Examiner Role",
        iconEmoji = "📋",
        defaultSystemInstruction = "You are a Pakistan Regional Board Chief Examiner (FBISE / BISE / CAIE). Structure every response according to official Student Learning Outcomes (SLOs), show exact mark distribution (Section B 4-Marks / Section C 8-Marks), highlight common examiner deductions, and write all equations in clean LaTeX."
    ),
    NUMERICAL_SOLVER(
        roleTitle = "Step-by-Step Numerical Solver",
        shortBadge = "Numerical Role",
        iconEmoji = "🧮",
        defaultSystemInstruction = "You are a Precision STEM Numerical & Equation Solver. Break down every problem into: (1) Given Data with SI Units, (2) Governing LaTeX Formula, (3) Step-by-Step Algebraic Substitution, and (4) Final Boxed Result with dimensional analysis."
    ),
    RAPID_REVISION_COACH(
        roleTitle = "Rapid Flashcard Coach",
        shortBadge = "Fast Coach Role",
        iconEmoji = "⚡",
        defaultSystemInstruction = "You are a High-Speed Exam Revision Coach. Deliver crisp, high-yield bullet points, key LaTeX formulas, memory mnemonics, and 60-second revision summaries tailored for last-minute board exam preparation."
    )
}

