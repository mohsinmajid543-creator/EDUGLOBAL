package com.example.data.auth

import android.util.Base64
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class JwtClaims(
    val jti: String,
    val sub: String,
    val firstName: String,
    val lastName: String,
    val phone: String,
    val board: String,
    val gradeLevel: String,
    val role: String,
    val authProvider: String,
    val issuedAtSeconds: Long,
    val expiresAtSeconds: Long
) {
    val fullName: String
        get() = "$firstName $lastName".trim()

    val isExpired: Boolean
        get() = (System.currentTimeMillis() / 1000L) >= expiresAtSeconds
}

object JwtAuthManager {
    private const val HMAC_ALGO = "HmacSHA256"
    private const val JWT_SIGNING_SECRET = "EduGlobal_JWT_2026_OctagonInc_VerifiedScholar_Secret_Key_92PK"
    private const val TOKEN_TTL_SECONDS = 24L * 60L * 60L // 24 hours

    /**
     * Validates strictly Pakistan 11-digit mobile number formats:
     * Accepts:
     * - "3XX XXXXXXX" or "3XXXXXXXXX" (10 digits starting with 3, paired with +92 prefix)
     * - "03XX XXXXXXX" or "03XXXXXXXXX" (11 digits starting with 03)
     * - "+92 3XX XXXXXXX" or "+923XXXXXXXXX"
     */
    fun normalizePakistanPhone(rawInput: String): String {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return when {
            digitsOnly.startsWith("923") && digitsOnly.length == 12 -> "+$digitsOnly"
            digitsOnly.startsWith("03") && digitsOnly.length == 11 -> "+92${digitsOnly.substring(1)}"
            digitsOnly.startsWith("3") && digitsOnly.length == 10 -> "+92$digitsOnly"
            else -> rawInput.trim()
        }
    }

    fun isValidPakistanMobile(rawInput: String): Boolean {
        val digitsOnly = rawInput.filter { it.isDigit() }
        return when {
            digitsOnly.startsWith("923") && digitsOnly.length == 12 -> true
            digitsOnly.startsWith("03") && digitsOnly.length == 11 -> true
            digitsOnly.startsWith("3") && digitsOnly.length == 10 -> true
            else -> false
        }
    }

    fun formatPakistanDisplayPhone(normalizedPhone: String): String {
        val digits = normalizedPhone.filter { it.isDigit() }
        val tenDigits = when {
            digits.startsWith("92") && digits.length == 12 -> digits.substring(2)
            digits.startsWith("0") && digits.length == 11 -> digits.substring(1)
            digits.length == 10 -> digits
            else -> return normalizedPhone
        }
        return "+92 ${tenDigits.substring(0, 3)} ${tenDigits.substring(3)}"
    }

    fun hashPassword(password: String, salt: String = "EduGlobalSalt2026"): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val hashBytes = digest.digest("$salt:$password".toByteArray(StandardCharsets.UTF_8))
        return hashBytes.joinToString("") { "%02x".format(it) }
    }

    /**
     * Generates a cryptographically signed RFC-7519 HS256 JWT token for verified users.
     */
    fun issueSignedJwt(
        email: String,
        firstName: String,
        lastName: String,
        phone: String,
        board: String,
        gradeLevel: String,
        role: String = "VERIFIED_SCHOLAR",
        authProvider: String = "EMAIL_JWT"
    ): String {
        val nowSeconds = System.currentTimeMillis() / 1000L
        val expSeconds = nowSeconds + TOKEN_TTL_SECONDS
        val jti = UUID.randomUUID().toString()

        val headerJson = JSONObject().apply {
            put("alg", "HS256")
            put("typ", "JWT")
            put("iss", "EduGlobal-Auth-Engine")
        }.toString()

        val payloadJson = JSONObject().apply {
            put("jti", jti)
            put("sub", email.trim().lowercase())
            put("firstName", firstName.trim())
            put("lastName", lastName.trim())
            put("phone", normalizePakistanPhone(phone))
            put("board", board)
            put("gradeLevel", gradeLevel)
            put("role", role)
            put("authProvider", authProvider)
            put("iat", nowSeconds)
            put("exp", expSeconds)
        }.toString()

        val encodedHeader = base64UrlEncode(headerJson.toByteArray(StandardCharsets.UTF_8))
        val encodedPayload = base64UrlEncode(payloadJson.toByteArray(StandardCharsets.UTF_8))
        val signingInput = "$encodedHeader.$encodedPayload"
        val signature = signHmacSha256(signingInput)

        return "$signingInput.$signature"
    }

    /**
     * Verifies the HMAC-SHA256 signature and expiration of a JWT token, returning decoded claims if valid.
     */
    fun verifyAndDecodeJwt(token: String): JwtClaims? {
        if (token.isBlank()) return null
        val parts = token.split(".")
        if (parts.size != 3) return null

        return try {
            val signingInput = "${parts[0]}.${parts[1]}"
            val expectedSig = signHmacSha256(signingInput)
            if (expectedSig != parts[2]) {
                return null // Invalid signature
            }

            val payloadString = String(base64UrlDecode(parts[1]), StandardCharsets.UTF_8)
            val json = JSONObject(payloadString)
            val claims = JwtClaims(
                jti = json.optString("jti", ""),
                sub = json.optString("sub", ""),
                firstName = json.optString("firstName", "Scholar"),
                lastName = json.optString("lastName", ""),
                phone = json.optString("phone", "+923001234567"),
                board = json.optString("board", "Federal Board (FBISE)"),
                gradeLevel = json.optString("gradeLevel", "Class 11 / FSc Part 1"),
                role = json.optString("role", "VERIFIED_SCHOLAR"),
                authProvider = json.optString("authProvider", "EMAIL_JWT"),
                issuedAtSeconds = json.optLong("iat", 0L),
                expiresAtSeconds = json.optLong("exp", 0L)
            )
            if (claims.isExpired) null else claims
        } catch (e: Exception) {
            null
        }
    }

    fun prettyPrintPayload(token: String): String {
        val parts = token.split(".")
        if (parts.size != 3) return "{ \"error\": \"Invalid JWT structure\" }"
        return try {
            val payloadString = String(base64UrlDecode(parts[1]), StandardCharsets.UTF_8)
            JSONObject(payloadString).toString(2)
        } catch (e: Exception) {
            "{ \"error\": \"Unable to decode payload\" }"
        }
    }

    private fun signHmacSha256(data: String): String {
        val mac = Mac.getInstance(HMAC_ALGO)
        val secretKey = SecretKeySpec(JWT_SIGNING_SECRET.toByteArray(StandardCharsets.UTF_8), HMAC_ALGO)
        mac.init(secretKey)
        val rawHmac = mac.doFinal(data.toByteArray(StandardCharsets.UTF_8))
        return base64UrlEncode(rawHmac)
    }

    private fun base64UrlEncode(bytes: ByteArray): String {
        return Base64.encodeToString(
            bytes,
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
    }

    private fun base64UrlDecode(encoded: String): ByteArray {
        return Base64.decode(
            encoded,
            Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING
        )
    }
}
