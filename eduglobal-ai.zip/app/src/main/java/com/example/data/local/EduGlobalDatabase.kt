package com.example.data.local

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

data class UserEntity(
    val email: String,
    val firstName: String,
    val lastName: String,
    val phone: String,
    val passwordHash: String,
    val geminiApiKey: String,
    val selectedBoard: String,
    val gradeLevel: String,
    val accountType: String = "Pro Scholar Account",
    val studyHours: Float = 28.5f,
    val quizzesCompleted: Int = 16,
    val quizAvgScore: Int = 92,
    val bestQuizScore: Int = 100,
    val extremeQuizzesCompleted: Int = 1,
    val savedTopicsCount: Int = 42,
    val streakDays: Int = 9,
    val scholarXp: Int = 860,
    val isVerified: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class SessionEntity(
    val sessionId: Int = 1,
    val userEmail: String,
    val jwtToken: String,
    val geminiApiKey: String,
    val authProvider: String,
    val issuedAt: Long,
    val expiresAt: Long
)

data class SubjectEntity(
    val name: String,
    val category: String,
    val progressPercent: Int,
    val isCustom: Boolean = false
)

data class ChatMessageEntity(
    val id: Long = 0,
    val userEmail: String,
    val subject: String,
    val board: String,
    val isUser: Boolean,
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)

data class QuizAttemptEntity(
    val id: Long = 0,
    val userEmail: String,
    val subject: String,
    val topic: String,
    val board: String,
    val difficulty: String,
    val totalQuestions: Int,
    val correctAnswers: Int,
    val scorePercent: Int,
    val xpEarned: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class SavedPaperEntity(
    val id: Long = 0,
    val subject: String,
    val topic: String,
    val board: String,
    val gradeLevel: String,
    val markdownContent: String,
    val timestamp: Long = System.currentTimeMillis()
)

interface EduGlobalDao {
    suspend fun getUserByEmail(email: String): UserEntity?
    fun observeUserByEmail(email: String): Flow<UserEntity?>
    suspend fun upsertUser(user: UserEntity)
    suspend fun updateUser(user: UserEntity)

    fun observeActiveSession(): Flow<SessionEntity?>
    suspend fun getActiveSession(): SessionEntity?
    suspend fun saveSession(session: SessionEntity)
    suspend fun clearSession()

    fun observeAllSubjects(): Flow<List<SubjectEntity>>
    suspend fun getSubjectCount(): Int
    suspend fun insertSubject(subject: SubjectEntity)
    suspend fun insertSubjects(subjects: List<SubjectEntity>)

    fun observeChatMessages(email: String): Flow<List<ChatMessageEntity>>
    suspend fun insertChatMessage(message: ChatMessageEntity)
    suspend fun clearChatMessages(email: String)

    fun observeQuizAttempts(email: String): Flow<List<QuizAttemptEntity>>
    suspend fun insertQuizAttempt(attempt: QuizAttemptEntity)

    fun observeSavedPapers(): Flow<List<SavedPaperEntity>>
    suspend fun insertSavedPaper(paper: SavedPaperEntity)
}

class EduGlobalDatabase private constructor(context: Context) :
    SQLiteOpenHelper(context.applicationContext, "eduglobal_academic_db", null, 1),
    EduGlobalDao {

    private val usersState = MutableStateFlow<Map<String, UserEntity>>(emptyMap())
    private val sessionState = MutableStateFlow<SessionEntity?>(null)
    private val subjectsState = MutableStateFlow<List<SubjectEntity>>(emptyList())
    private val chatMessagesState = MutableStateFlow<List<ChatMessageEntity>>(emptyList())
    private val quizAttemptsState = MutableStateFlow<List<QuizAttemptEntity>>(emptyList())
    private val savedPapersState = MutableStateFlow<List<SavedPaperEntity>>(emptyList())

    init {
        reloadAllFromDisk()
    }

    fun dao(): EduGlobalDao = this

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS verified_users (
                email TEXT PRIMARY KEY,
                firstName TEXT NOT NULL,
                lastName TEXT NOT NULL,
                phone TEXT NOT NULL,
                passwordHash TEXT NOT NULL,
                geminiApiKey TEXT NOT NULL,
                selectedBoard TEXT NOT NULL,
                gradeLevel TEXT NOT NULL,
                accountType TEXT NOT NULL,
                studyHours REAL NOT NULL,
                quizzesCompleted INTEGER NOT NULL,
                quizAvgScore INTEGER NOT NULL,
                bestQuizScore INTEGER NOT NULL,
                extremeQuizzesCompleted INTEGER NOT NULL,
                savedTopicsCount INTEGER NOT NULL,
                streakDays INTEGER NOT NULL,
                scholarXp INTEGER NOT NULL,
                isVerified INTEGER NOT NULL,
                createdAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS jwt_sessions (
                sessionId INTEGER PRIMARY KEY,
                userEmail TEXT NOT NULL,
                jwtToken TEXT NOT NULL,
                geminiApiKey TEXT NOT NULL,
                authProvider TEXT NOT NULL,
                issuedAt INTEGER NOT NULL,
                expiresAt INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS custom_subjects (
                name TEXT PRIMARY KEY,
                category TEXT NOT NULL,
                progressPercent INTEGER NOT NULL,
                isCustom INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS chat_messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userEmail TEXT NOT NULL,
                subject TEXT NOT NULL,
                board TEXT NOT NULL,
                isUser INTEGER NOT NULL,
                content TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS quiz_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                userEmail TEXT NOT NULL,
                subject TEXT NOT NULL,
                topic TEXT NOT NULL,
                board TEXT NOT NULL,
                difficulty TEXT NOT NULL,
                totalQuestions INTEGER NOT NULL,
                correctAnswers INTEGER NOT NULL,
                scorePercent INTEGER NOT NULL,
                xpEarned INTEGER NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS saved_papers (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                subject TEXT NOT NULL,
                topic TEXT NOT NULL,
                board TEXT NOT NULL,
                gradeLevel TEXT NOT NULL,
                markdownContent TEXT NOT NULL,
                timestamp INTEGER NOT NULL
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        onCreate(db)
    }

    @Synchronized
    private fun reloadAllFromDisk() {
        val db = writableDatabase

        // Load users
        val userMap = mutableMapOf<String, UserEntity>()
        db.rawQuery("SELECT * FROM verified_users", null).use { c ->
            while (c.moveToNext()) {
                val u = UserEntity(
                    email = c.getString(c.getColumnIndexOrThrow("email")),
                    firstName = c.getString(c.getColumnIndexOrThrow("firstName")),
                    lastName = c.getString(c.getColumnIndexOrThrow("lastName")),
                    phone = c.getString(c.getColumnIndexOrThrow("phone")),
                    passwordHash = c.getString(c.getColumnIndexOrThrow("passwordHash")),
                    geminiApiKey = c.getString(c.getColumnIndexOrThrow("geminiApiKey")),
                    selectedBoard = c.getString(c.getColumnIndexOrThrow("selectedBoard")),
                    gradeLevel = c.getString(c.getColumnIndexOrThrow("gradeLevel")),
                    accountType = c.getString(c.getColumnIndexOrThrow("accountType")),
                    studyHours = c.getFloat(c.getColumnIndexOrThrow("studyHours")),
                    quizzesCompleted = c.getInt(c.getColumnIndexOrThrow("quizzesCompleted")),
                    quizAvgScore = c.getInt(c.getColumnIndexOrThrow("quizAvgScore")),
                    bestQuizScore = c.getInt(c.getColumnIndexOrThrow("bestQuizScore")),
                    extremeQuizzesCompleted = c.getInt(c.getColumnIndexOrThrow("extremeQuizzesCompleted")),
                    savedTopicsCount = c.getInt(c.getColumnIndexOrThrow("savedTopicsCount")),
                    streakDays = c.getInt(c.getColumnIndexOrThrow("streakDays")),
                    scholarXp = c.getInt(c.getColumnIndexOrThrow("scholarXp")),
                    isVerified = c.getInt(c.getColumnIndexOrThrow("isVerified")) == 1,
                    createdAt = c.getLong(c.getColumnIndexOrThrow("createdAt"))
                )
                userMap[u.email] = u
            }
        }
        usersState.value = userMap

        // Load active session
        var activeSess: SessionEntity? = null
        db.rawQuery("SELECT * FROM jwt_sessions WHERE sessionId = 1 LIMIT 1", null).use { c ->
            if (c.moveToFirst()) {
                activeSess = SessionEntity(
                    sessionId = c.getInt(c.getColumnIndexOrThrow("sessionId")),
                    userEmail = c.getString(c.getColumnIndexOrThrow("userEmail")),
                    jwtToken = c.getString(c.getColumnIndexOrThrow("jwtToken")),
                    geminiApiKey = c.getString(c.getColumnIndexOrThrow("geminiApiKey")),
                    authProvider = c.getString(c.getColumnIndexOrThrow("authProvider")),
                    issuedAt = c.getLong(c.getColumnIndexOrThrow("issuedAt")),
                    expiresAt = c.getLong(c.getColumnIndexOrThrow("expiresAt"))
                )
            }
        }
        sessionState.value = activeSess

        // Load subjects
        val subjList = mutableListOf<SubjectEntity>()
        db.rawQuery("SELECT * FROM custom_subjects ORDER BY isCustom DESC, name ASC", null).use { c ->
            while (c.moveToNext()) {
                subjList.add(
                    SubjectEntity(
                        name = c.getString(c.getColumnIndexOrThrow("name")),
                        category = c.getString(c.getColumnIndexOrThrow("category")),
                        progressPercent = c.getInt(c.getColumnIndexOrThrow("progressPercent")),
                        isCustom = c.getInt(c.getColumnIndexOrThrow("isCustom")) == 1
                    )
                )
            }
        }
        subjectsState.value = subjList

        // Load chat messages
        val chatList = mutableListOf<ChatMessageEntity>()
        db.rawQuery("SELECT * FROM chat_messages ORDER BY timestamp ASC", null).use { c ->
            while (c.moveToNext()) {
                chatList.add(
                    ChatMessageEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        userEmail = c.getString(c.getColumnIndexOrThrow("userEmail")),
                        subject = c.getString(c.getColumnIndexOrThrow("subject")),
                        board = c.getString(c.getColumnIndexOrThrow("board")),
                        isUser = c.getInt(c.getColumnIndexOrThrow("isUser")) == 1,
                        content = c.getString(c.getColumnIndexOrThrow("content")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        chatMessagesState.value = chatList

        // Load quiz attempts
        val attemptList = mutableListOf<QuizAttemptEntity>()
        db.rawQuery("SELECT * FROM quiz_attempts ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                attemptList.add(
                    QuizAttemptEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        userEmail = c.getString(c.getColumnIndexOrThrow("userEmail")),
                        subject = c.getString(c.getColumnIndexOrThrow("subject")),
                        topic = c.getString(c.getColumnIndexOrThrow("topic")),
                        board = c.getString(c.getColumnIndexOrThrow("board")),
                        difficulty = c.getString(c.getColumnIndexOrThrow("difficulty")),
                        totalQuestions = c.getInt(c.getColumnIndexOrThrow("totalQuestions")),
                        correctAnswers = c.getInt(c.getColumnIndexOrThrow("correctAnswers")),
                        scorePercent = c.getInt(c.getColumnIndexOrThrow("scorePercent")),
                        xpEarned = c.getInt(c.getColumnIndexOrThrow("xpEarned")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        quizAttemptsState.value = attemptList

        // Load saved papers
        val paperList = mutableListOf<SavedPaperEntity>()
        db.rawQuery("SELECT * FROM saved_papers ORDER BY timestamp DESC", null).use { c ->
            while (c.moveToNext()) {
                paperList.add(
                    SavedPaperEntity(
                        id = c.getLong(c.getColumnIndexOrThrow("id")),
                        subject = c.getString(c.getColumnIndexOrThrow("subject")),
                        topic = c.getString(c.getColumnIndexOrThrow("topic")),
                        board = c.getString(c.getColumnIndexOrThrow("board")),
                        gradeLevel = c.getString(c.getColumnIndexOrThrow("gradeLevel")),
                        markdownContent = c.getString(c.getColumnIndexOrThrow("markdownContent")),
                        timestamp = c.getLong(c.getColumnIndexOrThrow("timestamp"))
                    )
                )
            }
        }
        savedPapersState.value = paperList
    }

    override suspend fun getUserByEmail(email: String): UserEntity? = withContext(Dispatchers.IO) {
        usersState.value[email]
    }

    override fun observeUserByEmail(email: String): Flow<UserEntity?> =
        usersState.map { it[email] }

    override suspend fun upsertUser(user: UserEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                put("email", user.email)
                put("firstName", user.firstName)
                put("lastName", user.lastName)
                put("phone", user.phone)
                put("passwordHash", user.passwordHash)
                put("geminiApiKey", user.geminiApiKey)
                put("selectedBoard", user.selectedBoard)
                put("gradeLevel", user.gradeLevel)
                put("accountType", user.accountType)
                put("studyHours", user.studyHours)
                put("quizzesCompleted", user.quizzesCompleted)
                put("quizAvgScore", user.quizAvgScore)
                put("bestQuizScore", user.bestQuizScore)
                put("extremeQuizzesCompleted", user.extremeQuizzesCompleted)
                put("savedTopicsCount", user.savedTopicsCount)
                put("streakDays", user.streakDays)
                put("scholarXp", user.scholarXp)
                put("isVerified", if (user.isVerified) 1 else 0)
                put("createdAt", user.createdAt)
            }
            writableDatabase.insertWithOnConflict(
                "verified_users",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    override suspend fun updateUser(user: UserEntity) = upsertUser(user)

    override fun observeActiveSession(): Flow<SessionEntity?> = sessionState

    override suspend fun getActiveSession(): SessionEntity? = withContext(Dispatchers.IO) {
        sessionState.value
    }

    override suspend fun saveSession(session: SessionEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                put("sessionId", session.sessionId)
                put("userEmail", session.userEmail)
                put("jwtToken", session.jwtToken)
                put("geminiApiKey", session.geminiApiKey)
                put("authProvider", session.authProvider)
                put("issuedAt", session.issuedAt)
                put("expiresAt", session.expiresAt)
            }
            writableDatabase.insertWithOnConflict(
                "jwt_sessions",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    override suspend fun clearSession() = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            writableDatabase.delete("jwt_sessions", null, null)
            reloadAllFromDisk()
        }
    }

    override fun observeAllSubjects(): Flow<List<SubjectEntity>> = subjectsState

    override suspend fun getSubjectCount(): Int = withContext(Dispatchers.IO) {
        subjectsState.value.size
    }

    override suspend fun insertSubject(subject: SubjectEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                put("name", subject.name)
                put("category", subject.category)
                put("progressPercent", subject.progressPercent)
                put("isCustom", if (subject.isCustom) 1 else 0)
            }
            writableDatabase.insertWithOnConflict(
                "custom_subjects",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    override suspend fun insertSubjects(subjects: List<SubjectEntity>) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            writableDatabase.beginTransaction()
            try {
                for (subject in subjects) {
                    val cv = ContentValues().apply {
                        put("name", subject.name)
                        put("category", subject.category)
                        put("progressPercent", subject.progressPercent)
                        put("isCustom", if (subject.isCustom) 1 else 0)
                    }
                    writableDatabase.insertWithOnConflict(
                        "custom_subjects",
                        null,
                        cv,
                        SQLiteDatabase.CONFLICT_REPLACE
                    )
                }
                writableDatabase.setTransactionSuccessful()
            } finally {
                writableDatabase.endTransaction()
            }
            reloadAllFromDisk()
        }
    }

    override fun observeChatMessages(email: String): Flow<List<ChatMessageEntity>> =
        chatMessagesState.map { list -> list.filter { it.userEmail == email } }

    override suspend fun insertChatMessage(message: ChatMessageEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                if (message.id != 0L) put("id", message.id)
                put("userEmail", message.userEmail)
                put("subject", message.subject)
                put("board", message.board)
                put("isUser", if (message.isUser) 1 else 0)
                put("content", message.content)
                put("timestamp", message.timestamp)
            }
            writableDatabase.insertWithOnConflict(
                "chat_messages",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    override suspend fun clearChatMessages(email: String) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            writableDatabase.delete("chat_messages", "userEmail = ?", arrayOf(email))
            reloadAllFromDisk()
        }
    }

    override fun observeQuizAttempts(email: String): Flow<List<QuizAttemptEntity>> =
        quizAttemptsState.map { list -> list.filter { it.userEmail == email } }

    override suspend fun insertQuizAttempt(attempt: QuizAttemptEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                put("userEmail", attempt.userEmail)
                put("subject", attempt.subject)
                put("topic", attempt.topic)
                put("board", attempt.board)
                put("difficulty", attempt.difficulty)
                put("totalQuestions", attempt.totalQuestions)
                put("correctAnswers", attempt.correctAnswers)
                put("scorePercent", attempt.scorePercent)
                put("xpEarned", attempt.xpEarned)
                put("timestamp", attempt.timestamp)
            }
            writableDatabase.insertWithOnConflict(
                "quiz_attempts",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    override fun observeSavedPapers(): Flow<List<SavedPaperEntity>> = savedPapersState

    override suspend fun insertSavedPaper(paper: SavedPaperEntity) = withContext(Dispatchers.IO) {
        synchronized(this@EduGlobalDatabase) {
            val cv = ContentValues().apply {
                put("subject", paper.subject)
                put("topic", paper.topic)
                put("board", paper.board)
                put("gradeLevel", paper.gradeLevel)
                put("markdownContent", paper.markdownContent)
                put("timestamp", paper.timestamp)
            }
            writableDatabase.insertWithOnConflict(
                "saved_papers",
                null,
                cv,
                SQLiteDatabase.CONFLICT_REPLACE
            )
            reloadAllFromDisk()
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: EduGlobalDatabase? = null

        fun getInstance(context: Context): EduGlobalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = EduGlobalDatabase(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
