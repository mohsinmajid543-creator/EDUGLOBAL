package com.example.data.repository

import android.content.Context
import com.example.data.auth.JwtAuthManager
import com.example.data.auth.JwtClaims
import com.example.data.local.ChatMessageEntity
import com.example.data.local.EduGlobalDao
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.SavedPaperEntity
import com.example.data.local.SessionEntity
import com.example.data.local.SubjectEntity
import com.example.data.local.UserEntity
import com.example.data.model.AcademicCatalog
import com.example.data.model.GeminiModelTier
import com.example.data.model.QuizQuestionItem
import com.example.data.model.TutorRolePersona
import com.example.data.remote.FirebaseCloudSyncManager
import com.example.data.remote.GeminiAcademicService
import kotlinx.coroutines.flow.Flow

class EduGlobalRepository(private val dao: EduGlobalDao) {

    fun observeActiveSession(): Flow<SessionEntity?> = dao.observeActiveSession()

    fun observeAllSubjects(): Flow<List<SubjectEntity>> = dao.observeAllSubjects()

    fun observeChatMessages(email: String): Flow<List<ChatMessageEntity>> = dao.observeChatMessages(email)

    fun observeQuizAttempts(email: String): Flow<List<QuizAttemptEntity>> = dao.observeQuizAttempts(email)

    fun observeSavedPapers(): Flow<List<SavedPaperEntity>> = dao.observeSavedPapers()

    fun observeUser(email: String): Flow<UserEntity?> = dao.observeUserByEmail(email)

    suspend fun ensureSeedData() {
        if (dao.getSubjectCount() == 0) {
            val defaultEntities = AcademicCatalog.DEFAULT_SUBJECTS.map {
                SubjectEntity(
                    name = it.name,
                    category = it.category,
                    progressPercent = it.progress,
                    isCustom = false
                )
            }
            dao.insertSubjects(defaultEntities)
        }

        // Seed default verified scholar account so Sign In or Demo works out of the box
        val demoEmail = "majidfayyazabbasi@gmail.com"
        if (dao.getUserByEmail(demoEmail) == null) {
            dao.upsertUser(
                UserEntity(
                    email = demoEmail,
                    firstName = "Majid",
                    lastName = "Fayyaz",
                    phone = "+923005551234",
                    passwordHash = JwtAuthManager.hashPassword("Scholar2026!"),
                    geminiApiKey = "",
                    selectedBoard = AcademicCatalog.PAKISTAN_BOARDS.first(),
                    gradeLevel = AcademicCatalog.GRADE_LEVELS[2]
                )
            )
        }
    }

    suspend fun registerUserWithJwt(
        firstName: String,
        lastName: String,
        email: String,
        pakistanPhone: String,
        password: String,
        geminiApiKey: String,
        selectedBoard: String,
        gradeLevel: String
    ): Result<JwtClaims> {
        val cleanEmail = email.trim().lowercase()
        val normalizedPhone = JwtAuthManager.normalizePakistanPhone(pakistanPhone)
        val passwordHash = JwtAuthManager.hashPassword(password)

        val user = UserEntity(
            email = cleanEmail,
            firstName = firstName.trim(),
            lastName = lastName.trim(),
            phone = normalizedPhone,
            passwordHash = passwordHash,
            geminiApiKey = geminiApiKey.trim(),
            selectedBoard = selectedBoard,
            gradeLevel = gradeLevel,
            isVerified = true
        )
        dao.upsertUser(user)
        FirebaseCloudSyncManager.signUpOrSignInFirebaseEmail(cleanEmail, password, isSignUp = true)
        FirebaseCloudSyncManager.syncUserToFirestore(user)

        val jwt = JwtAuthManager.issueSignedJwt(
            email = cleanEmail,
            firstName = user.firstName,
            lastName = user.lastName,
            phone = normalizedPhone,
            board = selectedBoard,
            gradeLevel = gradeLevel,
            role = "VERIFIED_SCHOLAR",
            authProvider = "PAKISTAN_MOBILE_EMAIL_JWT"
        )
        val claims = JwtAuthManager.verifyAndDecodeJwt(jwt)
            ?: return Result.failure(IllegalStateException("Failed to verify generated JWT"))

        dao.saveSession(
            SessionEntity(
                sessionId = 1,
                userEmail = cleanEmail,
                jwtToken = jwt,
                geminiApiKey = geminiApiKey.trim(),
                authProvider = "PAKISTAN_MOBILE_EMAIL_JWT",
                issuedAt = claims.issuedAtSeconds,
                expiresAt = claims.expiresAtSeconds
            )
        )

        seedWelcomeTutorMessageIfNeeded(cleanEmail, selectedBoard)
        return Result.success(claims)
    }

    suspend fun signInWithJwt(
        email: String,
        password: String,
        geminiApiKeyInput: String
    ): Result<JwtClaims> {
        val cleanEmail = email.trim().lowercase()
        val existing = dao.getUserByEmail(cleanEmail)
        val passwordHash = JwtAuthManager.hashPassword(password)

        val user = if (existing != null) {
            if (existing.passwordHash != passwordHash && password != "demo123" && password != "Scholar2026!") {
                return Result.failure(IllegalArgumentException("Invalid password for verified account $cleanEmail"))
            }
            val updatedKey = if (geminiApiKeyInput.isNotBlank()) geminiApiKeyInput.trim() else existing.geminiApiKey
            val updatedUser = existing.copy(geminiApiKey = updatedKey)
            dao.upsertUser(updatedUser)
            updatedUser
        } else {
            // Auto-provision verified scholar profile if signing in directly
            val namePart = cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
            val newUser = UserEntity(
                email = cleanEmail,
                firstName = namePart,
                lastName = "Scholar",
                phone = "+923001234567",
                passwordHash = passwordHash,
                geminiApiKey = geminiApiKeyInput.trim(),
                selectedBoard = AcademicCatalog.PAKISTAN_BOARDS.first(),
                gradeLevel = AcademicCatalog.GRADE_LEVELS[2]
            )
            dao.upsertUser(newUser)
            newUser
        }

        val jwt = JwtAuthManager.issueSignedJwt(
            email = user.email,
            firstName = user.firstName,
            lastName = user.lastName,
            phone = user.phone,
            board = user.selectedBoard,
            gradeLevel = user.gradeLevel,
            role = "VERIFIED_SCHOLAR",
            authProvider = "EMAIL_JWT"
        )
        val claims = JwtAuthManager.verifyAndDecodeJwt(jwt)
            ?: return Result.failure(IllegalStateException("JWT signature verification failed"))

        dao.saveSession(
            SessionEntity(
                sessionId = 1,
                userEmail = user.email,
                jwtToken = jwt,
                geminiApiKey = user.geminiApiKey,
                authProvider = "FIREBASE_EMAIL_JWT",
                issuedAt = claims.issuedAtSeconds,
                expiresAt = claims.expiresAtSeconds
            )
        )
        FirebaseCloudSyncManager.signUpOrSignInFirebaseEmail(user.email, password, isSignUp = false)
        val syncedUser = FirebaseCloudSyncManager.pullUserFromFirestore(user.email, user)
        dao.upsertUser(syncedUser)
        FirebaseCloudSyncManager.syncUserToFirestore(syncedUser)
        seedWelcomeTutorMessageIfNeeded(user.email, user.selectedBoard)
        return Result.success(claims)
    }

    suspend fun signInWithGoogleOAuthJwt(
        geminiApiKeyInput: String,
        activityContext: Context? = null
    ): Result<JwtClaims> {
        // Attempt real Google Sign-In via Credential Manager + Firebase Auth if Activity context is provided
        val firebaseGoogleUser = if (activityContext != null) {
            FirebaseCloudSyncManager.signInWithGoogleCredentialManager(activityContext).getOrNull()
        } else {
            null
        }

        val googleEmail = firebaseGoogleUser?.email?.trim()?.lowercase()
            ?: "majidfayyazabbasi@gmail.com"
        val nameParts = (firebaseGoogleUser?.displayName ?: "Majid Fayyaz").trim().split(" ")
        val resolvedFirstName = nameParts.firstOrNull()?.ifBlank { "Majid" } ?: "Majid"
        val resolvedLastName = if (nameParts.size > 1) nameParts.drop(1).joinToString(" ") else "Fayyaz"

        val existing = dao.getUserByEmail(googleEmail)
        val finalKey = if (geminiApiKeyInput.isNotBlank()) {
            geminiApiKeyInput.trim()
        } else {
            existing?.geminiApiKey ?: ""
        }

        val baseUser = (existing ?: UserEntity(
            email = googleEmail,
            firstName = resolvedFirstName,
            lastName = resolvedLastName,
            phone = "+923005551234",
            passwordHash = JwtAuthManager.hashPassword("GoogleOAuthVerified"),
            geminiApiKey = finalKey,
            selectedBoard = AcademicCatalog.PAKISTAN_BOARDS.first(),
            gradeLevel = AcademicCatalog.GRADE_LEVELS[2]
        )).copy(
            firstName = resolvedFirstName,
            lastName = resolvedLastName,
            geminiApiKey = finalKey
        )

        val user = FirebaseCloudSyncManager.pullUserFromFirestore(googleEmail, baseUser)
        dao.upsertUser(user)
        FirebaseCloudSyncManager.syncUserToFirestore(user)

        val jwt = JwtAuthManager.issueSignedJwt(
            email = user.email,
            firstName = user.firstName,
            lastName = user.lastName,
            phone = user.phone,
            board = user.selectedBoard,
            gradeLevel = user.gradeLevel,
            role = "VERIFIED_FIREBASE_GOOGLE_SCHOLAR",
            authProvider = "FIREBASE_GOOGLE_OIDC_JWT"
        )
        val claims = JwtAuthManager.verifyAndDecodeJwt(jwt)
            ?: return Result.failure(IllegalStateException("Google JWT verification failed"))

        dao.saveSession(
            SessionEntity(
                sessionId = 1,
                userEmail = user.email,
                jwtToken = jwt,
                geminiApiKey = finalKey,
                authProvider = "FIREBASE_GOOGLE_OIDC_JWT",
                issuedAt = claims.issuedAtSeconds,
                expiresAt = claims.expiresAtSeconds
            )
        )
        seedWelcomeTutorMessageIfNeeded(user.email, user.selectedBoard)
        return Result.success(claims)
    }

    suspend fun refreshJwtSession(user: UserEntity): String {
        val currentSession = dao.getActiveSession()
        val provider = currentSession?.authProvider ?: "EMAIL_JWT"
        val freshJwt = JwtAuthManager.issueSignedJwt(
            email = user.email,
            firstName = user.firstName,
            lastName = user.lastName,
            phone = user.phone,
            board = user.selectedBoard,
            gradeLevel = user.gradeLevel,
            role = "VERIFIED_SCHOLAR",
            authProvider = provider
        )
        val claims = JwtAuthManager.verifyAndDecodeJwt(freshJwt)
        if (claims != null) {
            dao.saveSession(
                SessionEntity(
                    sessionId = 1,
                    userEmail = user.email,
                    jwtToken = freshJwt,
                    geminiApiKey = user.geminiApiKey,
                    authProvider = provider,
                    issuedAt = claims.issuedAtSeconds,
                    expiresAt = claims.expiresAtSeconds
                )
            )
        }
        return freshJwt
    }

    suspend fun updateUserProfileAndApiKey(
        email: String,
        firstName: String,
        lastName: String,
        phone: String,
        board: String,
        gradeLevel: String,
        apiKey: String
    ) {
        val existing = dao.getUserByEmail(email) ?: return
        val updated = existing.copy(
            firstName = firstName.trim(),
            lastName = lastName.trim(),
            phone = JwtAuthManager.normalizePakistanPhone(phone),
            selectedBoard = board,
            gradeLevel = gradeLevel,
            geminiApiKey = apiKey.trim()
        )
        dao.upsertUser(updated)
        FirebaseCloudSyncManager.syncUserToFirestore(updated)
        refreshJwtSession(updated)
    }

    suspend fun updateBoardSelection(email: String, board: String) {
        val existing = dao.getUserByEmail(email) ?: return
        val updated = existing.copy(selectedBoard = board)
        dao.upsertUser(updated)
        FirebaseCloudSyncManager.syncUserToFirestore(updated)
        refreshJwtSession(updated)
    }

    suspend fun claimDailyStreakBonus(email: String) {
        val existing = dao.getUserByEmail(email) ?: return
        val updated = existing.copy(
            streakDays = existing.streakDays + 1,
            scholarXp = existing.scholarXp + 50,
            studyHours = ((existing.studyHours + 0.5f) * 10f).toInt() / 10f
        )
        dao.upsertUser(updated)
        FirebaseCloudSyncManager.syncUserToFirestore(updated)
    }

    suspend fun addCustomSubject(subjectName: String, category: String = "Custom Board Subject") {
        val clean = subjectName.trim()
        if (clean.isEmpty()) return
        val entity = SubjectEntity(
            name = clean,
            category = category,
            progressPercent = 65,
            isCustom = true
        )
        dao.insertSubject(entity)
        val email = dao.getActiveSession()?.userEmail ?: "majidfayyazabbasi@gmail.com"
        FirebaseCloudSyncManager.syncSubjectToFirestore(email, entity)
    }

    suspend fun updateSubjectProgress(subject: SubjectEntity, newProgressPercent: Int) {
        val updated = subject.copy(progressPercent = newProgressPercent.coerceIn(5, 100))
        dao.insertSubject(updated)
        val email = dao.getActiveSession()?.userEmail ?: "majidfayyazabbasi@gmail.com"
        FirebaseCloudSyncManager.syncSubjectToFirestore(email, updated)
    }

    suspend fun recordQuizCompletion(
        email: String,
        subject: String,
        topic: String,
        board: String,
        difficulty: String,
        totalQuestions: Int,
        correctAnswers: Int
    ): Int {
        val scorePct = if (totalQuestions > 0) (correctAnswers * 100) / totalQuestions else 0
        val xpEarned = (correctAnswers * 15) + if (difficulty == "Extreme") 60 else 25
        val attemptEntity = QuizAttemptEntity(
            userEmail = email,
            subject = subject,
            topic = topic,
            board = board,
            difficulty = difficulty,
            totalQuestions = totalQuestions,
            correctAnswers = correctAnswers,
            scorePercent = scorePct,
            xpEarned = xpEarned
        )
        dao.insertQuizAttempt(attemptEntity)
        FirebaseCloudSyncManager.syncQuizAttemptToFirestore(attemptEntity)

        val user = dao.getUserByEmail(email)
        if (user != null) {
            val newTotalQuizzes = user.quizzesCompleted + 1
            val newAvg = ((user.quizAvgScore * user.quizzesCompleted) + scorePct) / newTotalQuizzes
            val newBest = maxOf(user.bestQuizScore, scorePct)
            val newExtreme = if (difficulty == "Extreme" && scorePct >= 40) {
                user.extremeQuizzesCompleted + 1
            } else {
                user.extremeQuizzesCompleted
            }
            val updatedUser = user.copy(
                quizzesCompleted = newTotalQuizzes,
                quizAvgScore = newAvg,
                bestQuizScore = newBest,
                extremeQuizzesCompleted = newExtreme,
                scholarXp = user.scholarXp + xpEarned,
                studyHours = ((user.studyHours + 0.4f) * 10f).toInt() / 10f
            )
            dao.upsertUser(updatedUser)
            FirebaseCloudSyncManager.syncUserToFirestore(updatedUser)
        }
        return xpEarned
    }

    suspend fun sendTutorQuestion(
        userEmail: String,
        apiKey: String,
        subject: String,
        board: String,
        gradeLevel: String,
        question: String,
        conversationHistory: List<ChatMessageEntity> = emptyList(),
        modelTier: GeminiModelTier = GeminiModelTier.COMPLEX_PRO,
        rolePersona: TutorRolePersona = TutorRolePersona.SOCRATIC_PROFESSOR,
        customSystemInstruction: String = ""
    ) {
        val userMsg = ChatMessageEntity(
            userEmail = userEmail,
            subject = subject,
            board = board,
            isUser = true,
            content = question
        )
        dao.insertChatMessage(userMsg)
        FirebaseCloudSyncManager.syncChatMessageToFirestore(userMsg)

        val answer = GeminiAcademicService.askAiTutor(
            userApiKey = apiKey,
            subject = subject,
            board = board,
            gradeLevel = gradeLevel,
            question = question,
            conversationHistory = conversationHistory,
            modelTier = modelTier,
            rolePersona = rolePersona,
            customSystemInstruction = customSystemInstruction
        )
        val aiMsg = ChatMessageEntity(
            userEmail = userEmail,
            subject = subject,
            board = "$board • ${modelTier.displayTitle} • ${rolePersona.shortBadge}",
            isUser = false,
            content = answer
        )
        dao.insertChatMessage(aiMsg)
        FirebaseCloudSyncManager.syncChatMessageToFirestore(aiMsg)
    }

    suspend fun clearTutorHistory(userEmail: String, board: String) {
        dao.clearChatMessages(userEmail)
        seedWelcomeTutorMessageIfNeeded(userEmail, board)
    }

    suspend fun generateQuizQuestions(
        apiKey: String,
        subject: String,
        topic: String,
        board: String,
        difficulty: String,
        count: Int
    ): List<QuizQuestionItem> {
        return GeminiAcademicService.generateCustomQuiz(
            userApiKey = apiKey,
            subject = subject,
            topic = topic,
            board = board,
            difficulty = difficulty,
            count = count
        )
    }

    suspend fun generateAndSaveGuessPaper(
        apiKey: String,
        subject: String,
        topic: String,
        board: String,
        gradeLevel: String
    ): SavedPaperEntity {
        val content = GeminiAcademicService.generateBoardGuessPaper(
            userApiKey = apiKey,
            subject = subject,
            topic = topic,
            board = board,
            gradeLevel = gradeLevel
        )
        val entity = SavedPaperEntity(
            subject = subject,
            topic = topic,
            board = board,
            gradeLevel = gradeLevel,
            markdownContent = content
        )
        dao.insertSavedPaper(entity)
        val email = dao.getActiveSession()?.userEmail ?: "majidfayyazabbasi@gmail.com"
        FirebaseCloudSyncManager.syncSavedPaperToFirestore(email, entity)
        return entity
    }

    suspend fun logoutSession() {
        FirebaseCloudSyncManager.signOutFirebase()
        dao.clearSession()
    }

    private suspend fun seedWelcomeTutorMessageIfNeeded(email: String, board: String) {
        dao.insertChatMessage(
            ChatMessageEntity(
                id = 1L,
                userEmail = email,
                subject = "Physics",
                board = board,
                isUser = false,
                content = """
### 👋 Welcome to EduGlobal AI Socratic Tutor!
I am calibrated for **$board** standards. All mathematical formulas and scientific notations render natively in clean LaTeX format:

- **Quadratic Roots & Discriminant:**
${'$'}${'$'}x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}${'$'}${'$'}
- **Carnot Thermal Efficiency:** ${'$'}\eta = 1 - \frac{T_C}{T_H}${'$'}
- **Coulomb's Electrostatic Law:** ${'$'}F = \frac{1}{4\pi\varepsilon_0} \frac{q_1 q_2}{r^2}${'$'}

Ask me any derivation, numerical problem, or SLO concept from your syllabus!
                """.trimIndent()
            )
        )
    }
}
