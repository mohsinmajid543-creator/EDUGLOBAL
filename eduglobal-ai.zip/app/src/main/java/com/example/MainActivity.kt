package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.auth.JwtAuthManager
import com.example.data.model.AcademicCatalog
import com.example.ui.components.AmbientGlowBackground
import com.example.ui.screens.AiTutorScreen
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ExamHubScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.QuizEngineScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.AppDestination
import com.example.ui.viewmodel.EduGlobalViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                EduGlobalRootApp()
            }
        }
    }
}

@Composable
fun EduGlobalRootApp(viewModel: EduGlobalViewModel = viewModel()) {
    val activeSession by viewModel.activeSession.collectAsStateWithLifecycle()
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val subjects by viewModel.subjects.collectAsStateWithLifecycle()
    val chatMessages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val quizAttempts by viewModel.quizAttempts.collectAsStateWithLifecycle()
    val savedPapers by viewModel.savedPapers.collectAsStateWithLifecycle()
    val activeGuessPaper by viewModel.activeGuessPaper.collectAsStateWithLifecycle()
    val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
    val selectedSubject by viewModel.selectedSubject.collectAsStateWithLifecycle()
    val selectedBoard by viewModel.selectedBoard.collectAsStateWithLifecycle()
    val authError by viewModel.authError.collectAsStateWithLifecycle()
    val isAuthLoading by viewModel.isAuthLoading.collectAsStateWithLifecycle()
    val showAuthModalOverlay by viewModel.showAuthModalOverlay.collectAsStateWithLifecycle()
    val showStreakToast by viewModel.showStreakToast.collectAsStateWithLifecycle()
    val isTutorThinking by viewModel.isTutorThinking.collectAsStateWithLifecycle()
    val selectedModelTier by viewModel.selectedModelTier.collectAsStateWithLifecycle()
    val selectedTutorRole by viewModel.selectedTutorRole.collectAsStateWithLifecycle()
    val customSystemInstruction by viewModel.customSystemInstruction.collectAsStateWithLifecycle()
    val cloudTelemetry by viewModel.cloudTelemetry.collectAsStateWithLifecycle()
    val quizState by viewModel.quizState.collectAsStateWithLifecycle()
    val isPaperGenerating by viewModel.isPaperGenerating.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val isJwtSessionValid = activeSession != null &&
        JwtAuthManager.verifyAndDecodeJwt(activeSession?.jwtToken ?: "") != null

    if (!isJwtSessionValid || showAuthModalOverlay) {
        AuthScreen(
            isLoading = isAuthLoading,
            errorMessage = authError,
            onSignUp = { firstName, lastName, email, phone, password, apiKey, board, grade ->
                viewModel.signUpWithJwt(
                    firstName = firstName,
                    lastName = lastName,
                    email = email,
                    pakistanPhone = phone,
                    password = password,
                    geminiApiKey = apiKey,
                    board = board,
                    gradeLevel = grade
                )
            },
            onSignIn = { email, password, apiKey ->
                viewModel.signInWithJwt(email, password, apiKey)
            },
            onGoogleSignIn = { apiKey ->
                viewModel.signInWithGoogle(apiKey, context)
            },
            onCloseClicked = {
                if (isJwtSessionValid) {
                    viewModel.dismissAuthModalOverlay()
                } else {
                    // Quick Verified Scholar Session when user taps X on initial modal
                    viewModel.signInWithGoogle("DEMO_KEY_OCTAGON_2026")
                }
            },
            onClearError = { viewModel.clearAuthMessages() }
        )
    } else {
        // Handle Android system back button on secondary tabs to return to Dashboard
        if (currentDestination != AppDestination.DASHBOARD) {
            BackHandler {
                viewModel.navigateTo(AppDestination.DASHBOARD)
            }
        }

        AmbientGlowBackground {
            Scaffold(
                containerColor = Color.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    EduGlobalBottomBar(
                        currentDestination = currentDestination,
                        onNavigate = { viewModel.navigateTo(it) }
                    )
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentDestination) {
                        AppDestination.DASHBOARD -> {
                            DashboardScreen(
                                user = currentUser,
                                selectedBoard = selectedBoard,
                                selectedSubject = selectedSubject,
                                subjects = subjects,
                                quizAttempts = quizAttempts,
                                showStreakToast = showStreakToast,
                                onSelectBoard = { viewModel.selectBoard(it) },
                                onSelectSubject = { viewModel.selectSubject(it) },
                                onAddCustomSubject = { name, cat ->
                                    viewModel.addCustomSubject(name, cat)
                                },
                                onUpdateSubjectProgress = { sub, pct ->
                                    viewModel.updateSubjectProgress(sub, pct)
                                },
                                onDismissStreakToast = { viewModel.dismissStreakToast() },
                                onClaimStreakBonus = { viewModel.claimDailyStreak() },
                                onNavigate = { viewModel.navigateTo(it) },
                                onOpenAuthModal = { viewModel.openAuthModalOverlay() }
                            )
                        }

                        AppDestination.AI_TUTOR -> {
                            AiTutorScreen(
                                selectedSubject = selectedSubject,
                                selectedBoard = selectedBoard,
                                messages = chatMessages,
                                isThinking = isTutorThinking,
                                selectedModelTier = selectedModelTier,
                                selectedTutorRole = selectedTutorRole,
                                customSystemInstruction = customSystemInstruction,
                                onSelectModelTier = { viewModel.selectModelTier(it) },
                                onSelectTutorRole = { viewModel.selectTutorRole(it) },
                                onUpdateSystemInstruction = { viewModel.updateCustomSystemInstruction(it) },
                                onSendPrompt = { viewModel.askTutor(it) },
                                onClearChat = { viewModel.clearTutorChat() }
                            )
                        }

                        AppDestination.QUIZ_ENGINE -> {
                            QuizEngineScreen(
                                selectedBoard = selectedBoard,
                                selectedSubject = selectedSubject,
                                subjects = subjects,
                                quizState = quizState,
                                onSelectSubject = { viewModel.selectSubject(it) },
                                onGenerateQuiz = { sub, topic, diff, count ->
                                    viewModel.generateQuiz(sub, topic, diff, count)
                                },
                                onSelectOption = { qIdx, optIdx ->
                                    viewModel.selectQuizOption(qIdx, optIdx)
                                },
                                onSubmitQuiz = { viewModel.submitQuizForGrading() }
                            )
                        }

                        AppDestination.EXAM_HUB -> {
                            ExamHubScreen(
                                selectedBoard = selectedBoard,
                                selectedSubject = selectedSubject,
                                gradeLevel = currentUser?.gradeLevel ?: AcademicCatalog.GRADE_LEVELS[2],
                                subjects = subjects,
                                activePaper = activeGuessPaper,
                                savedPapers = savedPapers,
                                isGenerating = isPaperGenerating,
                                onSelectSubject = { viewModel.selectSubject(it) },
                                onAddCustomSubject = { name, cat ->
                                    viewModel.addCustomSubject(name, cat)
                                },
                                onGeneratePaper = { sub, topic, board, grade ->
                                    viewModel.generateBoardPaper(sub, topic, board, grade)
                                },
                                onSelectSavedPaper = { viewModel.selectSavedPaper(it) }
                            )
                        }

                        AppDestination.PROFILE -> {
                            ProfileScreen(
                                user = currentUser,
                                session = activeSession,
                                cloudTelemetry = cloudTelemetry,
                                onSaveProfileAndApiKey = { fName, lName, phone, board, grade, key ->
                                    viewModel.updateProfileAndApiKey(
                                        firstName = fName,
                                        lastName = lName,
                                        phone = phone,
                                        board = board,
                                        gradeLevel = grade,
                                        apiKey = key
                                    )
                                },
                                onRefreshJwt = { viewModel.refreshJwtToken() },
                                onSyncFirestore = { viewModel.syncNowToFirestore() },
                                onLogout = { viewModel.logout() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EduGlobalBottomBar(
    currentDestination: AppDestination,
    onNavigate: (AppDestination) -> Unit
) {
    val navItems = listOf(
        Triple(AppDestination.DASHBOARD, stringResource(R.string.nav_dashboard), Icons.Default.Dashboard),
        Triple(AppDestination.AI_TUTOR, stringResource(R.string.nav_tutor), Icons.Default.AutoAwesome),
        Triple(AppDestination.QUIZ_ENGINE, stringResource(R.string.nav_quiz), Icons.Default.Quiz),
        Triple(AppDestination.EXAM_HUB, stringResource(R.string.nav_exam_hub), Icons.Default.School),
        Triple(AppDestination.PROFILE, stringResource(R.string.nav_profile), Icons.Default.Person)
    )

    NavigationBar(
        containerColor = Color(0xFF0D1322).copy(alpha = 0.95f),
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .clip(RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .border(
                width = 1.dp,
                color = Color.White.copy(alpha = 0.12f),
                shape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
            )
    ) {
        navItems.forEach { (dest, label, icon) ->
            val selected = currentDestination == dest
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(dest) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.5.sp,
                        fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Medium
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CyberCyan,
                    selectedTextColor = CyberCyan,
                    indicatorColor = ElectricIndigo.copy(alpha = 0.28f),
                    unselectedIconColor = TextSecondarySlate,
                    unselectedTextColor = TextSecondarySlate
                ),
                modifier = Modifier
                    .background(Color.Transparent)
                    .testTag("nav_${dest.name.lowercase()}")
            )
        }
    }
}
