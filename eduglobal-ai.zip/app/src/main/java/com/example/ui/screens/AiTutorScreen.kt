package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatMessageEntity
import com.example.data.model.GeminiModelTier
import com.example.data.model.TutorRolePersona
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.MathTextView
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@Composable
fun AiTutorScreen(
    selectedSubject: String,
    selectedBoard: String,
    messages: List<ChatMessageEntity>,
    isThinking: Boolean,
    selectedModelTier: GeminiModelTier = GeminiModelTier.COMPLEX_PRO,
    selectedTutorRole: TutorRolePersona = TutorRolePersona.SOCRATIC_PROFESSOR,
    customSystemInstruction: String = TutorRolePersona.SOCRATIC_PROFESSOR.defaultSystemInstruction,
    onSelectModelTier: (GeminiModelTier) -> Unit = {},
    onSelectTutorRole: (TutorRolePersona) -> Unit = {},
    onUpdateSystemInstruction: (String) -> Unit = {},
    onSendPrompt: (String) -> Unit,
    onClearChat: () -> Unit
) {
    var inputPrompt by rememberSaveable { mutableStateOf("") }
    var showSystemInstructionPanel by rememberSaveable { mutableStateOf(false) }
    val listState = rememberLazyListState()

    val quickPrompts = listOf(
        "Derive Carnot Engine Efficiency η = 1 - Tc/Th",
        "Explain Quadratic Discriminant Δ = b² - 4ac",
        "Coulomb's Law & Gauss's Divergence Theorem",
        "de Broglie Wavelength & Relativistic Energy"
    )

    // Automatically scroll thread to latest message in multi-turn conversation
    LaunchedEffect(messages.size, isThinking) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem((messages.size - 1).coerceAtLeast(0))
        }
    }

    val totalTurns = messages.count { it.isUser }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) {
        // 1. Tutor Header Card with Model & System Instruction Controls
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 20.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(
                                    Brush.linearGradient(listOf(ElectricIndigo, CyberCyan)),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Gemini Multi-Turn AI Chat Tutor",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "$selectedSubject • ${selectedTutorRole.iconEmoji} ${selectedTutorRole.roleTitle} • ${messages.size} msgs",
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { showSystemInstructionPanel = !showSystemInstructionPanel },
                            modifier = Modifier.testTag("toggle_system_instruction_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Configure Chatbot Role & System Instruction",
                                tint = if (showSystemInstructionPanel) CyberCyan else TextSecondarySlate
                            )
                        }
                        IconButton(
                            onClick = onClearChat,
                            modifier = Modifier.testTag("clear_tutor_chat_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.DeleteSweep,
                                contentDescription = "Reset Multi-Turn Conversation",
                                tint = TextSecondarySlate
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Gemini Model Tier Selector (gemini-3.1-pro-preview | gemini-3.5-flash | gemini-3.1-flash-lite)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF080C14).copy(alpha = 0.90f))
                        .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    GeminiModelTier.entries.forEach { tier ->
                        val isSelected = tier == selectedModelTier
                        val badgeColor = when (tier) {
                            GeminiModelTier.COMPLEX_PRO -> RoyalViolet
                            GeminiModelTier.GENERAL_FLASH -> ElectricIndigo
                            GeminiModelTier.FAST_FLASH_LITE -> NeonEmerald
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(9.dp))
                                .background(
                                    if (isSelected) {
                                        Brush.horizontalGradient(listOf(badgeColor, CyberCyan.copy(alpha = 0.75f)))
                                    } else {
                                        Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                                    }
                                )
                                .clickable { onSelectModelTier(tier) }
                                .padding(vertical = 6.dp, horizontal = 4.dp)
                                .testTag("model_tier_${tier.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = tier.badgeLabel,
                                    color = if (isSelected) Color.White else TextSecondarySlate,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1
                                )
                                Text(
                                    text = tier.displayTitle,
                                    color = if (isSelected) Color(0xFFE0F2FE) else TextMutedSlate,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Role / System Instruction Persona Selector Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TutorRolePersona.entries.forEach { persona ->
                        val isSelected = persona == selectedTutorRole
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (isSelected) {
                                        CyberCyan.copy(alpha = 0.20f)
                                    } else {
                                        Color.White.copy(alpha = 0.05f)
                                    }
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) CyberCyan else Color.White.copy(alpha = 0.12f),
                                    RoundedCornerShape(50)
                                )
                                .clickable { onSelectTutorRole(persona) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("role_persona_${persona.name.lowercase()}")
                        ) {
                            Text(
                                text = "${persona.iconEmoji} ${persona.roleTitle}",
                                color = if (isSelected) CyberCyan else TextSecondarySlate,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                            )
                        }
                    }
                }

                // Expandable System Instruction Editor & Multi-Turn Inspector
                AnimatedVisibility(visible = showSystemInstructionPanel) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF090D16))
                            .border(1.dp, CyberCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "⚙️ Active System Instruction (${selectedTutorRole.roleTitle})",
                                color = CyberCyan,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = "Multi-Turn Memory: $totalTurns turns",
                                color = NeonEmerald,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        OutlinedTextField(
                            value = customSystemInstruction,
                            onValueChange = onUpdateSystemInstruction,
                            minLines = 2,
                            maxLines = 4,
                            shape = RoundedCornerShape(10.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimaryWhite,
                                unfocusedTextColor = TextPrimaryWhite,
                                focusedContainerColor = Color(0xFF111827),
                                unfocusedContainerColor = Color(0xFF111827),
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.18f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("system_instruction_input")
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = selectedModelTier.description,
                            color = TextMutedSlate,
                            fontSize = 10.5.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Quick Prompt Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            quickPrompts.forEach { chip ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(ElectricIndigo.copy(alpha = 0.16f))
                        .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(50))
                        .clickable { onSendPrompt(chip) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "✨ $chip",
                        color = TextPrimaryWhite,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Scrollable Multi-Turn Conversation Thread with Native LaTeX Math Rendering
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .testTag("multi_turn_chat_thread"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(
                items = messages,
                key = { idx, msg -> if (msg.id != 0L) msg.id else idx.toLong() }
            ) { index, msg ->
                ChatBubbleItem(
                    message = msg,
                    turnIndex = (index / 2) + 1
                )
            }

            if (isThinking) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(8.dp)
                            .background(Color.White.copy(alpha = 0.06f), RoundedCornerShape(14.dp))
                            .border(1.dp, CyberCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            strokeWidth = 2.5.dp,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "${selectedModelTier.displayTitle} (${selectedTutorRole.shortBadge}) is reasoning over multi-turn history...",
                            color = CyberCyan,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Bottom Multi-Turn Input Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputPrompt,
                onValueChange = { inputPrompt = it },
                placeholder = {
                    Text(
                        text = "Message ${selectedTutorRole.roleTitle} (${selectedModelTier.displayTitle})...",
                        color = TextMutedSlate,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                shape = RoundedCornerShape(18.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimaryWhite,
                    unfocusedTextColor = TextPrimaryWhite,
                    focusedContainerColor = Color(0xFF111827),
                    unfocusedContainerColor = Color(0xFF111827),
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.18f)
                ),
                modifier = Modifier
                    .weight(1f)
                    .testTag("tutor_prompt_input")
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (inputPrompt.isNotBlank()) {
                        onSendPrompt(inputPrompt)
                        inputPrompt = ""
                    }
                },
                modifier = Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(listOf(ElectricIndigo, RoyalViolet, CyberCyan))
                    )
                    .testTag("tutor_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send prompt to AI Tutor",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun ChatBubbleItem(
    message: ChatMessageEntity,
    turnIndex: Int
) {
    val isUser = message.isUser
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(if (isUser) 0.85f else 0.96f)
                .clip(
                    RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isUser) 18.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 18.dp
                    )
                )
                .background(
                    if (isUser) {
                        Brush.horizontalGradient(listOf(ElectricIndigo, RoyalViolet))
                    } else {
                        Brush.verticalGradient(
                            listOf(Color(0xFF161F33), Color(0xFF0F172A))
                        )
                    }
                )
                .border(
                    width = 1.dp,
                    color = if (isUser) CyberCyan.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isUser) 18.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 18.dp
                    )
                )
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) {
                            "You • ${message.subject} (Turn #$turnIndex)"
                        } else {
                            "🎓 ${message.board}"
                        },
                        color = if (isUser) Color(0xFFE0E7FF) else NeonEmerald,
                        fontSize = 10.5.sp,
                        fontWeight = FontWeight.ExtraBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.CloudDone,
                        contentDescription = "Synced with Firestore & SQLite",
                        tint = if (isUser) Color.White.copy(alpha = 0.7f) else AmberGold,
                        modifier = Modifier.size(13.dp)
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                MathTextView(
                    content = message.content,
                    textColor = TextPrimaryWhite,
                    mathHighlightColor = if (isUser) Color.White else Color(0xFFC7D2FE)
                )
            }
        }
    }
}
