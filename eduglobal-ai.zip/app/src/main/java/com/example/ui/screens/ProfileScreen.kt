package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.auth.JwtAuthManager
import com.example.data.local.SessionEntity
import com.example.data.local.UserEntity
import com.example.data.model.AcademicCatalog
import com.example.data.remote.CloudSyncTelemetry
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.OctagonFooterSection
import com.example.ui.components.PrimaryGradientButton
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.PakistanFlagGreen
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    user: UserEntity?,
    session: SessionEntity?,
    cloudTelemetry: CloudSyncTelemetry = CloudSyncTelemetry(),
    onSaveProfileAndApiKey: (
        firstName: String,
        lastName: String,
        phone: String,
        board: String,
        gradeLevel: String,
        apiKey: String
    ) -> Unit,
    onRefreshJwt: () -> Unit,
    onSyncFirestore: () -> Unit = {},
    onLogout: () -> Unit
) {
    var firstName by rememberSaveable { mutableStateOf(user?.firstName ?: "Majid") }
    var lastName by rememberSaveable { mutableStateOf(user?.lastName ?: "Fayyaz") }
    var phone by rememberSaveable { mutableStateOf(user?.phone ?: "+923005551234") }
    var board by rememberSaveable { mutableStateOf(user?.selectedBoard ?: AcademicCatalog.PAKISTAN_BOARDS.first()) }
    var gradeLevel by rememberSaveable { mutableStateOf(user?.gradeLevel ?: AcademicCatalog.GRADE_LEVELS[2]) }
    var apiKey by rememberSaveable { mutableStateOf(user?.geminiApiKey ?: session?.geminiApiKey ?: "") }

    var showApiKey by rememberSaveable { mutableStateOf(false) }
    var boardDropdownExpanded by remember { mutableStateOf(false) }
    var savedConfirmation by remember { mutableStateOf(false) }

    LaunchedEffect(user) {
        if (user != null) {
            firstName = user.firstName
            lastName = user.lastName
            phone = user.phone
            board = user.selectedBoard
            gradeLevel = user.gradeLevel
            apiKey = user.geminiApiKey
        }
    }

    val uriHandler = LocalUriHandler.current
    val jwtToken = session?.jwtToken ?: ""
    val decodedPayload = remember(jwtToken) {
        if (jwtToken.isNotBlank()) JwtAuthManager.prettyPrintPayload(jwtToken) else "{ \"status\": \"No active JWT\" }"
    }
    val isJwtSignatureValid = remember(jwtToken) {
        JwtAuthManager.verifyAndDecodeJwt(jwtToken) != null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. User Identity Header Card
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(62.dp)
                        .background(
                            Brush.linearGradient(listOf(ElectricIndigo, CyberCyan)),
                            CircleShape
                        )
                        .border(2.dp, Color.White.copy(alpha = 0.7f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = firstName.firstOrNull()?.uppercase() ?: "S",
                        color = Color.White,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$firstName $lastName",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = "Verified Scholar",
                            tint = NeonEmerald,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Text(
                        text = user?.email ?: session?.userEmail ?: "majidfayyazabbasi@gmail.com",
                        color = TextSecondarySlate,
                        fontSize = 12.5.sp
                    )
                    Text(
                        text = "🇵🇰 ${JwtAuthManager.formatPakistanDisplayPhone(phone)} • ${user?.accountType ?: "Pro Scholar Account"}",
                        color = CyberCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 3.dp)
                    )
                }
            }
        }

        // 2. JWT Authentication & Session Security Inspector Card
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            accentHighlight = NeonEmerald
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "☁️ Firebase Auth & Cloud Firestore Sync",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = cloudTelemetry.firestoreStatus,
                            color = CyberCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                        Text(
                            text = "Provider: ${session?.authProvider ?: cloudTelemetry.authProviderLabel} • Synced Docs: ${cloudTelemetry.syncedDocumentsCount}",
                            color = TextSecondarySlate,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(ElectricIndigo.copy(alpha = 0.28f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .clickable(onClick = onSyncFirestore)
                            .padding(horizontal = 10.dp, vertical = 7.dp)
                            .testTag("sync_firestore_button")
                    ) {
                        Text(
                            text = "Sync Cloud",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        // 2b. JWT Authentication & Session Security Inspector Card
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            accentHighlight = NeonEmerald
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "🔐 JWT Authentication & Session Engine",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = if (isJwtSignatureValid) {
                                "HS256 Signature Verified • Active Session"
                            } else {
                                "Session Unverified"
                            },
                            color = if (isJwtSignatureValid) NeonEmerald else AmberGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onRefreshJwt,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ElectricIndigo.copy(alpha = 0.25f))
                            .testTag("refresh_jwt_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Rotate & Refresh JWT Token",
                            tint = CyberCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Signed RFC-7519 Bearer Token (Header.Payload.Signature):",
                    color = TextSecondarySlate,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF090D16), RoundedCornerShape(10.dp))
                        .border(1.dp, NeonEmerald.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                        .horizontalScroll(rememberScrollState())
                        .padding(10.dp)
                ) {
                    Text(
                        text = jwtToken.ifBlank { "No active token" },
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Decoded Verified JWT Claims:",
                    color = TextSecondarySlate,
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF090D16), RoundedCornerShape(10.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = decodedPayload,
                        color = NeonEmerald,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // 3. Edit Profile, Pakistan Phone & Gemini API Key Management
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "⚙️ Scholar Profile & Gemini API Key Manager",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.ExtraBold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    GlassTextField(
                        value = firstName,
                        onValueChange = { firstName = it },
                        label = "First Name",
                        placeholder = "Majid",
                        modifier = Modifier.weight(1f)
                    )
                    GlassTextField(
                        value = lastName,
                        onValueChange = { lastName = it },
                        label = "Last Name",
                        placeholder = "Fayyaz",
                        modifier = Modifier.weight(1f)
                    )
                }

                GlassTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = "Pakistan Mobile Number (+92 3XX XXXXXXX)",
                    placeholder = "+923005551234",
                    leadingPrefixContent = {
                        Box(
                            modifier = Modifier
                                .padding(start = 10.dp, end = 6.dp)
                                .background(PakistanFlagGreen, RoundedCornerShape(6.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("🇵🇰 +92", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    isError = !JwtAuthManager.isValidPakistanMobile(phone),
                    supportingText = if (JwtAuthManager.isValidPakistanMobile(phone)) {
                        "✔ Verified Pakistan Mobile Format"
                    } else {
                        "Must be a valid 11-digit Pakistan mobile number (+92 3XX XXXXXXX)"
                    }
                )

                // Regional Board Dropdown
                Column {
                    Text(
                        text = "Pakistan Regional Examination Board",
                        style = MaterialTheme.typography.labelLarge,
                        color = TextSecondarySlate,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    ExposedDropdownMenuBox(
                        expanded = boardDropdownExpanded,
                        onExpandedChange = { boardDropdownExpanded = !boardDropdownExpanded }
                    ) {
                        OutlinedTextField(
                            value = board,
                            onValueChange = {},
                            readOnly = true,
                            trailingIcon = {
                                ExposedDropdownMenuDefaults.TrailingIcon(expanded = boardDropdownExpanded)
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimaryWhite,
                                unfocusedTextColor = TextPrimaryWhite,
                                focusedContainerColor = Color(0xFF0F172A),
                                unfocusedContainerColor = Color(0xFF0F172A),
                                focusedBorderColor = CyberCyan,
                                unfocusedBorderColor = Color.White.copy(alpha = 0.16f)
                            ),
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = boardDropdownExpanded,
                            onDismissRequest = { boardDropdownExpanded = false },
                            containerColor = Color(0xFF111827)
                        ) {
                            AcademicCatalog.PAKISTAN_BOARDS.forEach { item ->
                                DropdownMenuItem(
                                    text = { Text(item, color = TextPrimaryWhite, fontSize = 13.5.sp) },
                                    onClick = {
                                        board = item
                                        boardDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Personal Gemini API Key Input
                GlassTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = "Personal Gemini API Key",
                    placeholder = "AIzaSy...",
                    leadingIcon = Icons.Default.Key,
                    visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { showApiKey = !showApiKey }) {
                            Icon(
                                imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle API key visibility",
                                tint = TextSecondarySlate
                            )
                        }
                    }
                )

                Row(
                    modifier = Modifier
                        .clickable { uriHandler.openUri("https://aistudio.google.com/app/apikey") }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.auth_get_api_key_link),
                        color = CyberCyan,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        textDecoration = TextDecoration.Underline
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(14.dp)
                    )
                }

                if (savedConfirmation) {
                    Text(
                        text = "✅ Profile & Signed JWT Claims updated successfully!",
                        color = NeonEmerald,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                PrimaryGradientButton(
                    text = "Save Profile & Re-Sign JWT Session",
                    leadingEmoji = "💾",
                    onClick = {
                        if (JwtAuthManager.isValidPakistanMobile(phone)) {
                            onSaveProfileAndApiKey(firstName, lastName, phone, board, gradeLevel, apiKey)
                            savedConfirmation = true
                        }
                    },
                    testTagName = "save_profile_button"
                )
            }
        }

        // 4. Prototype Security Notice & Revoke Session (Logout)
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            accentHighlight = CrimsonAlert
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Text(
                    text = stringResource(R.string.security_prototype_warning),
                    color = AmberGold,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(CrimsonAlert.copy(alpha = 0.20f))
                        .border(1.dp, CrimsonAlert.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                        .clickable(onClick = onLogout)
                        .testTag("logout_jwt_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Logout,
                            contentDescription = "Revoke JWT Session & Sign Out",
                            tint = Color(0xFFFCA5A5),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Revoke JWT Session & Sign Out",
                            color = Color(0xFFFCA5A5),
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        OctagonFooterSection()
    }
}
