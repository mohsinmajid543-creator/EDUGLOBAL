package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.auth.JwtAuthManager
import com.example.data.model.AcademicCatalog
import com.example.ui.components.AmbientGlowBackground
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.GoogleSignInGlassButton
import com.example.ui.components.OctagonFooterSection
import com.example.ui.components.PrimaryGradientButton
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.PakistanFlagGreen
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    isLoading: Boolean,
    errorMessage: String?,
    onSignUp: (
        firstName: String,
        lastName: String,
        email: String,
        pakistanPhone: String,
        password: String,
        geminiApiKey: String,
        board: String,
        gradeLevel: String
    ) -> Unit,
    onSignIn: (
        email: String,
        password: String,
        geminiApiKey: String
    ) -> Unit,
    onGoogleSignIn: (geminiApiKey: String) -> Unit,
    onCloseClicked: () -> Unit,
    onClearError: () -> Unit
) {
    var isSignUpMode by rememberSaveable { mutableStateOf(true) }
    var firstName by rememberSaveable { mutableStateOf("Majid") }
    var lastName by rememberSaveable { mutableStateOf("Fayyaz") }
    var email by rememberSaveable { mutableStateOf("majidfayyazabbasi@gmail.com") }
    var pakistanPhoneDigits by rememberSaveable { mutableStateOf("3005551234") }
    var password by rememberSaveable { mutableStateOf("Scholar2026!") }
    var geminiApiKey by rememberSaveable { mutableStateOf("") }
    var selectedBoard by rememberSaveable { mutableStateOf(AcademicCatalog.PAKISTAN_BOARDS.first()) }
    var selectedGrade by rememberSaveable { mutableStateOf(AcademicCatalog.GRADE_LEVELS[2]) }

    var showPassword by rememberSaveable { mutableStateOf(false) }
    var showApiKey by rememberSaveable { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var boardDropdownExpanded by remember { mutableStateOf(false) }

    val uriHandler = LocalUriHandler.current
    val isPhoneValid = remember(pakistanPhoneDigits) {
        JwtAuthManager.isValidPakistanMobile("+92$pakistanPhoneDigits")
    }

    AmbientGlowBackground {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Centered Glassmorphic Modal Auth Card
            GlassmorphicCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 520.dp),
                cornerRadius = 26.dp,
                borderAlpha = 0.28f
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 22.dp, vertical = 22.dp)
                ) {
                    // Top Bar: Tab Toggle ("Sign up" / "Sign in") + Close Button ("X")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Pill Segmented Toggle ("Sign up" / "Sign in")
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color(0xFF090D16).copy(alpha = 0.85f))
                                .border(1.dp, Color.White.copy(alpha = 0.14f), RoundedCornerShape(50))
                                .padding(4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AuthTabPill(
                                title = stringResource(R.string.auth_tab_sign_up),
                                selected = isSignUpMode,
                                onClick = {
                                    isSignUpMode = true
                                    onClearError()
                                },
                                testTagName = "tab_sign_up"
                            )
                            AuthTabPill(
                                title = stringResource(R.string.auth_tab_sign_in),
                                selected = !isSignUpMode,
                                onClick = {
                                    isSignUpMode = false
                                    onClearError()
                                },
                                testTagName = "tab_sign_in"
                            )
                        }

                        // Close Button ("X")
                        IconButton(
                            onClick = onCloseClicked,
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.08f))
                                .border(1.dp, Color.White.copy(alpha = 0.18f), CircleShape)
                                .testTag("auth_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close authentication modal",
                                tint = TextPrimaryWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Brand Badge + JWT Security Indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    NeonEmerald.copy(alpha = 0.15f),
                                    RoundedCornerShape(50)
                                )
                                .border(1.dp, NeonEmerald.copy(alpha = 0.45f), RoundedCornerShape(50))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.VerifiedUser,
                                    contentDescription = null,
                                    tint = NeonEmerald,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "EDUGLOBAL • JWT AUTHENTICATED",
                                    color = NeonEmerald,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }

                        TextButton(
                            onClick = {
                                firstName = "Majid"
                                lastName = "Fayyaz"
                                email = "majidfayyazabbasi@gmail.com"
                                pakistanPhoneDigits = "3005551234"
                                password = "Scholar2026!"
                                if (geminiApiKey.isBlank()) {
                                    geminiApiKey = "DEMO_KEY_OCTAGON_2026"
                                }
                                onClearError()
                            },
                            modifier = Modifier.testTag("quick_demo_fill_button")
                        ) {
                            Text(
                                text = "⚡ Demo Fill",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Header: "Create an account" for registration / "Welcome back, Scholar" for login
                    Text(
                        text = if (isSignUpMode) {
                            stringResource(R.string.auth_header_create_account)
                        } else {
                            stringResource(R.string.auth_header_welcome_back)
                        },
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Text(
                        text = if (isSignUpMode) {
                            "Register your verified Pakistan Board scholar account with HS256 JWT session protection."
                        } else {
                            "Sign in with your verified credentials to resume your AI study session."
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondarySlate,
                        modifier = Modifier.padding(top = 4.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Error Message Alert if any
                    AnimatedVisibility(
                        visible = !errorMessage.isNullOrBlank(),
                        enter = fadeIn(),
                        exit = fadeOut()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                                .background(
                                    Color(0xFFEF4444).copy(alpha = 0.16f),
                                    RoundedCornerShape(12.dp)
                                )
                                .border(1.dp, Color(0xFFEF4444).copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = errorMessage ?: "",
                                color = Color(0xFFFCA5A5),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // 1. First Name & Last Name (Side-by-side input fields in Sign Up)
                    AnimatedVisibility(visible = isSignUpMode) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                GlassTextField(
                                    value = firstName,
                                    onValueChange = { firstName = it },
                                    label = stringResource(R.string.auth_first_name_label),
                                    placeholder = "Majid",
                                    leadingIcon = Icons.Default.Person,
                                    modifier = Modifier.weight(1f),
                                    testTagName = "first_name_input"
                                )
                                GlassTextField(
                                    value = lastName,
                                    onValueChange = { lastName = it },
                                    label = stringResource(R.string.auth_last_name_label),
                                    placeholder = "Fayyaz",
                                    modifier = Modifier.weight(1f),
                                    testTagName = "last_name_input"
                                )
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }

                    // 2. Email Address input field with an envelope icon
                    GlassTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = stringResource(R.string.auth_email_label),
                        placeholder = "student@gmail.com",
                        leadingIcon = Icons.Outlined.Email,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        testTagName = "email_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 3. Pakistan-Only Phone Number Input (+92 / 🇵🇰 Flag icon, 11-digit validation)
                    AnimatedVisibility(visible = isSignUpMode) {
                        Column {
                            GlassTextField(
                                value = pakistanPhoneDigits,
                                onValueChange = { raw ->
                                    // Strip non-digits; if user types leading 03..., normalize to 3... (10 digits after +92)
                                    val digits = raw.filter { it.isDigit() }
                                    val normalized = when {
                                        digits.startsWith("923") -> digits.removePrefix("92").take(10)
                                        digits.startsWith("03") -> digits.removePrefix("0").take(10)
                                        else -> digits.take(10)
                                    }
                                    pakistanPhoneDigits = normalized
                                },
                                label = stringResource(R.string.auth_phone_label),
                                placeholder = "300 1234567 (11-digit PK format)",
                                leadingPrefixContent = {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .padding(start = 10.dp, end = 6.dp)
                                            .background(
                                                PakistanFlagGreen.copy(alpha = 0.65f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .border(
                                                1.dp,
                                                NeonEmerald.copy(alpha = 0.5f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .padding(horizontal = 8.dp, vertical = 5.dp)
                                    ) {
                                        Text(text = "🇵🇰", fontSize = 14.sp)
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "+92",
                                            color = Color.White,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 13.sp
                                        )
                                    }
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                isError = pakistanPhoneDigits.isNotEmpty() && !isPhoneValid,
                                supportingText = if (pakistanPhoneDigits.isEmpty()) {
                                    "Strictly Pakistan (+92 3XX XXXXXXX / 03XX XXXXXXX)"
                                } else if (isPhoneValid) {
                                    "✔ Valid Pakistan Mobile: +92 ${pakistanPhoneDigits.take(3)} ${pakistanPhoneDigits.drop(3)}"
                                } else {
                                    "Must be a valid 11-digit Pakistani mobile number starting with 03 / +92 3XX"
                                },
                                testTagName = "pakistan_phone_input"
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            // Regional Board Selector for Sign Up
                            Text(
                                text = "Pakistan Regional Examination Board",
                                style = MaterialTheme.typography.labelLarge,
                                color = TextSecondarySlate,
                                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
                            )
                            ExposedDropdownMenuBox(
                                expanded = boardDropdownExpanded,
                                onExpandedChange = { boardDropdownExpanded = !boardDropdownExpanded }
                            ) {
                                OutlinedTextField(
                                    value = selectedBoard,
                                    onValueChange = {},
                                    readOnly = true,
                                    trailingIcon = {
                                        ExposedDropdownMenuDefaults.TrailingIcon(expanded = boardDropdownExpanded)
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextPrimaryWhite,
                                        unfocusedTextColor = TextPrimaryWhite,
                                        focusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.78f),
                                        unfocusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.56f),
                                        focusedBorderColor = CyberCyan,
                                        unfocusedBorderColor = Color.White.copy(alpha = 0.16f)
                                    ),
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = boardDropdownExpanded,
                                    onDismissRequest = { boardDropdownExpanded = false },
                                    containerColor = Color(0xFF111827)
                                ) {
                                    AcademicCatalog.PAKISTAN_BOARDS.forEach { boardItem ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = boardItem,
                                                    color = TextPrimaryWhite,
                                                    fontSize = 13.5.sp
                                                )
                                            },
                                            onClick = {
                                                selectedBoard = boardItem
                                                boardDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }

                    // Password Field for JWT Security
                    GlassTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = stringResource(R.string.auth_password_label),
                        placeholder = "Enter password",
                        leadingIcon = Icons.Default.Lock,
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle password visibility",
                                    tint = TextSecondarySlate
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        testTagName = "password_input"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4. Gemini API Key Input (password-masked input field)
                    GlassTextField(
                        value = geminiApiKey,
                        onValueChange = { geminiApiKey = it },
                        label = stringResource(R.string.auth_api_key_label),
                        placeholder = "AIzaSy... (Personal Gemini API Key)",
                        leadingIcon = Icons.Default.Key,
                        visualTransformation = if (showApiKey) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showApiKey = !showApiKey }) {
                                Icon(
                                    imageVector = if (showApiKey) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = "Toggle API key visibility",
                                    tint = TextSecondarySlate
                                )
                            }
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        testTagName = "gemini_api_key_input"
                    )

                    // 5. API Key Link right below the API key input
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp, start = 4.dp)
                            .clickable {
                                uriHandler.openUri("https://aistudio.google.com/app/apikey")
                            }
                            .testTag("get_gemini_api_key_link"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(R.string.auth_get_api_key_link),
                            color = CyberCyan,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            textDecoration = TextDecoration.Underline
                        )
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(
                            imageVector = Icons.Default.OpenInNew,
                            contentDescription = "Open Google AI Studio",
                            tint = CyberCyan,
                            modifier = Modifier.size(14.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // 6. Primary Full-Width Button ("Create an account" / "Sign in to EduGlobal")
                    if (isLoading) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator(color = CyberCyan, strokeWidth = 3.dp)
                        }
                    } else {
                        PrimaryGradientButton(
                            text = if (isSignUpMode) {
                                stringResource(R.string.auth_btn_create_account)
                            } else {
                                stringResource(R.string.auth_btn_sign_in)
                            },
                            onClick = {
                                if (isSignUpMode) {
                                    onSignUp(
                                        firstName,
                                        lastName,
                                        email,
                                        "+92$pakistanPhoneDigits",
                                        password,
                                        geminiApiKey.ifBlank { "DEMO_KEY_OCTAGON_2026" },
                                        selectedBoard,
                                        selectedGrade
                                    )
                                } else {
                                    onSignIn(
                                        email,
                                        password,
                                        geminiApiKey
                                    )
                                }
                            },
                            testTagName = "create_account_button"
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Social Login Divider: "OR SIGN IN WITH"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.14f)
                        )
                        Text(
                            text = stringResource(R.string.auth_divider_or_sign_in_with),
                            color = TextMutedSlate,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        HorizontalDivider(
                            modifier = Modifier.weight(1f),
                            color = Color.White.copy(alpha = 0.14f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // ONLY "Sign in with Google" button (Apple Sign-In completely removed)
                    GoogleSignInGlassButton(
                        onClick = { onGoogleSignIn(geminiApiKey) }
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Footer Text: "By creating an account, you agree to our Terms & Service"
                    Text(
                        text = stringResource(R.string.auth_footer_terms),
                        color = TextSecondarySlate,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTermsDialog = true }
                            .padding(vertical = 4.dp)
                            .testTag("terms_footer_text")
                    )
                }
            }

            OctagonFooterSection()
        }
    }

    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            containerColor = Color(0xFF111827),
            titleContentColor = TextPrimaryWhite,
            textContentColor = TextSecondarySlate,
            title = {
                Text("Terms & Service — EduGlobal (Octagon Inc)", fontWeight = FontWeight.Bold)
            },
            text = {
                Text(
                    "1. Verified JWT Authentication: Accounts are protected with signed HS256 JSON Web Tokens (JWT) and SHA-256 credential hashing.\n\n" +
                        "2. Pakistan Mobile Standard: Phone registration validates 11-digit Pakistani numbers (+92 3XX XXXXXXX).\n\n" +
                        "3. Personal Gemini API Key: Your key is used directly for AI Tutor derivations, customizable MCQ quizzes, and SLO guess papers.\n\n" +
                        "4. Prototype Security Warning: Do not share debug APKs containing active API keys publicly."
                )
            },
            confirmButton = {
                TextButton(onClick = { showTermsDialog = false }) {
                    Text("I Agree", color = CyberCyan, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}

@Composable
private fun AuthTabPill(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTagName: String
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(
                brush = if (selected) {
                    Brush.horizontalGradient(listOf(ElectricIndigo, RoyalViolet))
                } else {
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                }
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .testTag(testTagName),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = title,
            color = if (selected) Color.White else TextSecondarySlate,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold,
            fontSize = 13.5.sp
        )
    }
}
