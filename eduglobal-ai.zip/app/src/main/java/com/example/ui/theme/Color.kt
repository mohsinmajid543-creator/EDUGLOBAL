package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Dark Mode & Glassmorphic Palette for EduGlobal
val DeepMidnight = Color(0xFF070A12)
val DarkObsidian = Color(0xFF0B0F19)
val GlassSurfaceDark = Color(0xFF111827)
val GlassCardElevated = Color(0xFF1A2235)
val GlassBorderHighlight = Color(0x38FFFFFF)
val GlassBorderSubtle = Color(0x1EFFFFFF)

val ElectricIndigo = Color(0xFF6366F1)
val RoyalViolet = Color(0xFF8B5CF6)
val CyberCyan = Color(0xFF06B6D4)
val NeonEmerald = Color(0xFF10B981)
val AmberGold = Color(0xFFF59E0B)
val CrimsonAlert = Color(0xFFEF4444)

val TextPrimaryWhite = Color(0xFFF8FAFC)
val TextSecondarySlate = Color(0xFF94A3B8)
val TextMutedSlate = Color(0xFF64748B)
val PakistanFlagGreen = Color(0xFF01411C)
