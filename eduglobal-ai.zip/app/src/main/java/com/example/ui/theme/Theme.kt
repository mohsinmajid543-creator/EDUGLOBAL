package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val EduGlobalDarkColorScheme = darkColorScheme(
    primary = ElectricIndigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF1E1B4B),
    onPrimaryContainer = Color(0xFFE0E7FF),
    secondary = CyberCyan,
    onSecondary = Color(0xFF022C22),
    secondaryContainer = Color(0xFF083344),
    onSecondaryContainer = Color(0xFFCFFAFE),
    tertiary = NeonEmerald,
    onTertiary = Color(0xFF022C22),
    background = DarkObsidian,
    onBackground = TextPrimaryWhite,
    surface = GlassSurfaceDark,
    onSurface = TextPrimaryWhite,
    surfaceVariant = GlassCardElevated,
    onSurfaceVariant = TextSecondarySlate,
    error = CrimsonAlert,
    onError = Color.White,
    outline = GlassBorderHighlight
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = EduGlobalDarkColorScheme,
        typography = Typography,
        content = content
    )
}
