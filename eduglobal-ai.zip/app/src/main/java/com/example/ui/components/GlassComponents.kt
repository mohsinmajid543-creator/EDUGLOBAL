package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkObsidian
import com.example.ui.theme.DeepMidnight
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@Composable
fun AmbientGlowBackground(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(DeepMidnight, DarkObsidian, Color(0xFF090D16))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Top-left Indigo Ambient Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        ElectricIndigo.copy(alpha = 0.26f),
                        RoyalViolet.copy(alpha = 0.08f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.15f, h * 0.12f),
                    radius = w * 0.75f
                ),
                radius = w * 0.75f,
                center = Offset(w * 0.15f, h * 0.12f)
            )

            // Middle-right Cyan Ambient Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        CyberCyan.copy(alpha = 0.20f),
                        ElectricIndigo.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.88f, h * 0.42f),
                    radius = w * 0.7f
                ),
                radius = w * 0.7f,
                center = Offset(w * 0.88f, h * 0.42f)
            )

            // Bottom-left Emerald/Violet Ambient Glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        NeonEmerald.copy(alpha = 0.13f),
                        RoyalViolet.copy(alpha = 0.05f),
                        Color.Transparent
                    ),
                    center = Offset(w * 0.25f, h * 0.88f),
                    radius = w * 0.65f
                ),
                radius = w * 0.65f,
                center = Offset(w * 0.25f, h * 0.88f)
            )
        }
        content()
    }
}

@Composable
fun GlassmorphicCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 22.dp,
    borderAlpha: Float = 0.22f,
    fillAlpha: Float = 0.07f,
    accentHighlight: Color = ElectricIndigo,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = fillAlpha + 0.03f),
                        Color(0xFF151E32).copy(alpha = 0.82f),
                        Color(0xFF0E1525).copy(alpha = 0.90f)
                    )
                ),
                shape = shape
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = borderAlpha),
                        accentHighlight.copy(alpha = borderAlpha * 1.1f),
                        CyberCyan.copy(alpha = borderAlpha * 0.7f)
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

@Composable
fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    modifier: Modifier = Modifier,
    leadingIcon: ImageVector? = null,
    leadingPrefixContent: (@Composable () -> Unit)? = null,
    trailingIcon: (@Composable () -> Unit)? = null,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    isError: Boolean = false,
    supportingText: String? = null,
    singleLine: Boolean = true,
    testTagName: String = ""
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondarySlate,
            modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
        )
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            placeholder = {
                Text(
                    text = placeholder,
                    color = TextMutedSlate,
                    fontSize = 13.5.sp
                )
            },
            leadingIcon = when {
                leadingPrefixContent != null -> leadingPrefixContent
                leadingIcon != null -> {
                    {
                        Icon(
                            imageVector = leadingIcon,
                            contentDescription = label,
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
                else -> null
            },
            trailingIcon = trailingIcon,
            visualTransformation = visualTransformation,
            keyboardOptions = keyboardOptions,
            singleLine = singleLine,
            isError = isError,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimaryWhite,
                unfocusedTextColor = TextPrimaryWhite,
                focusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.78f),
                unfocusedContainerColor = Color(0xFF0F172A).copy(alpha = 0.56f),
                focusedBorderColor = CyberCyan,
                unfocusedBorderColor = Color.White.copy(alpha = 0.16f),
                errorBorderColor = Color(0xFFEF4444),
                cursorColor = CyberCyan
            ),
            modifier = Modifier
                .fillMaxWidth()
                .then(if (testTagName.isNotEmpty()) Modifier.testTag(testTagName) else Modifier)
        )
        if (!supportingText.isNullOrBlank()) {
            Text(
                text = supportingText,
                style = MaterialTheme.typography.labelSmall,
                color = if (isError) Color(0xFFF87171) else NeonEmerald,
                modifier = Modifier.padding(top = 4.dp, start = 4.dp)
            )
        }
    }
}

@Composable
fun PrimaryGradientButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingEmoji: String? = null,
    testTagName: String = ""
) {
    val shape = RoundedCornerShape(14.dp)
    Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Transparent,
            disabledContainerColor = Color.White.copy(alpha = 0.08f)
        ),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(),
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .then(if (testTagName.isNotEmpty()) Modifier.testTag(testTagName) else Modifier)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    brush = if (enabled) {
                        Brush.horizontalGradient(
                            colors = listOf(ElectricIndigo, RoyalViolet, CyberCyan)
                        )
                    } else {
                        Brush.horizontalGradient(
                            colors = listOf(Color(0xFF334155), Color(0xFF1E293B))
                        )
                    },
                    shape = shape
                ),
            contentAlignment = Alignment.Center
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (leadingEmoji != null) {
                    Text(text = leadingEmoji, fontSize = 16.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                    text = text,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun GoogleSignInGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.08f))
            .border(1.dp, Color.White.copy(alpha = 0.22f), shape)
            .clickable(onClick = onClick)
            .testTag("google_sign_in_button"),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            // Custom multi-color Google 'G' badge
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "G",
                    color = Color(0xFF4285F4),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "Sign in with Google",
                color = TextPrimaryWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 14.5.sp
            )
        }
    }
}

@Composable
fun OctagonFooterSection(modifier: Modifier = Modifier) {
    var activeDialog by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "OCTAGON INC Copyright 2026",
            style = MaterialTheme.typography.labelLarge,
            color = TextSecondarySlate,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { activeDialog = "privacy" }) {
                Text("Privacy Policy", color = CyberCyan, fontSize = 12.sp)
            }
            Text("•", color = TextMutedSlate)
            TextButton(onClick = { activeDialog = "terms" }) {
                Text("Terms & Service", color = CyberCyan, fontSize = 12.sp)
            }
            Text("•", color = TextMutedSlate)
            TextButton(onClick = { activeDialog = "help" }) {
                Text("Help Center", color = CyberCyan, fontSize = 12.sp)
            }
        }
    }

    if (activeDialog != null) {
        val (title, body) = when (activeDialog) {
            "privacy" -> "Privacy Policy — Octagon Inc 2026" to
                "1. Local JWT & Key Security: Your personal Gemini API Key and signed HS256 JWT session token are stored locally on your device.\n\n" +
                "2. Data Minimization: Quizzes, AI Tutor derivations, and Pakistan Board syllabus preferences are persisted in your local Room database.\n\n" +
                "3. Prototype Security Notice: Do not share debug APKs containing embedded keys publicly."

            "terms" -> "Terms & Service — Octagon Inc 2026" to
                "• EduGlobal is an AI-powered Study & Exam Preparation command center tailored for Pakistan's Regional Examination Boards (FBISE, Punjab, Sindh, KPK, Balochistan, AKU-EB, and CAIE).\n\n" +
                "• All AI-generated model guess papers, LaTeX derivations, and customizable MCQ assessments are aligned with official SLO frameworks.\n\n" +
                "• All copyrights reserved by OCTAGON INC Copyright 2026."

            else -> "EduGlobal Help Center" to
                "• Gemini API Key: Obtain your personal key at https://aistudio.google.com/app/apikey\n\n" +
                "• Pakistan Mobile Validation: Enter your 11-digit mobile number in +92 3XX XXXXXXX or 03XX XXXXXXX format.\n\n" +
                "• LaTeX Math Engine: All equations (\${'$'}E = mc^2\${'$'}, fractions, roots, and integrals) render natively in publication-quality math notation."
        }

        AlertDialog(
            onDismissRequest = { activeDialog = null },
            containerColor = Color(0xFF111827),
            titleContentColor = TextPrimaryWhite,
            textContentColor = TextSecondarySlate,
            title = { Text(title, fontWeight = FontWeight.Bold) },
            text = { Text(body, lineHeight = 20.sp) },
            confirmButton = {
                TextButton(onClick = { activeDialog = null }) {
                    Text("Close", color = CyberCyan, fontWeight = FontWeight.Bold)
                }
            }
        )
    }
}
