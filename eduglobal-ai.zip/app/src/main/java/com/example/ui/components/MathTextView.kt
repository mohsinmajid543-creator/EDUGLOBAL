package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

object LatexSanitizer {
    private val blockFenceRegex = Regex("```(?:math|latex|tex)\\s*([\\s\\S]*?)\\s*```", RegexOption.IGNORE_CASE)
    private val genericFenceWithLatexRegex = Regex("```\\s*(\\\\[a-zA-Z]+[\\s\\S]*?)\\s*```")
    private val inlineBacktickLatexRegex = Regex("`(\\\\[a-zA-Z]+[^`\\n]*)`")
    private val codeTagRegex = Regex("<code>(\\\\[a-zA-Z]+[^<]*)</code>", RegexOption.IGNORE_CASE)
    private val doubleEscapedSlashRegex = Regex("\\\\\\\\([a-zA-Z]+)")

    /**
     * Strictly removes raw markdown code blocks wrapping math and normalizes LaTeX delimiters.
     */
    fun cleanLatexMathFormat(raw: String): String {
        if (raw.isBlank()) return ""
        var cleaned = raw
        cleaned = blockFenceRegex.replace(cleaned) { "\n\n$$${it.groupValues[1].trim()}$$\n\n" }
        cleaned = genericFenceWithLatexRegex.replace(cleaned) { "\n\n$$${it.groupValues[1].trim()}$$\n\n" }
        cleaned = inlineBacktickLatexRegex.replace(cleaned) { "$${it.groupValues[1].trim()}$" }
        cleaned = codeTagRegex.replace(cleaned) { "$${it.groupValues[1].trim()}$" }
        cleaned = doubleEscapedSlashRegex.replace(cleaned) { "\\${it.groupValues[1]}" }
        return cleaned.trim()
    }

    private val latexSymbolMap = linkedMapOf(
        "\\varepsilon_0" to "ε₀",
        "\\varepsilon" to "ε",
        "\\epsilon" to "ϵ",
        "\\alpha" to "α",
        "\\beta" to "β",
        "\\gamma" to "γ",
        "\\Gamma" to "Γ",
        "\\delta" to "δ",
        "\\Delta" to "Δ",
        "\\theta" to "θ",
        "\\Theta" to "Θ",
        "\\lambda" to "λ",
        "\\Lambda" to "Λ",
        "\\mu_0" to "μ₀",
        "\\mu" to "μ",
        "\\nu" to "ν",
        "\\pi" to "π",
        "\\Pi" to "Π",
        "\\rho" to "ρ",
        "\\sigma" to "σ",
        "\\Sigma" to "Σ",
        "\\tau" to "τ",
        "\\phi" to "φ",
        "\\Phi" to "Φ",
        "\\psi" to "ψ",
        "\\Psi" to "Ψ",
        "\\omega" to "ω",
        "\\Omega" to "Ω",
        "\\eta" to "η",
        "\\hbar" to "ℏ",
        "\\mathcal{E}" to "ℰ",
        "\\oint" to "∮",
        "\\int" to "∫",
        "\\sum" to "∑",
        "\\prod" to "∏",
        "\\partial" to "∂",
        "\\nabla" to "∇",
        "\\infty" to "∞",
        "\\pm" to "±",
        "\\mp" to "∓",
        "\\times" to "×",
        "\\cdot" to "·",
        "\\div" to "÷",
        "\\neq" to "≠",
        "\\leq" to "≤",
        "\\geq" to "≥",
        "\\ll" to "≪",
        "\\gg" to "≫",
        "\\approx" to "≈",
        "\\equiv" to "≡",
        "\\propto" to "∝",
        "\\implies" to "⟹",
        "\\iff" to "⟺",
        "\\rightleftharpoons" to "⇌",
        "\\rightarrow" to "→",
        "\\leftarrow" to "←",
        "\\circ" to "°",
        "\\quad" to "  ",
        "\\," to " ",
        "\\left(" to "(",
        "\\right)" to ")",
        "\\left[" to "[",
        "\\right]" to "]",
        "\\%" to "%"
    )

    fun replaceLatexCommands(expr: String): String {
        var out = expr
        // Handle \vec{X} and \hat{X}
        out = Regex("\\\\vec\\{([^}]+)\\}").replace(out) { "${it.groupValues[1]}⃗" }
        out = Regex("\\\\hat\\{([^}]+)\\}").replace(out) { "${it.groupValues[1]}̂" }
        out = Regex("\\\\text\\{([^}]+)\\}").replace(out) { it.groupValues[1] }
        out = Regex("\\\\mathbf\\{([^}]+)\\}").replace(out) { it.groupValues[1] }
        for ((k, v) in latexSymbolMap) {
            out = out.replace(k, v)
        }
        return out
    }
}

sealed class MathToken {
    data class Plain(val text: String) : MathToken()
    data class Fraction(val numerator: String, val denominator: String) : MathToken()
    data class Sqrt(val radicand: String) : MathToken()
}

fun tokenizeLatexExpression(latex: String): List<MathToken> {
    val tokens = mutableListOf<MathToken>()
    var idx = 0
    val buffer = StringBuilder()

    fun flushBuffer() {
        if (buffer.isNotEmpty()) {
            tokens.add(MathToken.Plain(buffer.toString()))
            buffer.clear()
        }
    }

    fun extractBracedGroup(startIdx: Int): Pair<String, Int>? {
        if (startIdx >= latex.length || latex[startIdx] != '{') return null
        var depth = 0
        val sb = StringBuilder()
        var i = startIdx
        while (i < latex.length) {
            val ch = latex[i]
            if (ch == '{') {
                if (depth > 0) sb.append(ch)
                depth++
            } else if (ch == '}') {
                depth--
                if (depth == 0) {
                    return sb.toString() to (i + 1)
                } else {
                    sb.append(ch)
                }
            } else {
                sb.append(ch)
            }
            i++
        }
        return null
    }

    while (idx < latex.length) {
        if (latex.startsWith("\\frac", idx)) {
            var cursor = idx + 5
            while (cursor < latex.length && latex[cursor].isWhitespace()) cursor++
            val numGroup = extractBracedGroup(cursor)
            if (numGroup != null) {
                cursor = numGroup.second
                while (cursor < latex.length && latex[cursor].isWhitespace()) cursor++
                val denGroup = extractBracedGroup(cursor)
                if (denGroup != null) {
                    flushBuffer()
                    tokens.add(MathToken.Fraction(numGroup.first, denGroup.first))
                    idx = denGroup.second
                    continue
                }
            }
        } else if (latex.startsWith("\\sqrt", idx)) {
            var cursor = idx + 5
            while (cursor < latex.length && latex[cursor].isWhitespace()) cursor++
            val radGroup = extractBracedGroup(cursor)
            if (radGroup != null) {
                flushBuffer()
                tokens.add(MathToken.Sqrt(radGroup.first))
                idx = radGroup.second
                continue
            }
        }
        buffer.append(latex[idx])
        idx++
    }
    flushBuffer()
    return tokens
}

fun buildRichMathAnnotatedString(
    rawSegment: String,
    isMathMode: Boolean,
    mathColor: Color
): AnnotatedString {
    val prepared = if (isMathMode) {
        var s = rawSegment
        // Convert inline nested \frac{a}{b} inside numerator/denominator or inline spans
        s = Regex("\\\\frac\\{([^}]+)\\}\\{([^}]+)\\}").replace(s) {
            "(${it.groupValues[1]})/(${it.groupValues[2]})"
        }
        s = Regex("\\\\sqrt\\{([^}]+)\\}").replace(s) {
            "√(${it.groupValues[1]})"
        }
        LatexSanitizer.replaceLatexCommands(s)
    } else {
        LatexSanitizer.replaceLatexCommands(rawSegment)
    }

    return buildAnnotatedString {
        var i = 0
        while (i < prepared.length) {
            val ch = prepared[i]
            if ((ch == '^' || ch == '_') && i + 1 < prepared.length) {
                val isSuper = ch == '^'
                val shift = if (isSuper) BaselineShift(0.32f) else BaselineShift(-0.24f)
                i++
                val content = if (prepared[i] == '{') {
                    val endBrace = prepared.indexOf('}', i + 1)
                    if (endBrace != -1) {
                        val sub = prepared.substring(i + 1, endBrace)
                        i = endBrace + 1
                        sub
                    } else {
                        val sub = prepared.substring(i + 1)
                        i = prepared.length
                        sub
                    }
                } else {
                    // Read single character or signed number/token
                    val start = i
                    if (prepared[i] == '+' || prepared[i] == '-') i++
                    while (i < prepared.length && (prepared[i].isLetterOrDigit() || prepared[i] == '°')) {
                        i++
                        if (i - start >= 3) break
                    }
                    if (i == start) {
                        i++
                    }
                    prepared.substring(start, i)
                }
                withStyle(
                    SpanStyle(
                        baselineShift = shift,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isMathMode) mathColor else Color.Unspecified
                    )
                ) {
                    append(LatexSanitizer.replaceLatexCommands(content))
                }
            } else if (!isMathMode && prepared.startsWith("**", i)) {
                val closeBold = prepared.indexOf("**", i + 2)
                if (closeBold != -1) {
                    withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = TextPrimaryWhite)) {
                        append(prepared.substring(i + 2, closeBold))
                    }
                    i = closeBold + 2
                } else {
                    append(ch)
                    i++
                }
            } else {
                if (isMathMode) {
                    withStyle(
                        SpanStyle(
                            color = mathColor,
                            fontFamily = FontFamily.Serif,
                            fontStyle = if (ch.isLetter() && ch in 'a'..'z') FontStyle.Italic else FontStyle.Normal,
                            fontWeight = FontWeight.Medium
                        )
                    ) {
                        append(ch)
                    }
                } else {
                    append(ch)
                }
                i++
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VisualMathFormulaRow(
    latexExpression: String,
    fontSize: TextUnit = 15.sp,
    mathColor: Color = Color(0xFFE0E7FF),
    modifier: Modifier = Modifier
) {
    val tokens = remember(latexExpression) { tokenizeLatexExpression(latexExpression.trim()) }

    FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalArrangement = Arrangement.Center
    ) {
        tokens.forEach { token ->
            when (token) {
                is MathToken.Plain -> {
                    val annotated = remember(token.text, mathColor) {
                        buildRichMathAnnotatedString(token.text, isMathMode = true, mathColor = mathColor)
                    }
                    Text(
                        text = annotated,
                        fontSize = fontSize,
                        color = mathColor,
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }

                is MathToken.Fraction -> {
                    val numAnnotated = remember(token.numerator, mathColor) {
                        buildRichMathAnnotatedString(token.numerator, isMathMode = true, mathColor = mathColor)
                    }
                    val denAnnotated = remember(token.denominator, mathColor) {
                        buildRichMathAnnotatedString(token.denominator, isMathMode = true, mathColor = mathColor)
                    }
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .width(IntrinsicSize.Max)
                            .padding(horizontal = 3.dp, vertical = 1.dp)
                            .align(Alignment.CenterVertically)
                    ) {
                        Text(
                            text = numAnnotated,
                            fontSize = (fontSize.value * 0.86f).sp,
                            color = mathColor,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        HorizontalDivider(
                            thickness = 1.2.dp,
                            color = CyberCyan.copy(alpha = 0.85f),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = denAnnotated,
                            fontSize = (fontSize.value * 0.86f).sp,
                            color = mathColor,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                    }
                }

                is MathToken.Sqrt -> {
                    val radAnnotated = remember(token.radicand, mathColor) {
                        buildRichMathAnnotatedString(token.radicand, isMathMode = true, mathColor = mathColor)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(horizontal = 2.dp)
                            .align(Alignment.CenterVertically)
                    ) {
                        Text(
                            text = "√",
                            fontSize = (fontSize.value * 1.15f).sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberCyan
                        )
                        Box(
                            modifier = Modifier
                                .border(
                                    width = 1.dp,
                                    color = CyberCyan.copy(alpha = 0.45f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = radAnnotated,
                                fontSize = (fontSize.value * 0.92f).sp,
                                color = mathColor,
                                style = TextStyle(textDecoration = TextDecoration.None)
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * Renders full Markdown + Inline ($...$) and Block ($$...$$) LaTeX equations cleanly in Jetpack Compose.
 * Strictly strips any raw ```math or ```latex fences before rendering.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MathTextView(
    content: String,
    modifier: Modifier = Modifier,
    textColor: Color = TextPrimaryWhite,
    mathHighlightColor: Color = Color(0xFFC7D2FE),
    fontSize: TextUnit = 14.5.sp
) {
    val sanitized = remember(content) { LatexSanitizer.cleanLatexMathFormat(content) }
    val blockParts = remember(sanitized) {
        val list = mutableListOf<Pair<Boolean, String>>()
        val regex = Regex("\\$\\$([\\s\\S]*?)\\$\\$")
        var lastIdx = 0
        for (match in regex.findAll(sanitized)) {
            if (match.range.first > lastIdx) {
                list.add(false to sanitized.substring(lastIdx, match.range.first))
            }
            list.add(true to match.groupValues[1].trim())
            lastIdx = match.range.last + 1
        }
        if (lastIdx < sanitized.length) {
            list.add(false to sanitized.substring(lastIdx))
        }
        list
    }

    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        blockParts.forEach { (isDisplayMath, segment) ->
            if (isDisplayMath) {
                // Render elevated Glassmorphic Block Math Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    ElectricIndigo.copy(alpha = 0.16f),
                                    CyberCyan.copy(alpha = 0.10f)
                                )
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    ElectricIndigo.copy(alpha = 0.6f),
                                    CyberCyan.copy(alpha = 0.45f)
                                )
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    VisualMathFormulaRow(
                        latexExpression = segment,
                        fontSize = (fontSize.value + 1.5f).sp,
                        mathColor = Color(0xFFE0F2FE)
                    )
                }
            } else {
                val lines = segment.lines()
                lines.forEach { rawLine ->
                    val line = rawLine.trim()
                    if (line.isEmpty()) {
                        Spacer(modifier = Modifier.height(2.dp))
                    } else if (line == "---") {
                        HorizontalDivider(
                            color = Color.White.copy(alpha = 0.12f),
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else if (line.startsWith("### ")) {
                        Text(
                            text = line.removePrefix("### ").trim(),
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberCyan,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    } else if (line.startsWith("#### ")) {
                        Text(
                            text = line.removePrefix("#### ").trim(),
                            style = MaterialTheme.typography.labelLarge,
                            color = Color(0xFFA5B4FC),
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    } else if (line.startsWith("> ")) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    ElectricIndigo.copy(alpha = 0.12f),
                                    RoundedCornerShape(8.dp)
                                )
                                .border(
                                    1.dp,
                                    ElectricIndigo.copy(alpha = 0.35f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(10.dp)
                        ) {
                            InlineMathParagraph(
                                line = line.removePrefix("> ").trim(),
                                textColor = TextSecondarySlate,
                                mathColor = mathHighlightColor,
                                fontSize = (fontSize.value - 0.5f).sp
                            )
                        }
                    } else {
                        InlineMathParagraph(
                            line = line,
                            textColor = textColor,
                            mathColor = mathHighlightColor,
                            fontSize = fontSize
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InlineMathParagraph(
    line: String,
    textColor: Color,
    mathColor: Color,
    fontSize: TextUnit
) {
    val inlineSegments = remember(line) {
        val list = mutableListOf<Pair<Boolean, String>>()
        val inlineRegex = Regex("\\$([^$]+)\\$")
        var lastIdx = 0
        for (m in inlineRegex.findAll(line)) {
            if (m.range.first > lastIdx) {
                list.add(false to line.substring(lastIdx, m.range.first))
            }
            list.add(true to m.groupValues[1])
            lastIdx = m.range.last + 1
        }
        if (lastIdx < line.length) {
            list.add(false to line.substring(lastIdx))
        }
        list
    }

    // Check if any inline math contains \frac or \sqrt for visual stacked rendering
    val hasComplexInlineMath = remember(inlineSegments) {
        inlineSegments.any { (isMath, seg) ->
            isMath && (seg.contains("\\frac") || seg.contains("\\sqrt"))
        }
    }

    if (hasComplexInlineMath) {
        FlowRow(
            verticalArrangement = Arrangement.Center,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            inlineSegments.forEach { (isMath, seg) ->
                if (isMath) {
                    VisualMathFormulaRow(
                        latexExpression = seg,
                        fontSize = fontSize,
                        mathColor = mathColor,
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                } else {
                    val annotated = remember(seg, textColor) {
                        buildRichMathAnnotatedString(seg, isMathMode = false, mathColor = textColor)
                    }
                    Text(
                        text = annotated,
                        color = textColor,
                        fontSize = fontSize,
                        modifier = Modifier.align(Alignment.CenterVertically)
                    )
                }
            }
        }
    } else {
        val combinedAnnotated = remember(inlineSegments, textColor, mathColor) {
            buildAnnotatedString {
                inlineSegments.forEach { (isMath, seg) ->
                    append(
                        buildRichMathAnnotatedString(
                            rawSegment = seg,
                            isMathMode = isMath,
                            mathColor = if (isMath) mathColor else textColor
                        )
                    )
                }
            }
        }
        Text(
            text = combinedAnnotated,
            color = textColor,
            fontSize = fontSize,
            lineHeight = (fontSize.value * 1.45f).sp
        )
    }
}
