package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.auth.JwtAuthManager
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.SubjectEntity
import com.example.data.local.UserEntity
import com.example.data.model.AcademicCatalog
import com.example.data.model.BadgeMetricType
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.MathTextView
import com.example.ui.components.OctagonFooterSection
import com.example.ui.components.PrimaryGradientButton
import com.example.ui.components.RechartsStudentProgressDashboard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.AppDestination

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DashboardScreen(
    user: UserEntity?,
    selectedBoard: String,
    selectedSubject: String,
    subjects: List<SubjectEntity>,
    quizAttempts: List<QuizAttemptEntity> = emptyList(),
    showStreakToast: Boolean,
    onSelectBoard: (String) -> Unit,
    onSelectSubject: (String) -> Unit,
    onAddCustomSubject: (String, String) -> Unit,
    onUpdateSubjectProgress: (SubjectEntity, Int) -> Unit = { _, _ -> },
    onDismissStreakToast: () -> Unit,
    onClaimStreakBonus: () -> Unit,
    onNavigate: (AppDestination) -> Unit,
    onOpenAuthModal: () -> Unit
) {
    var boardExpanded by remember { mutableStateOf(false) }
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var newSubjectName by remember { mutableStateOf("") }
    var newSubjectCategory by remember { mutableStateOf("Custom Board Elective") }

    val displayName = remember(user) {
        if (user != null) "${user.firstName} ${user.lastName}".trim() else "Majid Fayyaz"
    }
    val streakDays = user?.streakDays ?: 9
    val scholarXp = user?.scholarXp ?: 860
    val studyHours = user?.studyHours ?: 28.5f
    val quizzesDone = user?.quizzesCompleted ?: 16
    val avgAccuracy = user?.quizAvgScore ?: 92

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Header Card with Generated Hero Illustration & JWT Session Badge
        GlassmorphicCard(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 24.dp,
            borderAlpha = 0.30f
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                Image(
                    painter = painterResource(id = R.drawable.img_eduglobal_hero),
                    contentDescription = "EduGlobal Academic Command Center Hero",
                    contentScale = ContentScale.Crop,
                    alpha = 0.32f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(210.dp)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF070A12).copy(alpha = 0.45f),
                                    Color(0xFF0B0F19).copy(alpha = 0.92f)
                                )
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(
                                    NeonEmerald.copy(alpha = 0.18f),
                                    RoundedCornerShape(50)
                                )
                                .border(1.dp, NeonEmerald.copy(alpha = 0.5f), RoundedCornerShape(50))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VerifiedUser,
                                contentDescription = null,
                                tint = NeonEmerald,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "JWT VERIFIED SCHOLAR",
                                color = NeonEmerald,
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(Color.White.copy(alpha = 0.10f))
                                .clickable { onNavigate(AppDestination.PROFILE) }
                                .padding(horizontal = 10.dp, vertical = 5.dp)
                                .testTag("dashboard_profile_chip")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Key,
                                contentDescription = "API Key & JWT",
                                tint = CyberCyan,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = "API Key & JWT",
                                color = CyberCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Salam, $displayName 👋",
                        style = MaterialTheme.typography.headlineMedium,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "$selectedBoard • Active Subject: $selectedSubject",
                        style = MaterialTheme.typography.bodyMedium,
                        color = CyberCyan,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        QuickActionHeroChip(
                            title = "Ask AI Tutor",
                            icon = Icons.Default.AutoAwesome,
                            accent = ElectricIndigo,
                            onClick = { onNavigate(AppDestination.AI_TUTOR) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionHeroChip(
                            title = "Custom Quiz",
                            icon = Icons.Default.Quiz,
                            accent = CyberCyan,
                            onClick = { onNavigate(AppDestination.QUIZ_ENGINE) },
                            modifier = Modifier.weight(1f)
                        )
                        QuickActionHeroChip(
                            title = "Exam Hub",
                            icon = Icons.Default.School,
                            accent = NeonEmerald,
                            onClick = { onNavigate(AppDestination.EXAM_HUB) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 2. Daily Study Streak Toast Banner
        AnimatedVisibility(visible = showStreakToast) {
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 18.dp,
                accentHighlight = AmberGold
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFFEA580C), Color(0xFFDC2626))
                                    ),
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🔥", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = "$streakDays-DAY STUDY STREAK",
                                    color = AmberGold,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = "• +50 XP",
                                    color = NeonEmerald,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Text(
                                text = "Keep your daily board exam discipline active to unlock Gold & Diamond badges!",
                                color = TextSecondarySlate,
                                fontSize = 12.sp
                            )
                        }
                    }
                    IconButton(onClick = onDismissStreakToast) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Dismiss streak banner",
                            tint = TextSecondarySlate
                        )
                    }
                }
            }
        }

        // 3. Pakistan Regional Boards Selector + User Profile Quick Card
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🇵🇰 Pakistan Regional Board Authority",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                    TextButton(onClick = onOpenAuthModal) {
                        Text("Switch Account", color = CyberCyan, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                ExposedDropdownMenuBox(
                    expanded = boardExpanded,
                    onExpandedChange = { boardExpanded = !boardExpanded }
                ) {
                    OutlinedTextField(
                        value = selectedBoard,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(expanded = boardExpanded)
                        },
                        shape = RoundedCornerShape(14.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimaryWhite,
                            unfocusedTextColor = TextPrimaryWhite,
                            focusedContainerColor = Color(0xFF0B0F19),
                            unfocusedContainerColor = Color(0xFF0B0F19),
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.18f)
                        ),
                        modifier = Modifier
                            .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                            .fillMaxWidth()
                            .testTag("dashboard_board_selector")
                    )
                    ExposedDropdownMenu(
                        expanded = boardExpanded,
                        onDismissRequest = { boardExpanded = false },
                        containerColor = Color(0xFF111827)
                    ) {
                        AcademicCatalog.PAKISTAN_BOARDS.forEach { board ->
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = board,
                                        color = TextPrimaryWhite,
                                        fontSize = 13.5.sp
                                    )
                                },
                                onClick = {
                                    onSelectBoard(board)
                                    boardExpanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = " Verified Phone: ${JwtAuthManager.formatPakistanDisplayPhone(user?.phone ?: "+923005551234")} • ${user?.gradeLevel ?: "Class 11 / FSc Part 1"}",
                    color = TextSecondarySlate,
                    fontSize = 12.sp
                )
            }
        }

        // 4. Dynamic Subject Selector & Custom Subject Creator
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "📚 Dynamic Subject Selector",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Tap any subject to calibrate AI Tutor, Quizzes & Guess Papers",
                            color = TextSecondarySlate,
                            fontSize = 12.sp
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(ElectricIndigo.copy(alpha = 0.22f))
                            .border(1.dp, ElectricIndigo.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
                            .clickable { showAddSubjectDialog = true }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("add_custom_subject_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Add,
                                contentDescription = "Add Custom Subject",
                                tint = CyberCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Custom",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    subjects.forEach { sub ->
                        val isSelected = sub.name.equals(selectedSubject, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (isSelected) {
                                        Brush.horizontalGradient(listOf(ElectricIndigo, CyberCyan))
                                    } else {
                                        Brush.horizontalGradient(
                                            listOf(
                                                Color.White.copy(alpha = 0.06f),
                                                Color.White.copy(alpha = 0.06f)
                                            )
                                        )
                                    }
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) Color.White.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(50)
                                )
                                .clickable { onSelectSubject(sub.name) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = "${sub.name} (${sub.progressPercent}%)",
                                color = if (isSelected) Color.White else TextSecondarySlate,
                                fontSize = 12.5.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        // 5. Key Progress Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricGlassTile(
                value = "${studyHours}h",
                label = "Study Hours",
                subtext = "71% of Monthly Goal",
                accent = ElectricIndigo,
                modifier = Modifier.weight(1f)
            )
            MetricGlassTile(
                value = "$quizzesDone",
                label = "Quizzes Done",
                subtext = "$avgAccuracy% Avg Accuracy",
                accent = CyberCyan,
                modifier = Modifier.weight(1f)
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricGlassTile(
                value = "$streakDays Days",
                label = "Active Streak",
                subtext = "Tap below for +50 XP",
                accent = AmberGold,
                modifier = Modifier.weight(1f)
            )
            MetricGlassTile(
                value = "$scholarXp XP",
                label = "Scholar XP",
                subtext = "Rank: Elite Scholar",
                accent = NeonEmerald,
                modifier = Modifier.weight(1f)
            )
        }

        // 5b. Interactive Recharts Visual Analytics Dashboard (Subjects & Board Topics)
        RechartsStudentProgressDashboard(
            selectedBoard = selectedBoard,
            selectedSubject = selectedSubject,
            subjects = subjects,
            quizAttempts = quizAttempts,
            onSelectSubject = onSelectSubject,
            onUpdateSubjectProgress = onUpdateSubjectProgress
        )

        // 6. Live LaTeX Equation Preview Card on Dashboard
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Text(
                    text = "📐 Daily Board Formula Spotlight ($selectedSubject)",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(6.dp))
                MathTextView(
                    content = """
- **Quadratic Root Formula:** ${'$'}x = \frac{-b \pm \sqrt{b^2 - 4ac}}{2a}${'$'}
- **Carnot Heat Engine Efficiency:** ${'$'}\eta = 1 - \frac{T_C}{T_H}${'$'}
- **Relativistic Energy-Momentum Invariant:**
${'$'}${'$'}E = \sqrt{p^2 c^2 + m_0^2 c^4}${'$'}${'$'}
                    """.trimIndent()
                )
            }
        }

        // 7. Gamification Badges Horizontal Showcase
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "🏅 Scholar Achievement Badges",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                    TextButton(onClick = onClaimStreakBonus) {
                        Text("🔥 Claim +1 Streak", color = AmberGold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AcademicCatalog.BADGE_CATALOG.forEach { badge ->
                        val currentMetric = when (badge.metricType) {
                            BadgeMetricType.STREAK_DAYS -> streakDays
                            BadgeMetricType.QUIZZES_COMPLETED -> quizzesDone
                            BadgeMetricType.BEST_QUIZ_SCORE -> user?.bestQuizScore ?: 100
                            BadgeMetricType.AVG_QUIZ_SCORE -> avgAccuracy
                            BadgeMetricType.EXTREME_QUIZZES -> user?.extremeQuizzesCompleted ?: 1
                            BadgeMetricType.SCHOLAR_XP -> scholarXp
                        }
                        val unlocked = currentMetric >= badge.target
                        val progress = (currentMetric.toFloat() / badge.target.toFloat()).coerceIn(0f, 1f)

                        Box(
                            modifier = Modifier
                                .width(205.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(
                                    if (unlocked) {
                                        NeonEmerald.copy(alpha = 0.12f)
                                    } else {
                                        Color.White.copy(alpha = 0.04f)
                                    }
                                )
                                .border(
                                    1.dp,
                                    if (unlocked) NeonEmerald.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.12f),
                                    RoundedCornerShape(16.dp)
                                )
                                .padding(14.dp)
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = badge.icon, fontSize = 24.sp)
                                    Text(
                                        text = "+${badge.xpReward} XP",
                                        color = if (unlocked) NeonEmerald else CyberCyan,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = badge.title,
                                    color = TextPrimaryWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = badge.description,
                                    color = TextSecondarySlate,
                                    fontSize = 11.5.sp,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                                LinearProgressIndicator(
                                    progress = { progress },
                                    color = if (unlocked) NeonEmerald else CyberCyan,
                                    trackColor = Color.White.copy(alpha = 0.12f),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(50))
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (unlocked) "✅ UNLOCKED (${badge.rarity})" else "🔒 $currentMetric / ${badge.target}",
                                    color = if (unlocked) NeonEmerald else TextMutedSlate,
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        OctagonFooterSection()
    }

    if (showAddSubjectDialog) {
        AlertDialog(
            onDismissRequest = { showAddSubjectDialog = false },
            containerColor = Color(0xFF111827),
            titleContentColor = TextPrimaryWhite,
            textContentColor = TextSecondarySlate,
            title = { Text("Add Custom Subject", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    GlassTextField(
                        value = newSubjectName,
                        onValueChange = { newSubjectName = it },
                        label = "Subject Name",
                        placeholder = "e.g. Astrophysics, Sociology, Urdu Literature"
                    )
                    GlassTextField(
                        value = newSubjectCategory,
                        onValueChange = { newSubjectCategory = it },
                        label = "Syllabus Category",
                        placeholder = "e.g. Elective / Humanities / STEM"
                    )
                }
            },
            confirmButton = {
                PrimaryGradientButton(
                    text = "Add to Subject Hub",
                    onClick = {
                        if (newSubjectName.isNotBlank()) {
                            onAddCustomSubject(newSubjectName, newSubjectCategory)
                            newSubjectName = ""
                            showAddSubjectDialog = false
                        }
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { showAddSubjectDialog = false }) {
                    Text("Cancel", color = TextSecondarySlate)
                }
            }
        )
    }
}

@Composable
private fun QuickActionHeroChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(accent.copy(alpha = 0.22f))
            .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = title,
                color = Color.White,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MetricGlassTile(
    value: String,
    label: String,
    subtext: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    GlassmorphicCard(
        modifier = modifier,
        cornerRadius = 18.dp,
        accentHighlight = accent
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = value,
                color = accent,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = label,
                color = TextPrimaryWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 2.dp)
            )
            Text(
                text = subtext,
                color = NeonEmerald,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
