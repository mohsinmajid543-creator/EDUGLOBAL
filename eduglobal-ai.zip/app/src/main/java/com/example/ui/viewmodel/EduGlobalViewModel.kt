package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.auth.JwtAuthManager
import com.example.data.auth.JwtClaims
import com.example.data.local.ChatMessageEntity
import com.example.data.local.EduGlobalDatabase
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.SavedPaperEntity
import com.example.data.local.SessionEntity
import com.example.data.local.SubjectEntity
import com.example.data.local.UserEntity
import com.example.data.model.AcademicCatalog
import com.example.data.model.GeminiModelTier
import com.example.data.model.QuizQuestionItem
import com.example.data.model.TutorRolePersona
import com.example.data.remote.CloudSyncTelemetry
import com.example.data.remote.FirebaseCloudSyncManager
import com.example.data.repository.EduGlobalRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AppDestination {
    DASHBOARD,
    AI_TUTOR,
    QUIZ_ENGINE,
    EXAM_HUB,
    PROFILE
}

data class ActiveQuizState(
    val isGenerating: Boolean = false,
    val subject: String = "Physics",
    val topic: String = "Coulomb's Law, Gauss Divergence & Thermodynamics",
    val difficulty: String = "Medium",
    val requestedCount: Int = 15,
    val questions: List<QuizQuestionItem> = emptyList(),
    val selectedAnswers: Map<Int, Int> = emptyMap(),
    val isSubmitted: Boolean = false,
    val scorePercent: Int = 0,
    val xpAwarded: Int = 0
)

@OptIn(ExperimentalCoroutinesApi::class)
class EduGlobalViewModel(application: Application) : AndroidViewModel(application) {

    private val database = EduGlobalDatabase.getInstance(application)
    private val repository = EduGlobalRepository(database.dao())

    val activeSession: StateFlow<SessionEntity?> = repository.observeActiveSession()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val currentUser: StateFlow<UserEntity?> = activeSession
        .flatMapLatest { session ->
            if (session != null && JwtAuthManager.verifyAndDecodeJwt(session.jwtToken) != null) {
                repository.observeUser(session.userEmail)
            } else {
                flowOf(null)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val subjects: StateFlow<List<SubjectEntity>> = repository.observeAllSubjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatMessages: StateFlow<List<ChatMessageEntity>> = activeSession
        .flatMapLatest { session ->
            if (session != null) repository.observeChatMessages(session.userEmail) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quizAttempts: StateFlow<List<QuizAttemptEntity>> = activeSession
        .flatMapLatest { session ->
            if (session != null) repository.observeQuizAttempts(session.userEmail) else flowOf(emptyList())
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedPapers: StateFlow<List<SavedPaperEntity>> = repository.observeSavedPapers()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentDestination = MutableStateFlow(AppDestination.DASHBOARD)
    val currentDestination: StateFlow<AppDestination> = _currentDestination.asStateFlow()

    private val _selectedSubject = MutableStateFlow("Physics")
    val selectedSubject: StateFlow<String> = _selectedSubject.asStateFlow()

    private val _selectedBoard = MutableStateFlow(AcademicCatalog.PAKISTAN_BOARDS.first())
    val selectedBoard: StateFlow<String> = _selectedBoard.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _authSuccessBanner = MutableStateFlow<String?>(null)
    val authSuccessBanner: StateFlow<String?> = _authSuccessBanner.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _showAuthModalOverlay = MutableStateFlow(false)
    val showAuthModalOverlay: StateFlow<Boolean> = _showAuthModalOverlay.asStateFlow()

    private val _showStreakToast = MutableStateFlow(true)
    val showStreakToast: StateFlow<Boolean> = _showStreakToast.asStateFlow()

    private val _isTutorThinking = MutableStateFlow(false)
    val isTutorThinking: StateFlow<Boolean> = _isTutorThinking.asStateFlow()

    private val _selectedModelTier = MutableStateFlow(GeminiModelTier.COMPLEX_PRO)
    val selectedModelTier: StateFlow<GeminiModelTier> = _selectedModelTier.asStateFlow()

    private val _selectedTutorRole = MutableStateFlow(TutorRolePersona.SOCRATIC_PROFESSOR)
    val selectedTutorRole: StateFlow<TutorRolePersona> = _selectedTutorRole.asStateFlow()

    private val _customSystemInstruction = MutableStateFlow(
        TutorRolePersona.SOCRATIC_PROFESSOR.defaultSystemInstruction
    )
    val customSystemInstruction: StateFlow<String> = _customSystemInstruction.asStateFlow()

    val cloudTelemetry: StateFlow<CloudSyncTelemetry> = FirebaseCloudSyncManager.telemetry

    private val _quizState = MutableStateFlow(ActiveQuizState())
    val quizState: StateFlow<ActiveQuizState> = _quizState.asStateFlow()

    private val _isPaperGenerating = MutableStateFlow(false)
    val isPaperGenerating: StateFlow<Boolean> = _isPaperGenerating.asStateFlow()

    private val _activeGuessPaper = MutableStateFlow<SavedPaperEntity?>(null)
    val activeGuessPaper: StateFlow<SavedPaperEntity?> = _activeGuessPaper.asStateFlow()

    init {
        FirebaseCloudSyncManager.isFirebaseAvailable(application)
        viewModelScope.launch {
            repository.ensureSeedData()
            // Pre-generate an initial 15-question quiz and initial guess paper so UI is rich immediately
            val initialQuestions = repository.generateQuizQuestions(
                apiKey = "",
                subject = "Physics",
                topic = "Coulomb's Law, Gauss Divergence & Thermodynamics",
                board = AcademicCatalog.PAKISTAN_BOARDS.first(),
                difficulty = "Medium",
                count = 15
            )
            _quizState.value = _quizState.value.copy(questions = initialQuestions)

            val initialPaper = repository.generateAndSaveGuessPaper(
                apiKey = "",
                subject = "Physics",
                topic = "Thermodynamics & Carnot Heat Engine",
                board = AcademicCatalog.PAKISTAN_BOARDS.first(),
                gradeLevel = AcademicCatalog.GRADE_LEVELS[2]
            )
            _activeGuessPaper.value = initialPaper
        }
    }

    fun navigateTo(destination: AppDestination) {
        _currentDestination.value = destination
    }

    fun selectSubject(subjectName: String) {
        _selectedSubject.value = subjectName
        _quizState.value = _quizState.value.copy(subject = subjectName)
    }

    fun selectBoard(boardName: String) {
        _selectedBoard.value = boardName
        val email = activeSession.value?.userEmail ?: return
        viewModelScope.launch {
            repository.updateBoardSelection(email, boardName)
        }
    }

    fun clearAuthMessages() {
        _authError.value = null
        _authSuccessBanner.value = null
    }

    fun openAuthModalOverlay() {
        _showAuthModalOverlay.value = true
    }

    fun dismissAuthModalOverlay() {
        _showAuthModalOverlay.value = false
    }

    fun dismissStreakToast() {
        _showStreakToast.value = false
    }

    fun claimDailyStreak() {
        val email = activeSession.value?.userEmail ?: return
        viewModelScope.launch {
            repository.claimDailyStreakBonus(email)
            _showStreakToast.value = true
        }
    }

    fun signUpWithJwt(
        firstName: String,
        lastName: String,
        email: String,
        pakistanPhone: String,
        password: String,
        geminiApiKey: String,
        board: String,
        gradeLevel: String
    ) {
        _authError.value = null
        if (firstName.isBlank() || lastName.isBlank()) {
            _authError.value = "Please enter both your First Name and Last Name."
            return
        }
        if (email.isBlank() || !email.contains("@")) {
            _authError.value = "Please enter a valid Email Address."
            return
        }
        if (!JwtAuthManager.isValidPakistanMobile(pakistanPhone)) {
            _authError.value = "Enter a valid 11-digit Pakistan mobile number (+92 3XX XXXXXXX or 03XX XXXXXXX)."
            return
        }
        if (password.length < 6) {
            _authError.value = "Password must be at least 6 characters for JWT encryption."
            return
        }
        if (geminiApiKey.isBlank()) {
            _authError.value = "Please enter your personal Gemini API Key (or tap Quick Demo Fill)."
            return
        }

        _isAuthLoading.value = true
        viewModelScope.launch {
            val result = repository.registerUserWithJwt(
                firstName = firstName,
                lastName = lastName,
                email = email,
                pakistanPhone = pakistanPhone,
                password = password,
                geminiApiKey = geminiApiKey,
                selectedBoard = board,
                gradeLevel = gradeLevel
            )
            _isAuthLoading.value = false
            result.onSuccess { claims ->
                _selectedBoard.value = claims.board
                _showAuthModalOverlay.value = false
                _showStreakToast.value = true
                _authSuccessBanner.value = "JWT Session Verified for ${claims.fullName}"
            }.onFailure { err ->
                _authError.value = err.message ?: "Registration failed."
            }
        }
    }

    fun signInWithJwt(
        email: String,
        password: String,
        geminiApiKey: String
    ) {
        _authError.value = null
        if (email.isBlank() || !email.contains("@")) {
            _authError.value = "Please enter your registered Email Address."
            return
        }
        if (password.isBlank()) {
            _authError.value = "Please enter your account password."
            return
        }

        _isAuthLoading.value = true
        viewModelScope.launch {
            val result = repository.signInWithJwt(
                email = email,
                password = password,
                geminiApiKeyInput = geminiApiKey
            )
            _isAuthLoading.value = false
            result.onSuccess { claims ->
                _selectedBoard.value = claims.board
                _showAuthModalOverlay.value = false
                _showStreakToast.value = true
                _authSuccessBanner.value = "Welcome back, ${claims.fullName}!"
            }.onFailure { err ->
                _authError.value = err.message ?: "Authentication failed."
            }
        }
    }

    fun signInWithGoogle(geminiApiKey: String, activityContext: Context? = null) {
        _authError.value = null
        _isAuthLoading.value = true
        viewModelScope.launch {
            val keyToUse = geminiApiKey.ifBlank { "DEMO_KEY_GOOGLE_SCHOLAR_2026" }
            val result = repository.signInWithGoogleOAuthJwt(keyToUse, activityContext)
            _isAuthLoading.value = false
            result.onSuccess { claims ->
                _selectedBoard.value = claims.board
                _showAuthModalOverlay.value = false
                _showStreakToast.value = true
                _authSuccessBanner.value = "Signed in with Google (${claims.sub})"
            }.onFailure { err ->
                _authError.value = err.message ?: "Google Sign-In failed."
            }
        }
    }

    fun selectModelTier(tier: GeminiModelTier) {
        _selectedModelTier.value = tier
    }

    fun selectTutorRole(role: TutorRolePersona) {
        _selectedTutorRole.value = role
        _customSystemInstruction.value = role.defaultSystemInstruction
    }

    fun updateCustomSystemInstruction(instruction: String) {
        _customSystemInstruction.value = instruction
    }

    fun syncNowToFirestore() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            FirebaseCloudSyncManager.syncAllUserDataToFirestore(
                user = user,
                subjects = subjects.value,
                quizAttempts = quizAttempts.value,
                chatMessages = chatMessages.value
            )
        }
    }

    fun refreshJwtToken() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            repository.refreshJwtSession(user)
        }
    }

    fun updateProfileAndApiKey(
        firstName: String,
        lastName: String,
        phone: String,
        board: String,
        gradeLevel: String,
        apiKey: String
    ) {
        val email = activeSession.value?.userEmail ?: return
        viewModelScope.launch {
            repository.updateUserProfileAndApiKey(
                email = email,
                firstName = firstName,
                lastName = lastName,
                phone = phone,
                board = board,
                gradeLevel = gradeLevel,
                apiKey = apiKey
            )
            _selectedBoard.value = board
        }
    }

    fun addCustomSubject(subjectName: String, category: String) {
        viewModelScope.launch {
            repository.addCustomSubject(subjectName, category)
            _selectedSubject.value = subjectName.trim()
        }
    }

    fun updateSubjectProgress(subject: SubjectEntity, newProgressPercent: Int) {
        viewModelScope.launch {
            repository.updateSubjectProgress(subject, newProgressPercent)
        }
    }

    fun askTutor(question: String) {
        if (question.isBlank()) return
        val session = activeSession.value
        val user = currentUser.value
        val email = session?.userEmail ?: "majidfayyazabbasi@gmail.com"
        val apiKey = user?.geminiApiKey ?: session?.geminiApiKey ?: ""
        val board = user?.selectedBoard ?: _selectedBoard.value
        val grade = user?.gradeLevel ?: AcademicCatalog.GRADE_LEVELS[2]
        val subject = _selectedSubject.value
        val historySnapshot = chatMessages.value

        _isTutorThinking.value = true
        viewModelScope.launch {
            repository.sendTutorQuestion(
                userEmail = email,
                apiKey = apiKey,
                subject = subject,
                board = board,
                gradeLevel = grade,
                question = question.trim(),
                conversationHistory = historySnapshot,
                modelTier = _selectedModelTier.value,
                rolePersona = _selectedTutorRole.value,
                customSystemInstruction = _customSystemInstruction.value
            )
            _isTutorThinking.value = false
        }
    }

    fun clearTutorChat() {
        val email = activeSession.value?.userEmail ?: "majidfayyazabbasi@gmail.com"
        val board = currentUser.value?.selectedBoard ?: _selectedBoard.value
        viewModelScope.launch {
            repository.clearTutorHistory(email, board)
        }
    }

    fun generateQuiz(
        subject: String,
        topic: String,
        difficulty: String,
        count: Int
    ) {
        val safeCount = count.coerceIn(1, 50)
        val apiKey = currentUser.value?.geminiApiKey ?: activeSession.value?.geminiApiKey ?: ""
        val board = currentUser.value?.selectedBoard ?: _selectedBoard.value
        _quizState.value = _quizState.value.copy(
            isGenerating = true,
            subject = subject,
            topic = topic,
            difficulty = difficulty,
            requestedCount = safeCount,
            selectedAnswers = emptyMap(),
            isSubmitted = false,
            scorePercent = 0,
            xpAwarded = 0
        )
        viewModelScope.launch {
            val generated = repository.generateQuizQuestions(
                apiKey = apiKey,
                subject = subject,
                topic = topic,
                board = board,
                difficulty = difficulty,
                count = safeCount
            )
            _quizState.value = _quizState.value.copy(
                isGenerating = false,
                questions = generated
            )
        }
    }

    fun selectQuizOption(questionIndex: Int, optionIndex: Int) {
        if (_quizState.value.isSubmitted) return
        val updated = _quizState.value.selectedAnswers.toMutableMap()
        updated[questionIndex] = optionIndex
        _quizState.value = _quizState.value.copy(selectedAnswers = updated)
    }

    fun submitQuizForGrading() {
        val state = _quizState.value
        if (state.questions.isEmpty() || state.isSubmitted) return
        var correctCount = 0
        state.questions.forEachIndexed { index, item ->
            val chosen = state.selectedAnswers[index] ?: 0
            if (chosen == item.correctIndex) {
                correctCount++
            }
        }
        val total = state.questions.size
        val scorePct = (correctCount * 100) / total
        val email = activeSession.value?.userEmail ?: "majidfayyazabbasi@gmail.com"
        val board = currentUser.value?.selectedBoard ?: _selectedBoard.value

        viewModelScope.launch {
            val xp = repository.recordQuizCompletion(
                email = email,
                subject = state.subject,
                topic = state.topic,
                board = board,
                difficulty = state.difficulty,
                totalQuestions = total,
                correctAnswers = correctCount
            )
            _quizState.value = _quizState.value.copy(
                isSubmitted = true,
                scorePercent = scorePct,
                xpAwarded = xp
            )
        }
    }

    fun generateBoardPaper(
        subject: String,
        topic: String,
        board: String,
        gradeLevel: String
    ) {
        val apiKey = currentUser.value?.geminiApiKey ?: activeSession.value?.geminiApiKey ?: ""
        _isPaperGenerating.value = true
        viewModelScope.launch {
            val saved = repository.generateAndSaveGuessPaper(
                apiKey = apiKey,
                subject = subject,
                topic = topic,
                board = board,
                gradeLevel = gradeLevel
            )
            _activeGuessPaper.value = saved
            _isPaperGenerating.value = false
        }
    }

    fun selectSavedPaper(paper: SavedPaperEntity) {
        _activeGuessPaper.value = paper
    }

    fun logout() {
        viewModelScope.launch {
            repository.logoutSession()
            _currentDestination.value = AppDestination.DASHBOARD
        }
    }

    fun getVerifiedJwtClaims(): JwtClaims? {
        val token = activeSession.value?.jwtToken ?: return null
        return JwtAuthManager.verifyAndDecodeJwt(token)
    }
}
