package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SubjectEntity
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.MathTextView
import com.example.ui.components.OctagonFooterSection
import com.example.ui.components.PrimaryGradientButton
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import com.example.ui.viewmodel.ActiveQuizState

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuizEngineScreen(
    selectedBoard: String,
    selectedSubject: String,
    subjects: List<SubjectEntity>,
    quizState: ActiveQuizState,
    onSelectSubject: (String) -> Unit,
    onGenerateQuiz: (subject: String, topic: String, difficulty: String, count: Int) -> Unit,
    onSelectOption: (questionIndex: Int, optionIndex: Int) -> Unit,
    onSubmitQuiz: () -> Unit
) {
    var topicInput by rememberSaveable { mutableStateOf(quizState.topic) }
    var selectedDifficulty by rememberSaveable { mutableStateOf(quizState.difficulty) }
    var selectedPresetCount by rememberSaveable { mutableIntStateOf(15) }
    var isCustomCountMode by rememberSaveable { mutableStateOf(false) }
    var customCountText by rememberSaveable { mutableStateOf("20") }

    val difficulties = listOf("Easy", "Medium", "Hard", "Extreme")
    val presetCounts = listOf(15, 25, 30)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Quiz Engine Control Deck
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Text(
                    text = "🎯 Customizable LaTeX MCQ Quiz Engine",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Board Standard: $selectedBoard • Equations in stems & options render in native math format.",
                    color = TextSecondarySlate,
                    fontSize = 12.5.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Subject Quick Selector Chips
                Text(
                    text = "Select Subject",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondarySlate,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    subjects.take(8).forEach { sub ->
                        val active = sub.name.equals(selectedSubject, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (active) ElectricIndigo else Color.White.copy(alpha = 0.06f)
                                )
                                .border(
                                    1.dp,
                                    if (active) CyberCyan else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(50)
                                )
                                .clickable { onSelectSubject(sub.name) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = sub.name,
                                color = if (active) Color.White else TextSecondarySlate,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                GlassTextField(
                    value = topicInput,
                    onValueChange = { topicInput = it },
                    label = "Syllabus Chapter / Focus Topic",
                    placeholder = "e.g. Coulomb's Law, Quadratic Equations, Carnot Cycle",
                    testTagName = "quiz_topic_input"
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Difficulty Selection: Easy, Medium, Hard, Extreme
                Text(
                    text = "Difficulty Level (Easy, Medium, Hard, Extreme)",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondarySlate,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    difficulties.forEach { diff ->
                        val selected = selectedDifficulty == diff
                        val badgeColor = when (diff) {
                            "Easy" -> NeonEmerald
                            "Medium" -> CyberCyan
                            "Hard" -> AmberGold
                            else -> CrimsonAlert
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (selected) badgeColor.copy(alpha = 0.24f) else Color.White.copy(alpha = 0.05f)
                                )
                                .border(
                                    1.5.dp,
                                    if (selected) badgeColor else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { selectedDifficulty = diff }
                                .padding(vertical = 10.dp)
                                .testTag("difficulty_${diff.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = diff,
                                color = if (selected) Color.White else TextSecondarySlate,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.5.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // MCQ Count Selection: 15, 25, 30, or Custom number
                Text(
                    text = "MCQ Count Selection (15, 25, 30, or Custom)",
                    style = MaterialTheme.typography.labelLarge,
                    color = TextSecondarySlate,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    presetCounts.forEach { cnt ->
                        val active = !isCustomCountMode && selectedPresetCount == cnt
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (active) ElectricIndigo.copy(alpha = 0.32f) else Color.White.copy(alpha = 0.05f)
                                )
                                .border(
                                    1.5.dp,
                                    if (active) CyberCyan else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable {
                                    isCustomCountMode = false
                                    selectedPresetCount = cnt
                                }
                                .padding(vertical = 10.dp)
                                .testTag("mcq_count_$cnt"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "$cnt MCQs",
                                color = if (active) Color.White else TextSecondarySlate,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 12.5.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (isCustomCountMode) RoyalViolet.copy(alpha = 0.32f) else Color.White.copy(alpha = 0.05f)
                            )
                            .border(
                                1.5.dp,
                                if (isCustomCountMode) CyberCyan else Color.White.copy(alpha = 0.14f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { isCustomCountMode = true }
                            .padding(vertical = 10.dp)
                            .testTag("mcq_count_custom"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Custom #",
                            color = if (isCustomCountMode) Color.White else TextSecondarySlate,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 12.5.sp
                        )
                    }
                }

                AnimatedVisibility(visible = isCustomCountMode) {
                    Column {
                        Spacer(modifier = Modifier.height(10.dp))
                        GlassTextField(
                            value = customCountText,
                            onValueChange = { raw ->
                                customCountText = raw.filter { it.isDigit() }.take(2)
                            },
                            label = "Enter Custom Number of MCQs (1 - 50)",
                            placeholder = "e.g. 18",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            testTagName = "custom_mcq_number_input"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                val finalMcqCount = if (isCustomCountMode) {
                    (customCountText.toIntOrNull() ?: 15).coerceIn(1, 50)
                } else {
                    selectedPresetCount
                }

                if (quizState.isGenerating) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                color = CyberCyan,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Generating $finalMcqCount $selectedDifficulty MCQs with LaTeX...",
                                color = CyberCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    PrimaryGradientButton(
                        text = "Generate $finalMcqCount $selectedDifficulty MCQs ($selectedSubject)",
                        leadingEmoji = "⚡",
                        onClick = {
                            onGenerateQuiz(
                                selectedSubject,
                                topicInput.ifBlank { "Core Board Syllabus" },
                                selectedDifficulty,
                                finalMcqCount
                            )
                        },
                        testTagName = "generate_quiz_button"
                    )
                }
            }
        }

        // 2. Score Summary Banner if Submitted
        AnimatedVisibility(visible = quizState.isSubmitted) {
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                accentHighlight = NeonEmerald
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Text(
                        text = "🏆 Assessment Graded: ${quizState.scorePercent}% Accuracy",
                        style = MaterialTheme.typography.titleLarge,
                        color = NeonEmerald,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "You earned +${quizState.xpAwarded} Scholar XP! Review the step-by-step LaTeX derivations below.",
                        color = TextPrimaryWhite,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }

        // 3. Active Quiz Questions List (with MathTextView for Stem, Options, and Explanation)
        quizState.questions.forEachIndexed { qIndex, item ->
            val selectedOpt = quizState.selectedAnswers[qIndex] ?: 0
            GlassmorphicCard(
                modifier = Modifier.fillMaxWidth(),
                cornerRadius = 20.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(
                                    ElectricIndigo.copy(alpha = 0.24f),
                                    RoundedCornerShape(8.dp)
                                )
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Question ${qIndex + 1} of ${quizState.questions.size}",
                                color = CyberCyan,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                        Text(
                            text = item.sloTag,
                            color = AmberGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Question Stem rendered via MathTextView
                    MathTextView(
                        content = item.question,
                        fontSize = 15.sp,
                        textColor = TextPrimaryWhite,
                        mathHighlightColor = Color(0xFFE0F2FE)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Options rendered via MathTextView
                    item.options.forEachIndexed { optIndex, optionLatex ->
                        val isChosen = selectedOpt == optIndex
                        val isCorrectOption = item.correctIndex == optIndex
                        val borderColor = when {
                            quizState.isSubmitted && isCorrectOption -> NeonEmerald
                            quizState.isSubmitted && isChosen && !isCorrectOption -> CrimsonAlert
                            isChosen -> CyberCyan
                            else -> Color.White.copy(alpha = 0.14f)
                        }
                        val bgColor = when {
                            quizState.isSubmitted && isCorrectOption -> NeonEmerald.copy(alpha = 0.15f)
                            quizState.isSubmitted && isChosen && !isCorrectOption -> CrimsonAlert.copy(alpha = 0.15f)
                            isChosen -> ElectricIndigo.copy(alpha = 0.22f)
                            else -> Color(0xFF0B0F19).copy(alpha = 0.55f)
                        }

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(bgColor)
                                .border(1.2.dp, borderColor, RoundedCornerShape(14.dp))
                                .clickable(enabled = !quizState.isSubmitted) {
                                    onSelectOption(qIndex, optIndex)
                                }
                                .padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isChosen,
                                onClick = {
                                    if (!quizState.isSubmitted) {
                                        onSelectOption(qIndex, optIndex)
                                    }
                                },
                                colors = RadioButtonDefaults.colors(
                                    selectedColor = CyberCyan,
                                    unselectedColor = TextSecondarySlate
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                MathTextView(
                                    content = optionLatex,
                                    fontSize = 14.sp,
                                    textColor = TextPrimaryWhite,
                                    mathHighlightColor = Color(0xFFC7D2FE)
                                )
                            }
                            if (quizState.isSubmitted && isCorrectOption) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Correct option",
                                    tint = NeonEmerald,
                                    modifier = Modifier.size(20.dp)
                                )
                            } else if (quizState.isSubmitted && isChosen) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = "Incorrect selection",
                                    tint = CrimsonAlert,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Post-submission Step-by-Step LaTeX Explanation
                    AnimatedVisibility(visible = quizState.isSubmitted) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                                .background(
                                    Color(0xFF0F172A),
                                    RoundedCornerShape(12.dp)
                                )
                                .border(1.dp, CyberCyan.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "📐 Step-by-Step SLO Explanation:",
                                color = CyberCyan,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            MathTextView(
                                content = item.explanation,
                                fontSize = 13.5.sp,
                                textColor = TextSecondarySlate,
                                mathHighlightColor = Color(0xFFE0F2FE)
                            )
                        }
                    }
                }
            }
        }

        // Submit Quiz Button
        if (quizState.questions.isNotEmpty() && !quizState.isSubmitted) {
            PrimaryGradientButton(
                text = "Submit ${quizState.questions.size} MCQs for Auto-Grading & XP",
                leadingEmoji = "📊",
                onClick = onSubmitQuiz,
                testTagName = "submit_quiz_button"
            )
        }

        OctagonFooterSection()
    }
}
