package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PieChart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QuizAttemptEntity
import com.example.data.local.SubjectEntity
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonAlert
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextMutedSlate
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

data class BoardTopicProgressItem(
    val topicCode: String,
    val topicName: String,
    val sloWeight: String,
    val masteryPercent: Int,
    val quizAccuracy: Int,
    val boardSection: String
)

object BoardTopicCurriculumCatalog {
    fun getTopicsForSubject(
        subject: String,
        board: String,
        quizAttempts: List<QuizAttemptEntity>,
        boostMap: Map<String, Int>
    ): List<BoardTopicProgressItem> {
        val shortBoard = board.substringBefore("(").trim()
        val baseList = when (subject.lowercase()) {
            "physics" -> listOf(
                BoardTopicProgressItem("SLO-11.1", "Electrostatics & Coulomb's Law", "High Yield • 14%", 88, 92, "Section A & C"),
                BoardTopicProgressItem("SLO-11.2", "Gauss's Divergence & Flux", "Core Derivation • 16%", 82, 85, "Section C (8M)"),
                BoardTopicProgressItem("SLO-11.3", "Thermodynamics & Carnot Cycle", "Must Prepare • 18%", 91, 95, "Section B & C"),
                BoardTopicProgressItem("SLO-11.4", "SHM, Waves & Acoustics", "Standard • 12%", 76, 80, "Section B (4M)"),
                BoardTopicProgressItem("SLO-11.5", "Electromagnetic Induction", "High Yield • 15%", 84, 89, "Section B & C"),
                BoardTopicProgressItem("SLO-11.6", "Quantum & Relativistic Physics", "Conceptual • 13%", 79, 86, "Section A & B")
            )
            "mathematics" -> listOf(
                BoardTopicProgressItem("SLO-12.1", "Quadratic & Polynomial Roots", "Foundational • 14%", 94, 96, "Section A & B"),
                BoardTopicProgressItem("SLO-12.2", "Matrices, Determinants & Systems", "High Yield • 15%", 85, 88, "Section B (4M)"),
                BoardTopicProgressItem("SLO-12.3", "Trigonometric Identities & Inverse", "Core • 16%", 78, 82, "Section B & C"),
                BoardTopicProgressItem("SLO-12.4", "Differential Calculus & Extrema", "Must Prepare • 20%", 86, 90, "Section C (8M)"),
                BoardTopicProgressItem("SLO-12.5", "Definite & Indefinite Integrals", "Must Prepare • 20%", 74, 79, "Section C (8M)"),
                BoardTopicProgressItem("SLO-12.6", "Vectors & Analytic Conic Sections", "Analytical • 15%", 81, 84, "Section A & B")
            )
            "chemistry" -> listOf(
                BoardTopicProgressItem("SLO-10.1", "Stoichiometry & Atomic Orbitals", "Core • 14%", 90, 93, "Section A & B"),
                BoardTopicProgressItem("SLO-10.2", "Chemical Equilibrium & Kp/Kc", "Must Prepare • 18%", 87, 91, "Section C (8M)"),
                BoardTopicProgressItem("SLO-10.3", "Acids, Bases, pH & Buffer Systems", "High Yield • 16%", 85, 89, "Section B & C"),
                BoardTopicProgressItem("SLO-10.4", "Thermochemistry & Hess's Law", "Core Derivation • 15%", 80, 84, "Section B (4M)"),
                BoardTopicProgressItem("SLO-10.5", "Electrochemistry & Redox Cells", "Standard • 14%", 77, 81, "Section B & C"),
                BoardTopicProgressItem("SLO-10.6", "Organic Reaction Mechanisms", "Must Prepare • 23%", 83, 88, "Section C (8M)")
            )
            "computer science" -> listOf(
                BoardTopicProgressItem("SLO-CS.1", "Data Structures & Arrays", "High Yield • 18%", 96, 98, "Section A & B"),
                BoardTopicProgressItem("SLO-CS.2", "Object-Oriented Programming (C++)", "Must Prepare • 22%", 94, 95, "Section C (8M)"),
                BoardTopicProgressItem("SLO-CS.3", "Database Normalization & SQL", "High Yield • 18%", 91, 93, "Section B & C"),
                BoardTopicProgressItem("SLO-CS.4", "Boolean Logic & Karnaugh Maps", "Core • 14%", 89, 92, "Section A & B"),
                BoardTopicProgressItem("SLO-CS.5", "OSI Model & Network Protocols", "Standard • 14%", 87, 90, "Section B (4M)"),
                BoardTopicProgressItem("SLO-CS.6", "Algorithms & Time Complexity", "Analytical • 14%", 92, 94, "Section A & C")
            )
            else -> listOf(
                BoardTopicProgressItem("SLO-01", "$subject Foundational Principles", "$shortBoard • 18%", 84, 88, "Section A (MCQs)"),
                BoardTopicProgressItem("SLO-02", "Core Theoretical Frameworks", "$shortBoard • 20%", 79, 83, "Section B (4M)"),
                BoardTopicProgressItem("SLO-03", "Quantitative & Analytical Models", "$shortBoard • 18%", 75, 81, "Section B & C"),
                BoardTopicProgressItem("SLO-04", "Applied Case Studies & Proofs", "$shortBoard • 16%", 82, 86, "Section C (8M)"),
                BoardTopicProgressItem("SLO-05", "Past Paper High-Yield Synthesis", "$shortBoard • 15%", 88, 91, "Section A & B"),
                BoardTopicProgressItem("SLO-06", "SLO Rubric & Critical Evaluation", "$shortBoard • 13%", 80, 85, "Section C (8M)")
            )
        }

        val subjectAttempts = quizAttempts.filter { it.subject.equals(subject, ignoreCase = true) }
        val latestAttemptBonus = if (subjectAttempts.isNotEmpty()) {
            ((subjectAttempts.first().scorePercent - 75).coerceAtLeast(2)) / 3
        } else {
            0
        }

        return baseList.map { item ->
            val extraBoost = boostMap["$subject:${item.topicCode}"] ?: 0
            val finalMastery = (item.masteryPercent + latestAttemptBonus + extraBoost).coerceIn(10, 100)
            val finalAcc = (item.quizAccuracy + extraBoost / 2).coerceIn(10, 100)
            item.copy(masteryPercent = finalMastery, quizAccuracy = finalAcc)
        }
    }
}

/**
 * Interactive Recharts-inspired Visual Analytics Dashboard tracking student progress
 * across all subjects and regional examination board topics.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RechartsStudentProgressDashboard(
    selectedBoard: String,
    selectedSubject: String,
    subjects: List<SubjectEntity>,
    quizAttempts: List<QuizAttemptEntity>,
    onSelectSubject: (String) -> Unit,
    onUpdateSubjectProgress: (SubjectEntity, Int) -> Unit,
    modifier: Modifier = Modifier
) {
    // 0 = Subject BarChart, 1 = Topic AreaChart, 2 = Board Skill Radar/Donut
    var activeChartTab by rememberSaveable { mutableIntStateOf(0) }
    var selectedSubjectBarIndex by rememberSaveable { mutableIntStateOf(0) }
    var selectedTopicPointIndex by rememberSaveable { mutableIntStateOf(2) }
    val topicBoostMap = remember { mutableStateMapOf<String, Int>() }

    val displaySubjects = remember(subjects) {
        if (subjects.isNotEmpty()) subjects.take(8) else emptyList()
    }

    val topicItems = remember(selectedSubject, selectedBoard, quizAttempts, topicBoostMap.toMap()) {
        BoardTopicCurriculumCatalog.getTopicsForSubject(
            subject = selectedSubject,
            board = selectedBoard,
            quizAttempts = quizAttempts,
            boostMap = topicBoostMap
        )
    }

    val overallSubjectAvg = remember(displaySubjects) {
        if (displaySubjects.isNotEmpty()) {
            displaySubjects.sumOf { it.progressPercent } / displaySubjects.size
        } else {
            82
        }
    }

    val overallTopicMasteryAvg = remember(topicItems) {
        if (topicItems.isNotEmpty()) {
            topicItems.sumOf { it.masteryPercent } / topicItems.size
        } else {
            84
        }
    }

    GlassmorphicCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("recharts_progress_dashboard"),
        cornerRadius = 24.dp,
        borderAlpha = 0.28f
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Top Header & Live Summary Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                Brush.linearGradient(listOf(ElectricIndigo, CyberCyan)),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Analytics,
                            contentDescription = "Visual Analytics",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "📊 Recharts Visual Progress Analytics",
                            style = MaterialTheme.typography.titleMedium,
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "$selectedBoard • Subject & SLO Topic Telemetry",
                            color = CyberCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .background(NeonEmerald.copy(alpha = 0.16f), RoundedCornerShape(50))
                        .border(1.dp, NeonEmerald.copy(alpha = 0.45f), RoundedCornerShape(50))
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Text(
                        text = "$overallSubjectAvg% Syllabus",
                        color = NeonEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Recharts Chart Type Switcher Tabs
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF090D16).copy(alpha = 0.85f))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(14.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ChartModeTabButton(
                    title = "Subjects Bar",
                    icon = Icons.Default.BarChart,
                    selected = activeChartTab == 0,
                    onClick = { activeChartTab = 0 },
                    modifier = Modifier.weight(1f),
                    testTag = "chart_tab_subjects_bar"
                )
                ChartModeTabButton(
                    title = "Topics Area",
                    icon = Icons.Default.ShowChart,
                    selected = activeChartTab == 1,
                    onClick = { activeChartTab = 1 },
                    modifier = Modifier.weight(1f),
                    testTag = "chart_tab_topics_area"
                )
                ChartModeTabButton(
                    title = "SLO Radar",
                    icon = Icons.Default.PieChart,
                    selected = activeChartTab == 2,
                    onClick = { activeChartTab = 2 },
                    modifier = Modifier.weight(1f),
                    testTag = "chart_tab_slo_radar"
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Render Selected Recharts-Style Interactive Canvas Chart
            when (activeChartTab) {
                0 -> {
                    RechartsSubjectBarChartSection(
                        subjects = displaySubjects,
                        selectedSubject = selectedSubject,
                        selectedIndex = selectedSubjectBarIndex.coerceIn(
                            0,
                            (displaySubjects.size - 1).coerceAtLeast(0)
                        ),
                        onBarSelected = { index, subjectEntity ->
                            selectedSubjectBarIndex = index
                            onSelectSubject(subjectEntity.name)
                        },
                        onBoostSubjectProgress = { subjectEntity ->
                            val newPct = (subjectEntity.progressPercent + 4).coerceAtMost(100)
                            onUpdateSubjectProgress(subjectEntity, newPct)
                        }
                    )
                }

                1 -> {
                    RechartsTopicAreaChartSection(
                        selectedSubject = selectedSubject,
                        selectedBoard = selectedBoard,
                        topics = topicItems,
                        selectedPointIndex = selectedTopicPointIndex.coerceIn(
                            0,
                            (topicItems.size - 1).coerceAtLeast(0)
                        ),
                        onSelectPoint = { selectedTopicPointIndex = it },
                        onBoostTopic = { topicItem ->
                            val key = "$selectedSubject:${topicItem.topicCode}"
                            val current = topicBoostMap[key] ?: 0
                            topicBoostMap[key] = (current + 5).coerceAtMost(25)
                        }
                    )
                }

                else -> {
                    RechartsBoardDistributionSection(
                        selectedSubject = selectedSubject,
                        selectedBoard = selectedBoard,
                        overallSubjectAvg = overallSubjectAvg,
                        overallTopicMasteryAvg = overallTopicMasteryAvg,
                        topics = topicItems
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Exam Board Topic Mastery Breakdown List (Always visible below chart)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "🎯 $selectedSubject — Exam Board Topic Mastery",
                        style = MaterialTheme.typography.titleSmall,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = "Tap '+5% Practice' on any unit after completing revision",
                        color = TextSecondarySlate,
                        fontSize = 11.5.sp
                    )
                }
                Text(
                    text = "Avg: $overallTopicMasteryAvg%",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                topicItems.forEachIndexed { idx, topic ->
                    val statusColor = when {
                        topic.masteryPercent >= 88 -> NeonEmerald
                        topic.masteryPercent >= 78 -> CyberCyan
                        else -> AmberGold
                    }
                    val statusLabel = when {
                        topic.masteryPercent >= 88 -> "Mastered"
                        topic.masteryPercent >= 78 -> "On Track"
                        else -> "Focus Area"
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF0B0F19).copy(alpha = 0.72f))
                            .border(
                                width = 1.dp,
                                color = if (idx == selectedTopicPointIndex && activeChartTab == 1) {
                                    CyberCyan.copy(alpha = 0.7f)
                                } else {
                                    Color.White.copy(alpha = 0.10f)
                                },
                                shape = RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                selectedTopicPointIndex = idx
                            }
                            .padding(12.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                ElectricIndigo.copy(alpha = 0.25f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 7.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = topic.topicCode,
                                            color = CyberCyan,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = topic.topicName,
                                        color = TextPrimaryWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                statusColor.copy(alpha = 0.16f),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .padding(horizontal = 7.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "$statusLabel • ${topic.masteryPercent}%",
                                            color = statusColor,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }

                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(ElectricIndigo.copy(alpha = 0.28f))
                                            .border(
                                                1.dp,
                                                CyberCyan.copy(alpha = 0.45f),
                                                RoundedCornerShape(8.dp)
                                            )
                                            .clickable {
                                                val key = "$selectedSubject:${topic.topicCode}"
                                                val current = topicBoostMap[key] ?: 0
                                                topicBoostMap[key] = (current + 5).coerceAtMost(25)
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                            .testTag("boost_topic_${topic.topicCode}")
                                    ) {
                                        Text(
                                            text = "+5%",
                                            color = Color.White,
                                            fontSize = 10.5.sp,
                                            fontWeight = FontWeight.ExtraBold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { (topic.masteryPercent / 100f).coerceIn(0f, 1f) },
                                color = statusColor,
                                trackColor = Color.White.copy(alpha = 0.10f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(50))
                            )

                            Spacer(modifier = Modifier.height(5.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${topic.boardSection} • ${topic.sloWeight}",
                                    color = TextMutedSlate,
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "Quiz Accuracy: ${topic.quizAccuracy}%",
                                    color = TextSecondarySlate,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChartModeTabButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (selected) {
                    Brush.horizontalGradient(listOf(ElectricIndigo, RoyalViolet))
                } else {
                    Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                }
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 6.dp)
            .then(if (testTag.isNotEmpty()) Modifier.testTag(testTag) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (selected) Color.White else TextSecondarySlate,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = title,
                color = if (selected) Color.White else TextSecondarySlate,
                fontSize = 11.5.sp,
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Recharts-Style Responsive BarChart with CartesianGrid, Target ReferenceLine (90%),
 * XAxis labels, YAxis ticks, and Interactive Tooltip Card.
 */
@Composable
private fun RechartsSubjectBarChartSection(
    subjects: List<SubjectEntity>,
    selectedSubject: String,
    selectedIndex: Int,
    onBarSelected: (Int, SubjectEntity) -> Unit,
    onBoostSubjectProgress: (SubjectEntity) -> Unit
) {
    val animProgress by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 650, easing = FastOutSlowInEasing),
        label = "barChartAnim"
    )

    val inspectedSubject = subjects.getOrNull(selectedIndex) ?: subjects.firstOrNull()

    Column(modifier = Modifier.fillMaxWidth()) {
        // Recharts Interactive Floating Tooltip Banner
        if (inspectedSubject != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, CyberCyan.copy(alpha = 0.45f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .background(CyberCyan, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${inspectedSubject.name} (${inspectedSubject.category})",
                                color = TextPrimaryWhite,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 13.sp
                            )
                        }
                        Text(
                            text = "Mastery: ${inspectedSubject.progressPercent}%  •  Board Target: 90%  •  Tap any bar to switch subject",
                            color = TextSecondarySlate,
                            fontSize = 11.5.sp,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(NeonEmerald.copy(alpha = 0.20f))
                            .border(1.dp, NeonEmerald.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .clickable { onBoostSubjectProgress(inspectedSubject) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("boost_subject_progress_button")
                    ) {
                        Text(
                            text = "+4% Log Study",
                            color = NeonEmerald,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Recharts BarChart Canvas with CartesianGrid & ReferenceLine
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(215.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF090D16).copy(alpha = 0.90f))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                .padding(top = 16.dp, bottom = 12.dp, start = 12.dp, end = 12.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .pointerInput(subjects) {
                            detectTapGestures { tapOffset ->
                                if (subjects.isNotEmpty() && size.width > 0) {
                                    val slotWidth = size.width.toFloat() / subjects.size
                                    val idx = (tapOffset.x / slotWidth)
                                        .toInt()
                                        .coerceIn(0, subjects.size - 1)
                                    onBarSelected(idx, subjects[idx])
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)

                        // CartesianGrid horizontal lines (25%, 50%, 75%, 100%)
                        listOf(0.25f, 0.50f, 0.75f, 1.0f).forEach { frac ->
                            val y = h * (1f - frac)
                            drawLine(
                                color = Color.White.copy(alpha = 0.10f),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = dashEffect
                            )
                        }

                        // ReferenceLine at 90% Board Distinction Target
                        val targetY = h * (1f - 0.90f)
                        drawLine(
                            color = AmberGold.copy(alpha = 0.75f),
                            start = Offset(0f, targetY),
                            end = Offset(w, targetY),
                            strokeWidth = 1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                        )

                        if (subjects.isNotEmpty()) {
                            val count = subjects.size
                            val slotWidth = w / count
                            val barWidth = (slotWidth * 0.42f).coerceAtMost(32.dp.toPx())

                            subjects.forEachIndexed { index, sub ->
                                val centerX = slotWidth * index + slotWidth / 2f
                                val pct = (sub.progressPercent / 100f).coerceIn(0.05f, 1f) * animProgress
                                val barHeight = h * pct
                                val topY = h - barHeight
                                val isSelected = sub.name.equals(selectedSubject, ignoreCase = true) || index == selectedIndex

                                // Background target ghost bar (90%)
                                val targetBarHeight = h * 0.90f
                                drawRoundRect(
                                    color = Color.White.copy(alpha = 0.05f),
                                    topLeft = Offset(centerX - barWidth / 2f, h - targetBarHeight),
                                    size = Size(barWidth, targetBarHeight),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                                )

                                // Active Recharts Gradient Bar
                                val barBrush = when {
                                    isSelected -> Brush.verticalGradient(
                                        colors = listOf(CyberCyan, ElectricIndigo),
                                        startY = topY,
                                        endY = h
                                    )
                                    sub.progressPercent >= 85 -> Brush.verticalGradient(
                                        colors = listOf(NeonEmerald, Color(0xFF059669)),
                                        startY = topY,
                                        endY = h
                                    )
                                    else -> Brush.verticalGradient(
                                        colors = listOf(ElectricIndigo, RoyalViolet),
                                        startY = topY,
                                        endY = h
                                    )
                                }

                                drawRoundRect(
                                    brush = barBrush,
                                    topLeft = Offset(centerX - barWidth / 2f, topY),
                                    size = Size(barWidth, barHeight),
                                    cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                                )

                                // Highlight outline if selected
                                if (isSelected) {
                                    drawRoundRect(
                                        color = Color.White.copy(alpha = 0.85f),
                                        topLeft = Offset(centerX - barWidth / 2f, topY),
                                        size = Size(barWidth, barHeight),
                                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                                        style = Stroke(width = 1.5.dp.toPx())
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // XAxis Subject Labels Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    subjects.forEachIndexed { index, sub ->
                        val isSelected = sub.name.equals(selectedSubject, ignoreCase = true) || index == selectedIndex
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onBarSelected(index, sub) }
                        ) {
                            Text(
                                text = "${sub.progressPercent}%",
                                color = if (isSelected) CyberCyan else TextSecondarySlate,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = sub.name.take(5),
                                color = if (isSelected) TextPrimaryWhite else TextMutedSlate,
                                fontSize = 10.5.sp,
                                fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Recharts Legend Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDotItem(color = CyberCyan, label = "Selected Subject")
            Spacer(modifier = Modifier.width(14.dp))
            LegendDotItem(color = NeonEmerald, label = "Distinction (85%+)")
            Spacer(modifier = Modifier.width(14.dp))
            LegendDotItem(color = AmberGold, label = "Board Target (90%)")
        }
    }
}

/**
 * Recharts-Style Responsive AreaChart & LineChart for Exam Board Topic SLO Mastery
 * and Quiz Accuracy Trajectory.
 */
@Composable
private fun RechartsTopicAreaChartSection(
    selectedSubject: String,
    selectedBoard: String,
    topics: List<BoardTopicProgressItem>,
    selectedPointIndex: Int,
    onSelectPoint: (Int) -> Unit,
    onBoostTopic: (BoardTopicProgressItem) -> Unit
) {
    val inspectedTopic = topics.getOrNull(selectedPointIndex) ?: topics.firstOrNull()

    Column(modifier = Modifier.fillMaxWidth()) {
        // Recharts Tooltip Card for Inspected Topic Point
        if (inspectedTopic != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color(0xFF0F172A))
                    .border(1.dp, ElectricIndigo.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${inspectedTopic.topicCode}: ${inspectedTopic.topicName}",
                            color = TextPrimaryWhite,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "SLO Mastery: ${inspectedTopic.masteryPercent}%  •  Quiz Accuracy: ${inspectedTopic.quizAccuracy}%  •  ${inspectedTopic.boardSection}",
                            color = CyberCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(CyberCyan.copy(alpha = 0.20f))
                            .border(1.dp, CyberCyan.copy(alpha = 0.55f), RoundedCornerShape(10.dp))
                            .clickable { onBoostTopic(inspectedTopic) }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "+5% Mastery",
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Recharts Dual-Series AreaChart Canvas (Series 1: Topic Mastery %, Series 2: Quiz Accuracy %)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(210.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF090D16).copy(alpha = 0.90f))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
                .padding(14.dp)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .pointerInput(topics) {
                            detectTapGestures { tapOffset ->
                                if (topics.size > 1 && size.width > 0) {
                                    val stepX = size.width.toFloat() / (topics.size - 1)
                                    val idx = ((tapOffset.x + stepX / 2f) / stepX)
                                        .toInt()
                                        .coerceIn(0, topics.size - 1)
                                    onSelectPoint(idx)
                                }
                            }
                        }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val dash = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)

                        // CartesianGrid Horizontal & Vertical Lines
                        listOf(0.25f, 0.50f, 0.75f, 1.0f).forEach { frac ->
                            val y = h * (1f - frac)
                            drawLine(
                                color = Color.White.copy(alpha = 0.09f),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx(),
                                pathEffect = dash
                            )
                        }

                        if (topics.size >= 2) {
                            val stepX = w / (topics.size - 1)

                            val masteryPoints = topics.mapIndexed { idx, item ->
                                val x = idx * stepX
                                val y = h * (1f - (item.masteryPercent / 100f).coerceIn(0.05f, 0.98f))
                                Offset(x, y)
                            }

                            val accuracyPoints = topics.mapIndexed { idx, item ->
                                val x = idx * stepX
                                val y = h * (1f - (item.quizAccuracy / 100f).coerceIn(0.05f, 0.98f))
                                Offset(x, y)
                            }

                            // Area fill path for Mastery
                            val areaPath = Path().apply {
                                moveTo(masteryPoints.first().x, h)
                                masteryPoints.forEach { pt -> lineTo(pt.x, pt.y) }
                                lineTo(masteryPoints.last().x, h)
                                close()
                            }
                            drawPath(
                                path = areaPath,
                                brush = Brush.verticalGradient(
                                    colors = listOf(
                                        CyberCyan.copy(alpha = 0.36f),
                                        ElectricIndigo.copy(alpha = 0.14f),
                                        Color.Transparent
                                    ),
                                    startY = 0f,
                                    endY = h
                                )
                            )

                            // Line path for Quiz Accuracy (Emerald secondary series)
                            val accLinePath = Path().apply {
                                moveTo(accuracyPoints.first().x, accuracyPoints.first().y)
                                for (i in 1 until accuracyPoints.size) {
                                    lineTo(accuracyPoints[i].x, accuracyPoints[i].y)
                                }
                            }
                            drawPath(
                                path = accLinePath,
                                color = NeonEmerald.copy(alpha = 0.85f),
                                style = Stroke(
                                    width = 2.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 6f), 0f)
                                )
                            )

                            // Primary Line path for SLO Mastery
                            val masteryLinePath = Path().apply {
                                moveTo(masteryPoints.first().x, masteryPoints.first().y)
                                for (i in 1 until masteryPoints.size) {
                                    lineTo(masteryPoints[i].x, masteryPoints[i].y)
                                }
                            }
                            drawPath(
                                path = masteryLinePath,
                                brush = Brush.horizontalGradient(listOf(ElectricIndigo, CyberCyan)),
                                style = Stroke(
                                    width = 3.dp.toPx(),
                                    cap = StrokeCap.Round,
                                    join = StrokeJoin.Round
                                )
                            )

                            // Vertical cursor line on selected point
                            val activePt = masteryPoints.getOrNull(selectedPointIndex)
                            if (activePt != null) {
                                drawLine(
                                    color = CyberCyan.copy(alpha = 0.55f),
                                    start = Offset(activePt.x, 0f),
                                    end = Offset(activePt.x, h),
                                    strokeWidth = 1.5.dp.toPx(),
                                    pathEffect = dash
                                )
                            }

                            // Draw vertices
                            masteryPoints.forEachIndexed { idx, pt ->
                                val isSelected = idx == selectedPointIndex
                                drawCircle(
                                    color = if (isSelected) Color.White else CyberCyan,
                                    radius = if (isSelected) 6.dp.toPx() else 4.dp.toPx(),
                                    center = pt
                                )
                                if (isSelected) {
                                    drawCircle(
                                        color = CyberCyan.copy(alpha = 0.35f),
                                        radius = 11.dp.toPx(),
                                        center = pt
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // XAxis Topic Codes
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    topics.forEachIndexed { idx, item ->
                        val isSelected = idx == selectedPointIndex
                        Text(
                            text = item.topicCode.substringAfter("-"),
                            color = if (isSelected) CyberCyan else TextMutedSlate,
                            fontSize = 10.5.sp,
                            fontWeight = if (isSelected) FontWeight.ExtraBold else FontWeight.Medium,
                            modifier = Modifier.clickable { onSelectPoint(idx) }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            LegendDotItem(color = CyberCyan, label = "SLO Topic Mastery %")
            Spacer(modifier = Modifier.width(16.dp))
            LegendDotItem(color = NeonEmerald, label = "Quiz Accuracy % (Dashed)")
        }
    }
}

/**
 * Recharts-Style Radar & Donut Distribution Chart showing performance across
 * Pakistan Board Exam Paper Sections (Section A MCQs, Section B SLO Short Qs, Section C Derivations).
 */
@Composable
private fun RechartsBoardDistributionSection(
    selectedSubject: String,
    selectedBoard: String,
    overallSubjectAvg: Int,
    overallTopicMasteryAvg: Int,
    topics: List<BoardTopicProgressItem>
) {
    val sectionAMastery = remember(topics) {
        (overallTopicMasteryAvg + 4).coerceAtMost(98)
    }
    val sectionBMastery = remember(topics) {
        overallTopicMasteryAvg.coerceIn(60, 96)
    }
    val sectionCMastery = remember(topics) {
        (overallTopicMasteryAvg - 3).coerceIn(55, 94)
    }
    val numericalMastery = remember(topics) {
        ((overallSubjectAvg + overallTopicMasteryAvg) / 2).coerceIn(60, 95)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF090D16).copy(alpha = 0.90f))
            .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(16.dp))
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Multi-Ring Recharts RadialBar / Donut Chart
        Box(
            modifier = Modifier.size(135.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val strokeWidth = 11.dp.toPx()
                val spacing = 14.dp.toPx()
                val center = Offset(size.width / 2f, size.height / 2f)
                val maxRadius = (min(size.width, size.height) / 2f) - strokeWidth

                val rings = listOf(
                    Triple(sectionAMastery / 100f, CyberCyan, maxRadius),
                    Triple(sectionBMastery / 100f, ElectricIndigo, maxRadius - spacing),
                    Triple(sectionCMastery / 100f, NeonEmerald, maxRadius - spacing * 2)
                )

                rings.forEach { (pct, color, radius) ->
                    if (radius > 0f) {
                        drawCircle(
                            color = Color.White.copy(alpha = 0.08f),
                            radius = radius,
                            center = center,
                            style = Stroke(width = strokeWidth)
                        )
                        drawArc(
                            color = color,
                            startAngle = -90f,
                            sweepAngle = 360f * pct,
                            useCenter = false,
                            topLeft = Offset(center.x - radius, center.y - radius),
                            size = Size(radius * 2f, radius * 2f),
                            style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                        )
                    }
                }
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$overallTopicMasteryAvg%",
                    color = TextPrimaryWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "SLO Index",
                    color = CyberCyan,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Section Breakdown Legend & Readiness Metrics
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "$selectedSubject Paper Readiness",
                color = TextPrimaryWhite,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.5.sp
            )
            SectionReadinessRow(
                label = "Section A (Objective MCQs)",
                percent = sectionAMastery,
                color = CyberCyan
            )
            SectionReadinessRow(
                label = "Section B (SLO Short Qs)",
                percent = sectionBMastery,
                color = ElectricIndigo
            )
            SectionReadinessRow(
                label = "Section C (8M Derivations)",
                percent = sectionCMastery,
                color = NeonEmerald
            )
            SectionReadinessRow(
                label = "LaTeX Numericals & Proofs",
                percent = numericalMastery,
                color = AmberGold
            )
        }
    }
}

@Composable
private fun SectionReadinessRow(
    label: String,
    percent: Int,
    color: Color
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                color = TextSecondarySlate,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "$percent%",
                color = color,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold
            )
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { (percent / 100f).coerceIn(0f, 1f) },
            color = color,
            trackColor = Color.White.copy(alpha = 0.08f),
            modifier = Modifier
                .fillMaxWidth()
                .height(4.5.dp)
                .clip(RoundedCornerShape(50))
        )
    }
}

@Composable
private fun LegendDotItem(
    color: Color,
    label: String
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(color, CircleShape)
        )
        Spacer(modifier = Modifier.width(5.dp))
        Text(
            text = label,
            color = TextSecondarySlate,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
