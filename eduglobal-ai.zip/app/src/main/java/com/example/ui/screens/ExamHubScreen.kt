package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SavedPaperEntity
import com.example.data.local.SubjectEntity
import com.example.ui.components.GlassTextField
import com.example.ui.components.GlassmorphicCard
import com.example.ui.components.MathTextView
import com.example.ui.components.OctagonFooterSection
import com.example.ui.components.PrimaryGradientButton
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.ElectricIndigo
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RoyalViolet
import com.example.ui.theme.TextPrimaryWhite
import com.example.ui.theme.TextSecondarySlate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ExamHubScreen(
    selectedBoard: String,
    selectedSubject: String,
    gradeLevel: String,
    subjects: List<SubjectEntity>,
    activePaper: SavedPaperEntity?,
    savedPapers: List<SavedPaperEntity>,
    isGenerating: Boolean,
    onSelectSubject: (String) -> Unit,
    onAddCustomSubject: (String, String) -> Unit,
    onGeneratePaper: (subject: String, topic: String, board: String, grade: String) -> Unit,
    onSelectSavedPaper: (SavedPaperEntity) -> Unit
) {
    var activeTabIndex by rememberSaveable { mutableIntStateOf(0) }
    var customSubjectInput by rememberSaveable { mutableStateOf("") }
    var useOpenSubjectInput by rememberSaveable { mutableStateOf(false) }
    var focusTopic by rememberSaveable { mutableStateOf("Thermodynamics & Carnot Heat Engine") }
    var customLatexTest by rememberSaveable {
        mutableStateOf("```math\n\\int_{0}^{\\pi/2} \\cos(x) \\, dx = 1 \\quad \\text{and} \\quad x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}\n```")
    }

    val effectiveSubject = if (useOpenSubjectInput && customSubjectInput.isNotBlank()) {
        customSubjectInput.trim()
    } else {
        selectedSubject
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Sub-module Switcher: Guess Papers | Mind Maps | LaTeX Lab
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Text(
                    text = "🏛️ Exam Preparation Hub (Multi-Subject)",
                    style = MaterialTheme.typography.titleLarge,
                    color = TextPrimaryWhite,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "Unrestricted dynamic subject support aligned with $selectedBoard.",
                    color = TextSecondarySlate,
                    fontSize = 12.5.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("📝 Guess Papers", "🧠 Mind Maps", "📐 LaTeX Lab").forEachIndexed { idx, label ->
                        val active = activeTabIndex == idx
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    if (active) ElectricIndigo else Color.White.copy(alpha = 0.06f)
                                )
                                .border(
                                    1.dp,
                                    if (active) CyberCyan else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(12.dp)
                                )
                                .clickable { activeTabIndex = idx }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (active) Color.White else TextSecondarySlate,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Dynamic Multi-Subject Selector + Open Custom Subject Input
        GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Dynamic Subject List",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimaryWhite,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(
                                if (useOpenSubjectInput) RoyalViolet.copy(alpha = 0.35f) else Color.White.copy(alpha = 0.08f)
                            )
                            .border(1.dp, CyberCyan.copy(alpha = 0.5f), RoundedCornerShape(50))
                            .clickable { useOpenSubjectInput = !useOpenSubjectInput }
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                            .testTag("toggle_open_subject_input")
                    ) {
                        Text(
                            text = if (useOpenSubjectInput) "Using Custom Input" else "+ Type Any Subject",
                            color = CyberCyan,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    subjects.forEach { sub ->
                        val active = !useOpenSubjectInput && sub.name.equals(selectedSubject, ignoreCase = true)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (active) ElectricIndigo else Color.White.copy(alpha = 0.05f)
                                )
                                .border(
                                    1.dp,
                                    if (active) CyberCyan else Color.White.copy(alpha = 0.14f),
                                    RoundedCornerShape(50)
                                )
                                .clickable {
                                    useOpenSubjectInput = false
                                    onSelectSubject(sub.name)
                                }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = sub.name,
                                color = if (active) Color.White else TextSecondarySlate,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = useOpenSubjectInput) {
                    Column {
                        Spacer(modifier = Modifier.height(12.dp))
                        GlassTextField(
                            value = customSubjectInput,
                            onValueChange = { customSubjectInput = it },
                            label = "Type Any Custom Subject (Added to Dynamic Subject Hub)",
                            placeholder = "e.g. Applied Electronics, Macroeconomics, Sociology",
                            testTagName = "exam_hub_custom_subject_input"
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                GlassTextField(
                    value = focusTopic,
                    onValueChange = { focusTopic = it },
                    label = "Focus Chapter / Syllabus Unit",
                    placeholder = "e.g. Thermodynamics & Carnot Cycle",
                    testTagName = "exam_hub_topic_input"
                )

                Spacer(modifier = Modifier.height(14.dp))

                if (isGenerating) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(
                                color = CyberCyan,
                                strokeWidth = 2.5.dp,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Generating SLO Model Guess Paper for $effectiveSubject...",
                                color = CyberCyan,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    PrimaryGradientButton(
                        text = "Generate AI Predicted Guess Paper ($effectiveSubject)",
                        leadingEmoji = "⚡",
                        onClick = {
                            if (useOpenSubjectInput && customSubjectInput.isNotBlank()) {
                                onAddCustomSubject(customSubjectInput.trim(), "Custom Board Subject")
                            }
                            onGeneratePaper(
                                effectiveSubject,
                                focusTopic.ifBlank { "Complete Syllabus" },
                                selectedBoard,
                                gradeLevel
                            )
                        },
                        testTagName = "generate_guess_paper_button"
                    )
                }
            }
        }

        // Tab Content
        when (activeTabIndex) {
            0 -> {
                if (savedPapers.size > 1) {
                    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "📂 Saved Model Papers (${savedPapers.size})",
                                color = AmberGold,
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                savedPapers.take(5).forEach { paper ->
                                    val isCurrent = activePaper?.id == paper.id
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(
                                                if (isCurrent) ElectricIndigo.copy(alpha = 0.3f) else Color.White.copy(alpha = 0.05f)
                                            )
                                            .border(
                                                1.dp,
                                                if (isCurrent) CyberCyan else Color.White.copy(alpha = 0.14f),
                                                RoundedCornerShape(10.dp)
                                            )
                                            .clickable { onSelectSavedPaper(paper) }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = "${paper.subject}: ${paper.topic.take(18)}",
                                            color = TextPrimaryWhite,
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (activePaper != null) {
                    GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp)
                        ) {
                            MathTextView(
                                content = activePaper.markdownContent,
                                fontSize = 14.5.sp
                            )
                        }
                    }
                }
            }

            1 -> {
                // Visual Concept Mind Map Generator
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "🧠 Hierarchical Concept Mind Map: $effectiveSubject",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberCyan,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF090D16), RoundedCornerShape(14.dp))
                                .border(1.dp, CyberCyan.copy(alpha = 0.35f), RoundedCornerShape(14.dp))
                                .padding(14.dp)
                        ) {
                            Text(
                                text = """
[$effectiveSubject • $focusTopic]
  ├── 1. Core Governing Laws & Conservation Principles
  │     ├── Equilibrium State: ∑ F⃗ = 0  &  ΔU = Q - W
  │     └── Reference Frames & Boundary Conditions ($selectedBoard)
  ├── 2. Differential & Integral Formulations
  │     ├── Rate Equation: F⃗_net = dp⃗/dt = m a⃗
  │     └── Accumulation Integral: W = ∫ P dV  &  Φ_E = ∮ E⃗ · dA⃗
  └── 3. High-Yield Board SLO Applications
        ├── Section A: Conceptual Invariants & SI Dimensional Analysis
        └── Section C: 8-Mark Step-by-Step Analytical Derivation
                                """.trimIndent(),
                                color = NeonEmerald,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }

            else -> {
                // LaTeX & Scientific Notation Sanitizer Verification Lab
                GlassmorphicCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        Text(
                            text = "📐 LaTeX & KaTeX Mobile Sanitizer Lab",
                            style = MaterialTheme.typography.titleMedium,
                            color = CyberCyan,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Paste any LaTeX equation (even wrapped in accidental ```math fences) to verify clean symbol rendering:",
                            color = TextSecondarySlate,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp, bottom = 10.dp)
                        )
                        GlassTextField(
                            value = customLatexTest,
                            onValueChange = { customLatexTest = it },
                            label = "Raw Input (Supports $...$, $$...$$, and strips ```math fences)",
                            placeholder = "Enter LaTeX formula",
                            singleLine = false
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Rendered Publication-Grade Output:",
                            color = NeonEmerald,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        MathTextView(content = customLatexTest)
                    }
                }
            }
        }

        OctagonFooterSection()
    }
}
